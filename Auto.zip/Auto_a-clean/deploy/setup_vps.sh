#!/usr/bin/env bash
# ============================================================================
# نصب خودکار بات روی یک VPS اوبونتو (22.04 / 24.04) — x86_64 یا ARM (Oracle)
#
# طرز استفاده:
#   روی سرور، پروژه را به /opt برسانید، بعد:
#   sudo bash setup_vps.sh
#
# این اسکریپت:
#   1) پایتون 3 و ابزارهای ساخت را نصب می‌کند
#   2) یک virtualenv می‌سازد و requirements را نصب می‌کند
#   3) فایل سرویس systemd را نصب و فعال می‌کند (اجرای خودکار بعد از ری‌بوت)
#   4) بات را با polling شروع می‌کند (ساده‌ترین حالت، بدون نیاز به SSL)
#
# نکته: قبل از اجرا مطمئن شوید فایل .env در پوشه پروژه درست شده
# (BOT_TOKEN و ADMIN_TELEGRAM_IDS حداقل الزامی‌اند).
# ============================================================================
set -euo pipefail

PROJECT_DIR="/opt/tg-business-bot"
SERVICE_NAME="telegram-bot"

echo "==> نصب پکیج‌های سیستمی..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq python3 python3-venv python3-pip build-essential curl git

if [ ! -d "$PROJECT_DIR" ]; then
  echo "!! پوشه $PROJECT_DIR پیدا نشد. ابتدا پروژه را در آن مسیر قرار دهید:"
  echo "    sudo mkdir -p $PROJECT_DIR"
  echo "    sudo cp -r app main.py requirements.txt .env deploy $PROJECT_DIR/"
  exit 1
fi

cd "$PROJECT_DIR"

if [ ! -f .env ]; then
  echo "!! فایل .env پیدا نشد — اشکالی ندارد."
  echo "   توکن و ادمین به‌صورت Built-in در app/config.py تعبیه شده‌اند و بات"
  echo "   بدون .env هم کار می‌کند. (در صورت نیاز بعداً می‌توانید .env بسازید.)"
fi

echo "==> ساخت virtualenv و نصب وابستگی‌ها (چند دقیقه)..."
python3 -m venv venv
./venv/bin/pip install --upgrade pip -q
./venv/bin/pip install -r requirements.txt -q

echo "==> نصب سرویس systemd..."
cp deploy/telegram-bot.service /etc/systemd/system/$SERVICE_NAME.service
systemctl daemon-reload
systemctl enable $SERVICE_NAME

echo "==> شروع بات..."
systemctl restart $SERVICE_NAME

sleep 3
systemctl --no-pager status $SERVICE_NAME --lines=10 || true

echo ""
echo "✅ تمام شد! بات باید همین حالا بالا آمده باشد."
echo "   مشاهده لاگ زنده:        sudo journalctl -u $SERVICE_NAME -f"
echo "   ری‌استارت:               sudo systemctl restart $SERVICE_NAME"
echo ""
echo "   ⚠️ اگر BOT_TOKEN درست باشد، بات با /start کار می‌کند."
echo "   برای تغییر تنظیمات: فایل .env را ویرایش کنید و ری‌استارت بزنید."
