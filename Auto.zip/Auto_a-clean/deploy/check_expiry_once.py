"""
اسکریپت یک‌بار اجرا برای PythonAnywhere (مسیر C در deploy/README.md).

PythonAnywhere رایگان «Always-on task» ندارد؛ به‌جایش حساب رایگان ۱ تسک
زمان‌بندی‌شده (Scheduled Task) در روز دارد. این اسکریپت را همان تسک روزانه
قرار دهید تا کارهای دوره‌ای بات انجام شوند:

  - برگرداندن اکانت‌های Pro/Pro Max منقضی به Free
  - ارسال پیام یادآوری تمدید به کسانی که کمتر از ۲ روز مانده دارند

نکته: در حالت webhook روی PythonAnywhere، jobهای پس‌زمینه‌ی خودِ PTB اجرا
نمی‌شوند؛ این اسکریپت جایگزین آن‌هاست (به‌جای اجرای هر ۶ ساعت، روزی یک‌بار —
کافی و ساده).

استفاده (در PythonAnywhere → Tasks → New daily task):
    python3 /home/<username>/tg-business-bot/check_expiry_once.py
"""
from __future__ import annotations

import asyncio
import logging
import os

from dotenv import load_dotenv
from telegram import Bot

from app import texts
from app.database import get_session, init_db
from app.repository import downgrade_expired_accounts, get_accounts_expiring_soon
from app.timeutil import days_left_until, fa_digits, format_iran

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def main() -> None:
    init_db()  # مطمئن می‌شویم جدول‌ها و migrationها سر جایش هستند
    token = os.getenv("BOT_TOKEN", "")
    if not token:
        logger.error("BOT_TOKEN تنظیم نشده است.")
        return
    bot = Bot(token=token)

    with get_session() as session:
        downgraded = downgrade_expired_accounts(session)
        accounts = get_accounts_expiring_soon(session)
        payload = [(acc.owner.telegram_user_id, acc.plan.value, acc.pro_until) for acc in accounts]
    if downgraded:
        logger.info("Downgraded %d expired account(s) to FREE.", downgraded)

    for telegram_user_id, plan_value, pro_until in payload:
        plan_name = "Pro Max" if plan_value == "PRO_MAX" else "Pro"
        try:
            await bot.send_message(
                chat_id=telegram_user_id,
                text=texts.EXPIRY_WARNING_MESSAGE.format(
                    plan=plan_name,
                    expires_at=format_iran(pro_until),
                    days_left=fa_digits(days_left_until(pro_until)),
                ),
            )
        except Exception:
            logger.exception("Failed to send expiry warning to %s", telegram_user_id)
    logger.info("Done. Warnings sent: %d", len(payload))


if __name__ == "__main__":
    asyncio.run(main())
