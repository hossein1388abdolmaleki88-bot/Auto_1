"""
راه‌اندازی Application تلگرام و ثبت تمام Handlerها.

چون از Reply Keyboard (نه Inline) استفاده می‌شود، دیگر CallbackQueryHandler ای
در کار نیست؛ همه‌ی تعاملات منو از طریق پیام‌های متنی (فشردن دکمه = ارسال متن آن
دکمه) پردازش می‌شوند. یک روتر مرکزی (`_private_text_router`) بر اساس
وضعیت فعلی کاربر (`app.handlers.state`) تصمیم می‌گیرد کدام Handler باید پیام را
پردازش کند.

طبق بخش ۳۰ Specification: هم Polling (برای Local) و هم Webhook (برای Production)
پشتیبانی می‌شود؛ انتخاب با متغیر محیطی TELEGRAM_MODE انجام می‌شود.
"""
from __future__ import annotations

import logging
import time

from telegram import Update
from telegram.ext import (
    Application,
    BusinessConnectionHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    PicklePersistence,
    filters,
)
from telegram.request import HTTPXRequest

from app import texts
from app.config import PROJECT_ROOT, settings
from app.database import get_session, init_db
from app.handlers import admin_handlers, business_handlers, force_join, rule_handlers, state, user_handlers
from app.repository import (
    downgrade_expired_accounts,
    ensure_default_pricing,
    get_accounts_expiring_soon,
    purge_disconnected_accounts,
)
from app.timeutil import format_iran

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logging.getLogger("httpx").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)

# نشانه‌ی نسخه — با هر تغییر مهم در کد به‌روزرسانی می‌شود تا هنگام اجرا بلافاصله
# (اولین خط لاگ) بشود مطمئن شد کدام نسخه از پروژه واقعاً در حال اجراست. اگر این
# مقدار در لاگ شما با آخرین چیزی که دریافت کرده‌اید فرق دارد، یعنی هنوز نسخه‌ی
# قدیمی فایل‌ها اجرا می‌شود (نه نسخه‌ای که فکر می‌کنید).
BUILD_TAG = "2026-09-10-nightguard-timezone"


async def _on_error(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    logger.exception("Unhandled exception while processing update: %s", update, exc_info=context.error)


async def _downgrade_expired_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    with get_session() as session:
        count = downgrade_expired_accounts(session)
        if count:
            logger.info("Downgraded %d expired Pro/Pro Max account(s) to FREE.", count)


async def _purge_disconnected_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    """هر ۲۴ ساعت: اکانت‌هایی که بیش از مهلت بازیابی (۳۰ روز) پیش قطع شده‌اند و
    کاربر برنگشته‌اند را حذف کامل می‌کند تا داده‌ی بی‌صاحب باقی نماند (مکمل
    «غیرفعال‌سازی نرم» — خودِ حذف با delete_business_account انجام می‌شود)."""
    with get_session() as session:
        count = purge_disconnected_accounts(session)
    if count:
        logger.info("Purged %d disconnected account(s) past the grace period.", count)


async def _expiry_warning_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    """هر روز اجرا می‌شود: به کاربرانی که ظرف ۲ روز آینده Pro/Pro Max آن‌ها منقضی
    می‌شود، یک‌بار پیام یادآوری تمدید می‌فرستد (بخش ۲ روز مانده به اتمام اعتبار)."""
    with get_session() as session:
        accounts = get_accounts_expiring_soon(session)
        # استخراج فیلدهای لازم قبل از بسته شدن session (بعد از with، owner دیگر قابل دسترس نیست)
        payload = [(acc.owner.telegram_user_id, acc.plan.value, acc.pro_until) for acc in accounts]

    now = utcnow()
    for telegram_user_id, plan_value, pro_until in payload:
        plan_name = "Pro Max" if plan_value == "PRO_MAX" else "Pro"
        days_left = max(1, (pro_until - now).days + 1)
        try:
            await context.bot.send_message(
                chat_id=telegram_user_id,
                text=texts.EXPIRY_WARNING_MESSAGE.format(
                    plan=plan_name,
                    expires_at=format_iran(pro_until),
                    days_left=days_left,
                ),
            )
        except Exception:
            logger.exception("Failed to send expiry warning to telegram_user_id=%s", telegram_user_id)


async def _daily_backup_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    """هر ۲۴ ساعت اجرا می‌شود: فایل‌های لازم برای جابه‌جایی سرور (app.db،
    bot_persistence.pickle، .env) را برای همه‌ی ادمین‌ها (ADMIN_TELEGRAM_IDS)
    ارسال می‌کند تا همیشه یک نسخه‌ی به‌روز از اطلاعات، مستقل از سرور فعلی، در
    خودِ تلگرام موجود باشد."""
    for admin_id in settings.admin_telegram_ids:
        try:
            await admin_handlers.send_backup_files(context.bot, admin_id, auto=True)
        except Exception:
            logger.exception("Failed to send daily backup to admin_id=%s", admin_id)


# نگاشت (menu فعلی) → (تابع مدیریت متن آن منو). هر تابع True برمی‌گرداند اگر پیام
# را پردازش کرده باشد.
_MENU_TEXT_HANDLERS = {
    state.MENU_RULES: rule_handlers.handle_rules_menu_text,
    state.MENU_SALAM_LANG: rule_handlers.handle_rules_menu_text,
    state.MENU_RULE_DETAIL: rule_handlers.handle_rule_detail_text,
    state.MENU_RULE_TEST: rule_handlers.handle_rule_test_text,
    state.MENU_NIGHT_GUARD: rule_handlers.handle_night_guard_menu_text,
    state.MENU_NIGHT_GUARD_TZ: rule_handlers.handle_night_guard_tz_text,
    state.MENU_NIGHT_GUARD_TEXT: rule_handlers.handle_night_guard_text_input,
    state.MENU_NIGHT_GUARD_START: rule_handlers.handle_night_guard_time_input,
    state.MENU_NIGHT_GUARD_END: rule_handlers.handle_night_guard_time_input,
    state.MENU_RULE_ADD_TRIGGER_TYPE: rule_handlers.handle_trigger_type_text,
    state.MENU_RULE_ADD_TRIGGER_VALUE: rule_handlers.handle_trigger_value_text,
    state.MENU_RULE_ADD_RESPONSE_TEXT: rule_handlers.handle_response_text_text,
    state.MENU_RULE_ADD_PHOTOS: rule_handlers.handle_photos_menu_text,
    state.MENU_BUY_PLAN_CHOICE: user_handlers.handle_buy_plan_choice_text,
    state.MENU_BUY_DURATION_CHOICE: user_handlers.handle_buy_duration_choice_text,
    state.MENU_ADMIN: admin_handlers.handle_admin_menu_text,
    state.MENU_ADMIN_USERS: admin_handlers.handle_admin_users_text,
    state.MENU_ADMIN_USER_DETAIL: admin_handlers.handle_admin_user_detail_text,
    state.MENU_ADMIN_USER_DELETE_CONFIRM: admin_handlers.handle_admin_user_delete_confirm_text,
    state.MENU_ADMIN_ACTIVATE_PLAN_CHOICE: admin_handlers.handle_admin_activate_plan_choice_text,
    state.MENU_ADMIN_ACTIVATE_DURATION_CHOICE: admin_handlers.handle_admin_activate_duration_choice_text,
    state.MENU_ADMIN_PRICE: admin_handlers.handle_admin_price_text,
    state.MENU_ADMIN_EDIT_PRICE: admin_handlers.handle_admin_edit_price_text,
    state.MENU_ADMIN_EDIT_DURATION: admin_handlers.handle_admin_edit_duration_text,
    state.MENU_ADMIN_RULE_LIMITS: admin_handlers.handle_admin_rule_limits_text,
    state.MENU_ADMIN_BROADCAST_COMPOSE: admin_handlers.handle_admin_broadcast_compose_text,
    state.MENU_ADMIN_BROADCAST_CONFIRM: admin_handlers.handle_admin_broadcast_confirm_text,
    state.MENU_ADMIN_CONTENT: admin_handlers.handle_admin_content_text,
    state.MENU_ADMIN_EDIT_SUPPORT_USERNAME: admin_handlers.handle_admin_edit_support_username_text,
    state.MENU_ADMIN_EDIT_HELP_TEXT: admin_handlers.handle_admin_edit_help_text_text,
    state.MENU_ADMIN_EDIT_CONNECT_TEXT: admin_handlers.handle_admin_edit_connect_text,
    state.MENU_FALLBACK_REPLY: user_handlers.handle_fallback_menu_text,
    state.MENU_FALLBACK_REPLY_EDIT: user_handlers.handle_fallback_reply_edit_text,
    state.MENU_FALLBACK_REPLY_PHOTOS: user_handlers.handle_fallback_menu_text,
    state.MENU_ADMIN_EDIT_RULE_LIMIT: admin_handlers.handle_admin_edit_rule_limit_text,
    state.MENU_ADMIN_EDIT_PRO_RULE_LIMIT: admin_handlers.handle_admin_edit_pro_rule_limit_text,
    state.MENU_ADMIN_PRICING_LIST: admin_handlers.handle_admin_pricing_list_text,
    state.MENU_ADMIN_PRICING_EDIT: admin_handlers.handle_admin_pricing_edit_text,
    state.MENU_ADMIN_FORCE_JOIN: admin_handlers.handle_admin_force_join_text,
    state.MENU_ADMIN_FORCE_JOIN_LIST: admin_handlers.handle_admin_force_join_list_text,
    state.MENU_ADMIN_FJ_ADD_CHANNEL: admin_handlers.handle_admin_fj_add_channel_text,
}


async def _private_text_router(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text = (update.effective_message.text or "").strip()
    if not text:
        return

    # --- اکشن‌های سراسری (از هر منویی قابل دسترسی‌اند) ---
    if text == texts.BTN_FORCE_JOIN_CHECK:
        await force_join.force_join_check_handler(update, context)
        return

    if text == texts.BTN_BACK_TO_MENU:
        await user_handlers.show_main_menu(update, context)
        return

    if text == texts.BTN_ADMIN_PANEL:
        if admin_handlers.is_admin_user(update.effective_user.id):
            await admin_handlers.show_admin_panel(update, context)
        else:
            await update.effective_message.reply_text(texts.NOT_ADMIN_NO_PANEL_HINT)
        return

    current_menu = state.get_menu(context)

    # --- دکمه‌های منوی اصلی (فقط وقتی کاربر واقعاً در منوی اصلی است) ---
    if current_menu == state.MENU_MAIN:
        if text == texts.BTN_CONNECT:
            await user_handlers.show_connect_info(update, context)
            return
        if text == texts.BTN_BUY_PRO:
            await user_handlers.show_buy_pro(update, context)
            return
        if text == texts.BTN_ACCOUNT:
            await user_handlers.show_account_info(update, context)
            return
        if text == texts.BTN_HELP:
            await user_handlers.show_help(update, context)
            return
        if text == texts.BTN_MANAGE_RULES:
            await rule_handlers.show_rules_menu(update, context)
            return

    # دکمه‌هایی که در چند منو دیده می‌شوند (مثل خرید Pro و راهنما بعد از بازگشت)
    if text == texts.BTN_CONTACT_ADMIN:
        await user_handlers.buy_pro_contact_admin(update, context)
        return

    # --- روتر بر اساس وضعیت فعلی ---
    handler = _MENU_TEXT_HANDLERS.get(current_menu)
    if handler is not None:
        handled = await handler(update, context, text)
        if handled:
            return

    # هیچ‌کدام Match نشد → بازگشت به منوی اصلی برای جلوگیری از گیر کردن کاربر
    await update.effective_message.reply_text(texts.UNKNOWN_ACTION)


async def _private_photo_router(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await rule_handlers.rule_add_photo_router(update, context)
    await user_handlers.fallback_photo_router(update, context)


def build_application() -> Application:
    logger.info("=== Bot build tag: %s === (اگر این مقدار با چیزی که انتظار دارید فرق دارد، فایل‌های قدیمی هنوز در حال اجرا هستند)", BUILD_TAG)
    errors = settings.validate()
    for err in errors:
        logger.warning("Configuration warning: %s", err)

    init_db()
    with get_session() as session:
        ensure_default_pricing(session)

    # Persistence (رفع باگ مهم): بدون این، هر بار که فرآیند بات متوقف/دوباره اجرا شود،
    # context.user_data (که وضعیت فعلی منوی هر کاربر — مثلاً «داخل مدیریت قوانین است»
    # یا «منتظر تایپ عبارت Rule است» — و پیش‌نویس‌های نیمه‌کاره در آن ذخیره می‌شود) از صفر
    # شروع می‌شود، ولی کیبورد قبلی هنوز در گوشی کاربر نمایش داده می‌شود. با زدن دکمه‌ای
    # از آن کیبورد قدیمی، بات (که فکر می‌کند کاربر در منوی اصلی است) پیام را نمی‌شناسد و
    # «دستور نامشخص» برمی‌گرداند. PicklePersistence این وضعیت را روی دیسک ذخیره و در
    # هر اجرا بازیابی می‌کند تا این اتفاق نیفتد. (توجه: تنظیمات/قیمت‌ها/کاربران/قوانین از
    # اول هم در دیتابیس SQLite ذخیره می‌شدند و ماندگار بودند؛ مشکل واقعی مسیر نسبی
    # پیش‌فرض دیتابیس بود که در app/config.py رفع شد — همان‌جا مستندش کرده‌ایم.)
    persistence = PicklePersistence(filepath=str(PROJECT_ROOT / "bot_persistence.pickle"))

    # تنظیمات شبکه مقاوم‌تر (رفع باگ قابلیت‌اطمینان واقعی که در محیط تولید رخ داد:
    # httpx.ReadTimeout / httpx.ConnectTimeout روی اینترنت موبایل/ناپایدار).
    #
    # PTB به‌صورت پیش‌فرض timeout سخت‌گیرانه‌ای دارد (connect_timeout=5s،
    # read_timeout=5s) که برای اینترنت خانگی/دیتاسنتر پایدار کافی است اما روی
    # شبکه‌ی موبایل (یا هر اتصال ناپایدار دیگر) باعث خطای زودهنگام و مکرر
    # می‌شود، حتی وقتی اتصال چند ثانیه بعد خودش برقرار می‌ماند. مقادیر بزرگ‌تر
    # اینجا، همراه با mechanism داخلی PTB برای تلاش مجدد خودکار (که همان
    # network_retry_loop است که در لاگ‌های واقعی هم دیده شد و به‌درستی کار
    # می‌کند)، احتمال شکست‌های گذرا را به‌طور قابل‌توجهی کم می‌کند.
    #
    # get_updates باید read_timeout بزرگ‌تری داشته باشد چون خودِ Long Polling
    # (پارامتر timeout در run_polling، پیش‌فرض ۱۰ ثانیه) باید کمتر از این مقدار
    # باشد تا اتصال زودتر از پاسخ واقعی تلگرام قطع نشود.
    general_request = HTTPXRequest(
        connect_timeout=20.0,
        read_timeout=20.0,
        write_timeout=20.0,
        pool_timeout=20.0,
    )
    get_updates_request = HTTPXRequest(
        connect_timeout=20.0,
        read_timeout=40.0,
        write_timeout=20.0,
        pool_timeout=20.0,
    )

    application = (
        Application.builder()
        .token(settings.bot_token)
        .persistence(persistence)
        .request(general_request)
        .get_updates_request(get_updates_request)
        .build()
    )

    # --- Business (هسته اصلی محصول) ---
    application.add_handler(BusinessConnectionHandler(business_handlers.on_business_connection))
    application.add_handler(
        MessageHandler(filters.UpdateType.BUSINESS_MESSAGE, business_handlers.on_business_message)
    )

    # --- کاربر عادی / ادمین ---
    application.add_handler(CommandHandler("start", user_handlers.start_command))
    application.add_handler(CommandHandler("admin", admin_handlers.admin_command))
    # 🛡 ستون‌های اعتماد: حریم خصوصی و شفافیت سلامت — از هر منویی قابل اجرا
    application.add_handler(CommandHandler("privacy", user_handlers.privacy_command))
    application.add_handler(CommandHandler("status", user_handlers.status_command))

    # اطلاعات اجرا برای /status (بدون circular import از BUILD_TAG)
    application.bot_data["build_tag"] = BUILD_TAG
    application.bot_data["started_at"] = time.time()

    # --- روتر پیام‌های متنی/عکس خصوصی (کل منطق Reply Keyboard از همین‌جا رد می‌شود) ---
    #
    # نکته بسیار مهم (رفع باگ): آپدیت‌های Business Message (پیام بین صاحب کسب‌وکار و
    # مشتریانش) هم effective_chat.type == PRIVATE دارند و هم از فیلتر filters.TEXT
    # عبور می‌کنند (چون هر دو روی update.effective_message کار می‌کنند که برای این
    # آپدیت‌ها همان update.business_message است). بدون exclude کردن صریح
    # BUSINESS_MESSAGE/EDITED_BUSINESS_MESSAGE، این MessageHandler روی *همان* آپدیتی
    # هم اجرا می‌شد که BusinessConnectionHandler بالا از قبل مدیریتش کرده — و چون آن
    # پیام با هیچ‌کدام از دکمه‌های منو تطابق ندارد، به هر دو طرف (صاحب کسب‌وکار و
    # مشتری) پیام «دستور نامشخص» ارسال می‌شد.
    _NOT_BUSINESS = ~filters.UpdateType.BUSINESS_MESSAGE & ~filters.UpdateType.EDITED_BUSINESS_MESSAGE
    application.add_handler(
        MessageHandler(filters.ChatType.PRIVATE & filters.PHOTO & _NOT_BUSINESS, _private_photo_router)
    )
    application.add_handler(
        MessageHandler(
            filters.ChatType.PRIVATE & filters.TEXT & ~filters.COMMAND & _NOT_BUSINESS, _private_text_router
        )
    )

    application.add_error_handler(_on_error)

    if application.job_queue is not None:
        application.job_queue.run_repeating(_downgrade_expired_job, interval=3600, first=10)
        application.job_queue.run_repeating(_expiry_warning_job, interval=21600, first=30)
        application.job_queue.run_repeating(_daily_backup_job, interval=86400, first=60)
        application.job_queue.run_repeating(_purge_disconnected_job, interval=86400, first=120)
    else:
        logger.warning(
            "JobQueue در دسترس نیست (پکیج python-telegram-bot[job-queue] نصب نشده)؛ "
            "بررسی انقضای Pro/Pro Max و یادآوری اتمام اعتبار به‌صورت خودکار انجام نخواهد شد."
        )

    return application


def run() -> None:
    application = build_application()

    if settings.telegram_mode == "webhook":
        logger.info("Starting bot in webhook mode on %s:%s", settings.webhook_listen, settings.webhook_port)
        application.run_webhook(
            listen=settings.webhook_listen,
            port=settings.webhook_port,
            secret_token=settings.webhook_secret or None,
            webhook_url=settings.webhook_url,
            allowed_updates=Update.ALL_TYPES,
        )
    else:
        logger.info("Starting bot in polling mode")
        application.run_polling(allowed_updates=Update.ALL_TYPES)
