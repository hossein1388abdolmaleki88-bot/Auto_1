"""
مدیریت قوانین اختصاصی + امکان فعال/غیرفعال کردن قانون رایگان «سلام».

مدل Free/Pro/Pro Max برای قوانین اختصاصی:
    هر سه پلن می‌توانند قانون اختصاصی بسازند، اما هرکدام سقف خودش را دارد
    (`get_rule_limit_for_account`؛ قابل تنظیم از پنل ادمین → «💰 قیمت Pro»):
    Free → `free_rule_limit` (پیش‌فرض ۲)، Pro → `pro_rule_limit` (پیش‌فرض ۱۵)،
    Pro Max → همیشه نامحدود. رولی که یک کاربر غیر-Max در سقف مجاز خودش می‌سازد
    `requires_pro=False` دارد تا واقعاً هم اجرا شود (نه فقط ذخیره شود)؛ در
    غیر این‌صورت Rule Engine (app/rule_engine.py) آن را نادیده می‌گرفت. برای
    کاربر Pro/Pro Max واقعی، `requires_pro=True` می‌ماند تا اگر پلن منقضی شد
    رول هم غیرفعال شود (انگیزه تمدید).

نکته مهم درباره Rule «سلام»:
    این Rule از نوع EXACT است، نه FIRST_MESSAGE. بنابراین طبق طراحی Rule Engine
    (app/rule_engine.py)، برای *هر* پیامی که دقیقاً برابر «سلام» باشد اجرا
    می‌شود — چه این اولین پیام آن مشتری با کسب‌وکار باشد، چه مشتری قبلاً هم
    پیام داده باشد. نیازی به تغییر منطق Rule Engine نبود، چون این رفتار از
    ابتدا همین‌طور طراحی شده بود.

معماری وضعیت (State Machine ساده مبتنی بر context.user_data، به‌جای
ConversationHandler، برای سازگاری با Reply Keyboard):

    MENU_RULES              → لیست قوانین + دکمه فعال/غیرفعال «سلام»
    MENU_RULE_DETAIL         → جزئیات یک قانون اختصاصی خاص
    MENU_RULE_ADD_TRIGGER_TYPE   → انتخاب نوع شرط
    MENU_RULE_ADD_TRIGGER_VALUE  → تایپ عبارت
    MENU_RULE_ADD_RESPONSE_TEXT  → تایپ متن پاسخ
    MENU_RULE_ADD_PHOTOS         → افزودن عکس(ها)
"""
from __future__ import annotations

from telegram import Update
from telegram.ext import ContextTypes

from app import keyboards, texts
from app.database import get_session
from app.handlers import state
from app.handlers import user_handlers
from app.models import BusinessAccount, Rule, TriggerType, utcnow
from app.repository import (
    business_account_is_pro,
    count_custom_rules,
    count_rule_matches,
    create_rule,
    delete_rule,
    duplicate_rule,
    get_business_accounts_for_user,
    get_customer_reply_media,
    get_customer_reply_text,
    get_or_create_user,
    get_rule_limit_for_account,
    list_rules,
    plan_label,
    to_engine_rules,
    toggle_rule,
)
from app.repository import set_auto_reply_paused, set_night_guard, set_salam_rule
from app.services.media_service import TELEGRAM_MEDIA_GROUP_MAX
from app.services.night_guard import (
    DEFAULT_TIMEZONE,
    NIGHT_GUARD_DEFAULT_TEXT,
    format_minutes,
    is_within_window,
    parse_hhmm,
    resolve_timezone,
    zone_for,
)
from app.services.rule_tester import preview_response, trigger_label
from app.timeutil import fa_digits


def _get_any_account_id_sync(session, telegram_user_id: int) -> int | None:
    """برای دسترسی به Rule رایگان «سلام»، Pro لازم نیست — هر Business Account کافی است."""
    user = get_or_create_user(session, telegram_user_id=telegram_user_id)
    accounts = get_business_accounts_for_user(session, user.id)
    return accounts[0].id if accounts else None


def _get_any_account_sync(session, telegram_user_id: int) -> BusinessAccount | None:
    """اکانت Business کاربر (اگر باشد) — برای منطق سقف قانون هر پلن لازم است."""
    user = get_or_create_user(session, telegram_user_id=telegram_user_id)
    accounts = get_business_accounts_for_user(session, user.id)
    return accounts[0] if accounts else None


async def show_rules_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    tg_user = update.effective_user
    with get_session() as session:
        account = _get_any_account_sync(session, tg_user.id)
        if account is None:
            await update.effective_message.reply_text(
                texts.NO_BUSINESS_CONNECTION, reply_markup=keyboards.back_to_menu_keyboard()
            )
            state.set_menu(context, state.MENU_MAIN)
            return
        account_id = account.id

        rules = list_rules(session, account_id)
        system_rule = next((r for r in rules if r.is_system), None)
        custom_rules = [r for r in rules if not r.is_system]
        free_rule_enabled = system_rule.enabled if system_rule else True

        limit = get_rule_limit_for_account(session, account)
        label = plan_label(account)
        is_paused = bool(account.auto_reply_paused)

        text = texts.RULES_LIST_HEADER
        if not custom_rules:
            text += texts.RULES_LIST_EMPTY_NOTE
        if limit is None:
            text += texts.RULES_LIST_UNLIMITED_NOTE.format(plan=label)
        else:
            text += texts.RULES_LIST_QUOTA_NOTE.format(plan=label, used=len(custom_rules), limit=limit)
        if is_paused:
            # یادآوری مهم: وقتی کل پاسخ‌ها متوقف است، کاربر باید بداند چیزی جواب نمی‌گیرد
            text += "\n\n⏸ حالت فعلی: همه‌ی پاسخ‌های خودکار متوقف‌اند (دکمه‌ی ▶️ پایین)."
        keyboard = keyboards.rules_list_keyboard(custom_rules, free_rule_enabled, is_paused)

    state.set_menu(context, state.MENU_RULES)
    await update.effective_message.reply_text(text, reply_markup=keyboard)


async def show_salam_lang_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """🟢 زیرمنوی انتخاب زبان پیام «سلام» (فقط همین بخش) — وضعیت فعلی + پیش‌نمایش متن."""
    tg_user = update.effective_user
    enabled = False
    current = ""
    with get_session() as session:
        account_id = _get_any_account_id_sync(session, tg_user.id)
        if account_id is not None:
            system_rule = next((r for r in list_rules(session, account_id) if r.is_system), None)
            if system_rule is not None:
                enabled = bool(system_rule.enabled)
                current = (system_rule.response_text or "").strip()
    body = texts.safe_format(
        texts.SALAM_LANG_INTRO,
        status=texts.SALAM_STATUS_ON_FA if enabled else texts.SALAM_STATUS_OFF_FA,
        status_en=texts.SALAM_STATUS_ON_EN if enabled else texts.SALAM_STATUS_OFF_EN,
        text=current or "—",
    )
    state.set_menu(context, state.MENU_SALAM_LANG)
    await update.effective_message.reply_text(body, reply_markup=keyboards.salam_lang_keyboard())


async def handle_rules_menu_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    tg_user = update.effective_user

    if text in (texts.BTN_FREE_HELLO_RULE_ON, texts.BTN_FREE_HELLO_RULE_OFF):
        # لمس دکمه‌ی «پیام سلام» → دیگر تاگل مستقیم نیست؛ زیرمنوی انتخاب زبان باز می‌شود
        await show_salam_lang_menu(update, context)
        return True

    # 🟢 انتخاب زبان پاسخ «سلام» (فقط همین بخش) — فارسی / انگلیسی / خاموش
    if text in (texts.BTN_SALAM_SET_FA, texts.BTN_SALAM_SET_EN, texts.BTN_SALAM_TURN_OFF):
        with get_session() as session:
            account_id = _get_any_account_id_sync(session, tg_user.id)
            if account_id is None:
                await update.effective_message.reply_text(
                    texts.NO_BUSINESS_CONNECTION, reply_markup=keyboards.back_to_menu_keyboard()
                )
                return True
            system_rule = next((r for r in list_rules(session, account_id) if r.is_system), None)
            if system_rule is None:
                confirm = texts.RULE_NOT_FOUND
            elif text == texts.BTN_SALAM_TURN_OFF:
                toggle_rule(session, system_rule, False)
                confirm = texts.SALAM_TURN_OFF_DONE
            elif text == texts.BTN_SALAM_SET_FA:
                set_salam_rule(
                    session,
                    system_rule,
                    enabled=True,
                    response_text=texts.SALAM_RESPONSE_FA,
                    trigger_value=texts.SALAM_TRIGGER_FA,
                )
                confirm = texts.SALAM_SET_FA_DONE
            else:
                set_salam_rule(
                    session,
                    system_rule,
                    enabled=True,
                    response_text=texts.SALAM_RESPONSE_EN,
                    trigger_value=texts.SALAM_TRIGGER_EN,
                )
                confirm = texts.SALAM_SET_EN_DONE
        await update.effective_message.reply_text(confirm)
        await show_salam_lang_menu(update, context)
        return True

    # 🔙 بازگشت از زیرمنوی «پیام سلام» به لیست قوانین
    if state.get_menu(context) == state.MENU_SALAM_LANG and text == texts.BTN_BACK_TO_RULES:
        await show_rules_menu(update, context)
        return True

    if text == texts.BTN_RULE_ADD:
        with get_session() as session:
            account = _get_any_account_sync(session, tg_user.id)
            if account is None:
                await update.effective_message.reply_text(
                    texts.NO_BUSINESS_CONNECTION, reply_markup=keyboards.back_to_menu_keyboard()
                )
                return True
            account_id = account.id
            is_pro = business_account_is_pro(account)
            limit = get_rule_limit_for_account(session, account)
            if limit is not None:
                used = count_custom_rules(session, account_id)
                if used >= limit:
                    await update.effective_message.reply_text(
                        texts.RULE_ADD_LIMIT_REACHED.format(plan=plan_label(account), limit=limit),
                        reply_markup=keyboards.back_to_menu_keyboard(),
                    )
                    return True
        context.user_data[state.RULE_ADD_DRAFT] = {
            "business_account_id": account_id,
            "photo_file_ids": [],
            "requires_pro": is_pro,
        }
        state.set_menu(context, state.MENU_RULE_ADD_TRIGGER_TYPE)
        await update.effective_message.reply_text(
            texts.RULE_ADD_INTRO, reply_markup=keyboards.trigger_type_keyboard()
        )
        return True

    if text == texts.BTN_RULE_TEST:
        # 🧪 شبیه‌ساز قوانین — ورود به حالت تست امن (هیچ‌چیز ذخیره نمی‌شود)
        state.set_menu(context, state.MENU_RULE_TEST)
        await update.effective_message.reply_text(
            texts.RULE_TEST_INTRO, reply_markup=keyboards.rule_test_keyboard()
        )
        return True

    if text == texts.BTN_NIGHT_GUARD:
        # 🌙 نگهبان شبانه — منوی تنظیم پیام «الان بسته‌ایم» (همه‌ی پلن‌ها، حتی Free)
        await show_night_guard_menu(update, context)
        return True

    if text in (texts.BTN_RULES_PAUSE_ALL, texts.BTN_RULES_RESUME_ALL):
        # ⏸/▶️ توقف یا از سرگیری «همه‌ی» پاسخ‌های خودکار: قوانین + fallback + نگهبان شبانه
        with get_session() as session:
            account = _get_any_account_sync(session, tg_user.id)
            if account is None:
                await update.effective_message.reply_text(
                    texts.NO_BUSINESS_CONNECTION, reply_markup=keyboards.back_to_menu_keyboard()
                )
                return True
            pause = text == texts.BTN_RULES_PAUSE_ALL
            set_auto_reply_paused(session, account, pause)
        await update.effective_message.reply_text(
            texts.RULES_PAUSED_ALL if pause else texts.RULES_RESUMED_ALL
        )
        await show_rules_menu(update, context)
        return True

    if text == texts.BTN_FALLBACK_REPLY:
        await user_handlers.show_fallback_menu(update, context)
        return True

    rule_id = keyboards.extract_id(text)
    if rule_id is not None:
        await _show_rule_detail(update, context, rule_id)
        return True

    return False


async def _show_rule_detail(update: Update, context: ContextTypes.DEFAULT_TYPE, rule_id: int) -> None:
    with get_session() as session:
        rule = session.get(Rule, rule_id)
        if rule is None:
            await update.effective_message.reply_text(
                texts.RULE_NOT_FOUND, reply_markup=keyboards.back_to_menu_keyboard()
            )
            return
        photos_count = len(rule.media_items)
        match_count = count_rule_matches(session, rule_id)
        detail = texts.RULE_DETAIL_TEMPLATE.format(
            trigger_type=rule.trigger_type.value,
            trigger_value=rule.trigger_value or "—",
            response_text=rule.response_text or "—",
            photos_count=photos_count,
            status="فعال 🟢" if rule.enabled else "غیرفعال 🔴",
        )
        # 🎯 آمار اجرا — کاملاً عددی، بدون خواندن هیچ متن پیامی (سازگار با /privacy)
        detail += texts.RULE_DETAIL_STATS_LINE.format(count=fa_digits(match_count))
        keyboard = keyboards.rule_detail_keyboard(rule)

    context.user_data[state.CURRENT_RULE_ID] = rule_id
    state.set_menu(context, state.MENU_RULE_DETAIL)
    await update.effective_message.reply_text(detail, reply_markup=keyboard)


async def handle_rule_detail_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    rule_id = context.user_data.get(state.CURRENT_RULE_ID)
    if rule_id is None:
        return False

    if text == texts.BTN_BACK_TO_RULES:
        await show_rules_menu(update, context)
        return True

    if text == texts.BTN_RULE_TOGGLE:
        with get_session() as session:
            rule = session.get(Rule, rule_id)
            if rule is None or rule.is_system:
                await update.effective_message.reply_text(texts.RULE_CANNOT_DELETE_SYSTEM)
                return True
            rule = toggle_rule(session, rule, not rule.enabled)
            is_enabled = rule.enabled  # قبل از بسته‌شدن session ذخیره می‌شود (رفع DetachedInstanceError)
        await update.effective_message.reply_text(
            texts.RULE_TOGGLED_ON if is_enabled else texts.RULE_TOGGLED_OFF
        )
        await _show_rule_detail(update, context, rule_id)
        return True

    if text == texts.BTN_RULE_DELETE:
        with get_session() as session:
            rule = session.get(Rule, rule_id)
            if rule is None:
                await update.effective_message.reply_text(texts.RULE_NOT_FOUND)
                await show_rules_menu(update, context)
                return True
            ok = delete_rule(session, rule)
        if ok:
            await update.effective_message.reply_text(texts.RULE_DELETED)
        else:
            await update.effective_message.reply_text(texts.RULE_CANNOT_DELETE_SYSTEM)
        await show_rules_menu(update, context)
        return True

    if text == texts.BTN_RULE_COPY:
        # 📄 کپی قانون — سقف پلن مثل «افزودن قانون جدید» چک می‌شود
        with get_session() as session:
            rule = session.get(Rule, rule_id)
            if rule is None:
                await update.effective_message.reply_text(texts.RULE_NOT_FOUND)
                await show_rules_menu(update, context)
                return True
            if rule.is_system:
                await update.effective_message.reply_text(texts.RULE_CANNOT_DELETE_SYSTEM)
                return True
            account = session.get(BusinessAccount, rule.business_account_id)
            limit = get_rule_limit_for_account(session, account) if account else None
            if limit is not None and count_custom_rules(session, rule.business_account_id) >= limit:
                await update.effective_message.reply_text(
                    texts.RULE_ADD_LIMIT_REACHED.format(
                        plan=plan_label(account), limit=limit
                    ),
                    reply_markup=keyboards.back_to_menu_keyboard(),
                )
                return True
            copy = duplicate_rule(session, rule)
            new_id = copy.id
        await update.effective_message.reply_text(texts.RULE_COPIED.format(new_id=new_id))
        await show_rules_menu(update, context)
        return True

    return False


# --- 🧪 شبیه‌ساز قوانین (تست امن با پیام فرضی مشتری) ---


async def handle_rule_test_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    """هر پیام در این منو = یک پیام «فرضی مشتری». شبیه‌سازی کاملاً در حافظه انجام
    می‌شود: لاگ نمی‌شود، ذخیره نمی‌شود و چیزی ارسال نمی‌شود — فقط پیش‌نمایش."""
    if text == texts.BTN_BACK_TO_RULES:
        await show_rules_menu(update, context)
        return True

    tg_user = update.effective_user
    with get_session() as session:
        account = _get_any_account_sync(session, tg_user.id)
        if account is None:
            await update.effective_message.reply_text(
                texts.NO_BUSINESS_CONNECTION, reply_markup=keyboards.back_to_menu_keyboard()
            )
            state.set_menu(context, state.MENU_MAIN)
            return True

        # همان داده‌هایی که در پاسخ‌گویی واقعی به Rule Engine می‌رسند:
        rules = list_rules(session, account.id, only_enabled=True)
        engine_rules = to_engine_rules(rules)
        fallback_enabled = bool(account.customer_reply_enabled)
        fallback_text = get_customer_reply_text(session, account)
        fallback_photos = len(get_customer_reply_media(session, account))

    outcome = preview_response(
        rules=engine_rules,
        incoming_text=text,
        fallback_enabled=fallback_enabled,
        fallback_text=fallback_text,
        fallback_photos_count=fallback_photos,
    )

    if outcome.matched is not None:
        photos_note = (
            texts.RULE_TEST_PHOTOS_NOTE.format(count=fa_digits(outcome.final_photos_count))
            if outcome.final_photos_count
            else ""
        )
        reply = texts.RULE_TEST_MATCHED.format(
            rule_id=outcome.matched.id,
            trigger_type=trigger_label(outcome.matched),
            trigger_value=outcome.matched.trigger_value or "—",
            response=outcome.final_response_text or "—",
            photos_note=photos_note,
        )
    elif outcome.via_fallback:
        photos_note = (
            texts.RULE_TEST_PHOTOS_NOTE.format(count=fa_digits(outcome.final_photos_count))
            if outcome.final_photos_count
            else ""
        )
        reply = texts.RULE_TEST_FALLBACK.format(
            response=outcome.final_response_text or "—", photos_note=photos_note
        )
    else:
        reply = texts.RULE_TEST_NO_MATCH

    # کاربر در همان منوی تست می‌ماند تا چند پیام مختلف را پشت‌سرهم امتحان کند
    await update.effective_message.reply_text(reply, reply_markup=keyboards.rule_test_keyboard())
    return True


# --- افزودن قانون جدید ---


async def handle_trigger_type_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    draft = context.user_data.get(state.RULE_ADD_DRAFT)
    if draft is None:
        await show_rules_menu(update, context)
        return True

    if text == texts.BTN_CANCEL:
        state.clear_rule_add_draft(context)
        await update.effective_message.reply_text(texts.RULE_ADD_CANCELLED)
        await show_rules_menu(update, context)
        return True

    # گزینه‌ی «پاسخِ عمومی» — تنظیم پیامی که وقتی هیچ قانونی منطبق نیست
    # ارسال می‌شود. تنها راهِ دسترسیِ کاربر به این تنظیم همین‌جاست.
    if text == texts.BTN_TRIGGER_FALLBACK:
        state.clear_rule_add_draft(context)
        from app.handlers.user_handlers import show_fallback_menu

        await show_fallback_menu(update, context)
        return True

    mapping = {
        texts.BTN_TRIGGER_EXACT: TriggerType.EXACT.value,
        texts.BTN_TRIGGER_CONTAINS: TriggerType.CONTAINS.value,
    }
    trigger_type = mapping.get(text)
    if trigger_type is None:
        return False

    draft["trigger_type"] = trigger_type
    context.user_data[state.RULE_ADD_DRAFT] = draft

    state.set_menu(context, state.MENU_RULE_ADD_TRIGGER_VALUE)
    prompt = (
        texts.RULE_ADD_ASK_TRIGGER_VALUE_EXACT
        if trigger_type == TriggerType.EXACT.value
        else texts.RULE_ADD_ASK_TRIGGER_VALUE_CONTAINS
    )
    await update.effective_message.reply_text(prompt, reply_markup=keyboards.cancel_only_keyboard())
    return True


async def handle_trigger_value_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    draft = context.user_data.get(state.RULE_ADD_DRAFT)
    if draft is None:
        await show_rules_menu(update, context)
        return True

    if text == texts.BTN_CANCEL:
        state.clear_rule_add_draft(context)
        await update.effective_message.reply_text(texts.RULE_ADD_CANCELLED)
        await show_rules_menu(update, context)
        return True

    draft["trigger_value"] = text.strip()
    context.user_data[state.RULE_ADD_DRAFT] = draft
    state.set_menu(context, state.MENU_RULE_ADD_RESPONSE_TEXT)
    await update.effective_message.reply_text(
        texts.RULE_ADD_ASK_RESPONSE_TEXT, reply_markup=keyboards.cancel_only_keyboard()
    )
    return True


async def handle_response_text_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    draft = context.user_data.get(state.RULE_ADD_DRAFT)
    if draft is None:
        await show_rules_menu(update, context)
        return True

    if text == texts.BTN_CANCEL:
        state.clear_rule_add_draft(context)
        await update.effective_message.reply_text(texts.RULE_ADD_CANCELLED)
        await show_rules_menu(update, context)
        return True

    draft["response_text"] = None if text.strip() == "-" else text.strip()
    context.user_data[state.RULE_ADD_DRAFT] = draft

    if not draft.get("requires_pro", True):
        # پلن Free: افزودن عکس مخصوص Pro/Pro Max است — رول همین‌جا بدون رسانه ذخیره می‌شود
        # و اصلاً وارد مرحله‌ی «افزودن عکس» نمی‌شویم (نه فقط بلاک‌کردن، بلکه کلاً نمایش داده نمی‌شود).
        with get_session() as session:
            create_rule(
                session,
                business_account_id=draft["business_account_id"],
                trigger_type=TriggerType(draft["trigger_type"]),
                trigger_value=draft.get("trigger_value"),
                response_text=draft.get("response_text"),
                photo_file_ids=[],
                requires_pro=False,  # قوانینِ کاربر همیشه اجرا می‌شوند
            )
        state.clear_rule_add_draft(context)
        await update.effective_message.reply_text(texts.RULE_ADD_SAVED_FREE_NO_MEDIA)
        await show_rules_menu(update, context)
        return True

    state.set_menu(context, state.MENU_RULE_ADD_PHOTOS)
    await update.effective_message.reply_text(
        texts.RULE_ADD_ASK_PHOTOS, reply_markup=keyboards.photo_step_keyboard()
    )
    return True


async def handle_photos_menu_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    """دکمه‌های «پایان افزودن عکس» یا «انصراف» در مرحله عکس (خود عکس‌ها با Handler جدا پردازش می‌شوند)."""
    draft = context.user_data.get(state.RULE_ADD_DRAFT)
    if draft is None:
        await show_rules_menu(update, context)
        return True

    if text == texts.BTN_CANCEL:
        state.clear_rule_add_draft(context)
        await update.effective_message.reply_text(texts.RULE_ADD_CANCELLED)
        await show_rules_menu(update, context)
        return True

    if text == texts.BTN_PHOTOS_DONE:
        with get_session() as session:
            create_rule(
                session,
                business_account_id=draft["business_account_id"],
                trigger_type=TriggerType(draft["trigger_type"]),
                trigger_value=draft.get("trigger_value"),
                response_text=draft.get("response_text"),
                photo_file_ids=draft.get("photo_file_ids", []),
                requires_pro=False,  # قوانینِ کاربر همیشه اجرا می‌شوند
            )
        state.clear_rule_add_draft(context)
        await update.effective_message.reply_text(texts.RULE_ADD_SAVED)
        await show_rules_menu(update, context)
        return True

    return False


async def rule_add_photo_router(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """دریافت عکس‌های Rule در مرحله MENU_RULE_ADD_PHOTOS."""
    if state.get_menu(context) != state.MENU_RULE_ADD_PHOTOS:
        return False

    draft = context.user_data.get(state.RULE_ADD_DRAFT)
    if draft is None:
        return False

    photo = update.effective_message.photo
    if not photo:
        return False

    existing = draft.setdefault("photo_file_ids", [])
    # سقف واقعی Telegram Bot API برای sendMediaGroup دقیقاً ۱۰ آیتم است
    # (app/services/media_service.py::TELEGRAM_MEDIA_GROUP_MAX). قبلاً اگر کاربر
    # بیشتر از ۱۰ عکس می‌فرستاد، همه ذخیره می‌شدند ولی موقع ارسال واقعی فقط ۱۰
    # تای اول استفاده می‌شد — بدون هیچ هشداری، یعنی عکس‌های ۱۱ به بعد بی‌صدا گم
    # می‌شدند. حالا همان لحظه‌ی افزودن جلویش گرفته می‌شود.
    if len(existing) >= TELEGRAM_MEDIA_GROUP_MAX:
        await update.effective_message.reply_text(
            texts.RULE_ADD_PHOTO_LIMIT_REACHED, reply_markup=keyboards.photo_step_keyboard()
        )
        return True

    largest = photo[-1]  # بزرگترین سایز موجود
    existing.append(largest.file_id)
    context.user_data[state.RULE_ADD_DRAFT] = draft

    await update.effective_message.reply_text(
        texts.RULE_ADD_PHOTO_RECEIVED.format(count=len(draft["photo_file_ids"])),
        reply_markup=keyboards.photo_step_keyboard(),
    )
    return True


# --- 🌙 نگهبان شبانه (همه‌ی پلن‌ها، حتی Free) ---


def _night_status_text(account) -> str:
    """متن وضعیت نگهبان برای نمایش در منو (وضعیت + ساعات + پیام فعلی) — مستقیم از خود account."""
    text = account.night_guard_text
    text_preview = text if (text and text.strip()) else NIGHT_GUARD_DEFAULT_TEXT
    # پیش‌نمایش منو حداکثر ۵۰۰ کاراکتر (سقف ۴۰۹۶ تلگرام؛ متن ارسالی به مشتری کامل است)
    if len(text_preview) > 500:
        text_preview = text_preview[:500] + " …"
    start = fa_digits(format_minutes(account.night_start_minute))
    end = fa_digits(format_minutes(account.night_end_minute))
    if account.night_guard_enabled:
        return texts.NIGHT_GUARD_STATUS_ON.format(start=start, end=end, text=text_preview)
    return texts.NIGHT_GUARD_STATUS_OFF.format(
        start=start,
        end=end,
        text=text_preview if (text and text.strip()) else texts.NIGHT_GUARD_DEFAULT_TEXT_PREVIEW,
    )


def _night_tz_info(account) -> tuple[str, str]:
    """(نام منطقه‌ی زمانی فعال، ساعت همین لحظه‌ی همان‌جا HH:MM) برای نمایش در منو."""
    tz = zone_for(account)
    tz_now = utcnow().astimezone(tz)
    return (getattr(account, "night_guard_timezone", None) or DEFAULT_TIMEZONE), tz_now.strftime(
        "%H:%M"
    )


async def show_night_guard_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    tg_user = update.effective_user
    with get_session() as session:
        account = _get_any_account_sync(session, tg_user.id)
        if account is None:
            await update.effective_message.reply_text(
                texts.NO_BUSINESS_CONNECTION, reply_markup=keyboards.back_to_menu_keyboard()
            )
            state.set_menu(context, state.MENU_MAIN)
            return
        status = _night_status_text(account)
        is_enabled = bool(account.night_guard_enabled)

    state.set_menu(context, state.MENU_NIGHT_GUARD)
    tz_display, tz_hhmm = _night_tz_info(account)
    await update.effective_message.reply_text(
        texts.NIGHT_GUARD_INTRO.format(status=status, tz=tz_display, now=tz_hhmm),
        reply_markup=keyboards.night_guard_menu_keyboard(is_enabled),
    )


async def handle_night_guard_menu_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    tg_user = update.effective_user

    if text == texts.BTN_BACK_TO_RULES:
        await show_rules_menu(update, context)
        return True

    with get_session() as session:
        account = _get_any_account_sync(session, tg_user.id)
        if account is None:
            await update.effective_message.reply_text(
                texts.NO_BUSINESS_CONNECTION, reply_markup=keyboards.back_to_menu_keyboard()
            )
            state.set_menu(context, state.MENU_MAIN)
            return True

        if text == texts.BTN_NIGHT_TZ:
            # 🌍 انتخاب منطقه زمانی: پیام راهنما + ورود متنی آزاد (بدون دکمه‌ی انتخاب)
            tz_display, tz_hhmm = _night_tz_info(account)
            state.set_menu(context, state.MENU_NIGHT_GUARD_TZ)
            await update.effective_message.reply_text(
                texts.NIGHT_GUARD_ASK_TZ.format(tz=tz_display, now=tz_hhmm),
                reply_markup=keyboards.night_guard_time_keyboard(),
            )
            return True

        if text == texts.BTN_NIGHT_TEXT:
            state.set_menu(context, state.MENU_NIGHT_GUARD_TEXT)
            await update.effective_message.reply_text(
                texts.NIGHT_GUARD_ASK_TEXT, reply_markup=keyboards.night_guard_text_keyboard()
            )
            return True

        if text == texts.BTN_NIGHT_DEFAULT_TEXT:
            set_night_guard(session, account, text="")
            await update.effective_message.reply_text(texts.NIGHT_GUARD_TEXT_RESET)
        elif text == texts.BTN_NIGHT_START:
            tz_display, _ = _night_tz_info(account)
            state.set_menu(context, state.MENU_NIGHT_GUARD_START)
            await update.effective_message.reply_text(
                texts.NIGHT_GUARD_ASK_START.format(tz=tz_display),
                reply_markup=keyboards.night_guard_time_keyboard(),
            )
            return True
        elif text == texts.BTN_NIGHT_END:
            tz_display, _ = _night_tz_info(account)
            state.set_menu(context, state.MENU_NIGHT_GUARD_END)
            await update.effective_message.reply_text(
                texts.NIGHT_GUARD_ASK_END.format(tz=tz_display),
                reply_markup=keyboards.night_guard_time_keyboard(),
            )
            return True
        elif text in (texts.BTN_NIGHT_ON, texts.BTN_NIGHT_OFF):
            turn_on = text == texts.BTN_NIGHT_ON
            if turn_on:
                # شرط فعال‌سازی: هر دو ساعت تنظیم شده و برابر هم نیستند
                if (
                    account.night_start_minute is None
                    or account.night_end_minute is None
                    or account.night_start_minute == account.night_end_minute
                ):
                    await update.effective_message.reply_text(
                        texts.NIGHT_GUARD_NEED_TIMES.format(
                            start=fa_digits(format_minutes(account.night_start_minute)),
                            end=fa_digits(format_minutes(account.night_end_minute)),
                        )
                    )
                    return True
                set_night_guard(session, account, enabled=True)
                tz_display, _ = _night_tz_info(account)
                await update.effective_message.reply_text(
                    texts.NIGHT_GUARD_ENABLED.format(
                        start=fa_digits(format_minutes(account.night_start_minute)),
                        end=fa_digits(format_minutes(account.night_end_minute)),
                        tz=tz_display,
                    )
                )
            else:
                set_night_guard(session, account, enabled=False)
                await update.effective_message.reply_text(texts.NIGHT_GUARD_DISABLED)
        else:
            return False

    # بعد از تغییر وضعیت/متن/پاک‌سازی → بازگشت به خود منو با وضعیت تازه
    await show_night_guard_menu(update, context)
    return True


async def handle_night_guard_text_input(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    tg_user = update.effective_user

    if text == texts.BTN_BACK_TO_RULES:
        await show_rules_menu(update, context)
        return True
    if text == texts.BTN_CANCEL:
        await show_night_guard_menu(update, context)
        return True
    if text == texts.BTN_NIGHT_DEFAULT_TEXT:
        with get_session() as session:
            account = _get_any_account_sync(session, tg_user.id)
            if account is None:
                await show_rules_menu(update, context)
                return True
            set_night_guard(session, account, text="")
        await update.effective_message.reply_text(texts.NIGHT_GUARD_TEXT_RESET)
        await show_night_guard_menu(update, context)
        return True

    # هر متن دیگری = متن پیام شبانه (محدود معقول: ۱۰۰۰ کاراکتر)
    if len(text) > 1000:
        await update.effective_message.reply_text(
            "❌ متن خیلی طولانیه (حداکثر ۱۰۰۰ کاراکتر)."
        )
        return True

    with get_session() as session:
        account = _get_any_account_sync(session, tg_user.id)
        if account is None:
            await show_rules_menu(update, context)
            return True
        set_night_guard(session, account, text=text)
    await update.effective_message.reply_text(texts.NIGHT_GUARD_TEXT_SAVED)
    await show_night_guard_menu(update, context)
    return True


async def handle_night_guard_tz_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    """🌍 ورود متنی منطقه زمانی — «asia/Tehran» (بزرگ/کوچک و فاصله بی‌اهمیت)."""
    if text == texts.BTN_BACK_TO_RULES:
        await show_rules_menu(update, context)
        return True
    if text == texts.BTN_CANCEL:
        await show_night_guard_menu(update, context)
        return True

    canonical = resolve_timezone(text)
    if canonical is None:
        await update.effective_message.reply_text(
            texts.NIGHT_GUARD_TZ_INVALID, reply_markup=keyboards.night_guard_time_keyboard()
        )
        return True  # در همان منو می‌ماند تا دوباره تایپ کند

    from zoneinfo import ZoneInfo

    with get_session() as session:
        account = _get_any_account_sync(session, update.effective_user.id)
        if account is None:
            await update.effective_message.reply_text(
                texts.NO_BUSINESS_CONNECTION, reply_markup=keyboards.back_to_menu_keyboard()
            )
            state.set_menu(context, state.MENU_MAIN)
            return True
        set_night_guard(session, account, timezone=canonical)
    local_now = utcnow().astimezone(ZoneInfo(canonical)).strftime("%H:%M")
    await update.effective_message.reply_text(
        texts.NIGHT_GUARD_TZ_SAVED.format(tz=canonical, now=local_now)
    )
    await show_night_guard_menu(update, context)
    return True


async def handle_night_guard_time_input(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    tg_user = update.effective_user
    current_menu = state.get_menu(context)
    is_start = current_menu == state.MENU_NIGHT_GUARD_START
    time_label = "شروع" if is_start else "پایان"

    if text == texts.BTN_BACK_TO_RULES:
        await show_rules_menu(update, context)
        return True
    if text == texts.BTN_CANCEL:
        await show_night_guard_menu(update, context)
        return True

    minutes = parse_hhmm(text)
    if minutes is None:
        await update.effective_message.reply_text(
            texts.NIGHT_GUARD_TIME_INVALID, reply_markup=keyboards.night_guard_time_keyboard()
        )
        return True  # در همان منو می‌ماند تا دوباره تایپ کند

    with get_session() as session:
        account = _get_any_account_sync(session, tg_user.id)
        if account is None:
            await show_rules_menu(update, context)
            return True
        # شروع == پایان مجاز نیست (بازه‌ی بی‌معنی) — با پیام دوستانه رد می‌شود
        other = account.night_end_minute if is_start else account.night_start_minute
        if other is not None and other == minutes:
            await update.effective_message.reply_text(
                texts.NIGHT_GUARD_TIME_SAME, reply_markup=keyboards.night_guard_time_keyboard()
            )
            return True
        if is_start:
            set_night_guard(session, account, start_minute=minutes)
        else:
            set_night_guard(session, account, end_minute=minutes)

    await update.effective_message.reply_text(
        texts.NIGHT_GUARD_TIME_SAVED.format(
            label=time_label, value=fa_digits(format_minutes(minutes))
        )
    )
    await show_night_guard_menu(update, context)
    return True
