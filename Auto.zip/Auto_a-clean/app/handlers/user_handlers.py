"""Handlerهای منوی اصلی کاربر عادی (صاحب کسب‌وکار) — با Reply Keyboard دائمی."""
from __future__ import annotations

import time

from telegram import Update
from telegram.ext import ContextTypes

from app import keyboards, texts
from app.config import settings
from app.database import get_session
from app.handlers import state
from app.handlers.force_join import ensure_membership_or_prompt
from app.models import PlanType, utcnow
from app.timeutil import fa_digits, format_iran
from app.services.media_service import TELEGRAM_MEDIA_GROUP_MAX
from app.repository import (
    activate_pro,
    business_account_is_pro,
    get_connect_text,
    get_customer_reply_media,
    get_customer_reply_text,
    reset_customer_reply,
    set_customer_reply,
    set_customer_reply_media,
    clear_customer_reply_media,
    toggle_customer_reply,
    get_admin_username,
    get_business_accounts_for_user,
    get_free_rule_limit,
    get_help_text_template,
    get_or_create_user,
    get_pricing_option,
    get_pro_rule_limit,
    get_rule_limit_for_account,
    list_pricing_options,
)


def is_admin_user(telegram_user_id: int) -> bool:
    return telegram_user_id in settings.admin_telegram_ids


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    tg_user = update.effective_user
    with get_session() as session:
        get_or_create_user(
            session,
            telegram_user_id=tg_user.id,
            username=tg_user.username,
            first_name=tg_user.first_name,
            last_name=tg_user.last_name,
        )

    if not await ensure_membership_or_prompt(update, context):
        return

    context.user_data.clear()
    await update.effective_message.reply_text(
        texts.WELCOME.format(name=tg_user.first_name or "دوست عزیز")
    )
    await show_main_menu(update, context)


# --- 🛡 ستون‌های اعتماد: /privacy و /status ---
#
# این دو دستور از هر منویی قابل اجرا هستند (CommandHandler مستقل از روتر متنی)،
# وضعیت منوی کاربر را تغییر نمی‌دهند و فقط اطلاعات شفاف نمایش می‌دهند.


async def privacy_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """دستور /privacy — صفحه‌ی حریم خصوصی به زبان ساده (چه چیزی ذخیره می‌شود، چه چیزی هرگز)."""
    await update.effective_message.reply_text(texts.PRIVACY_TEXT)


async def status_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """دستور /status — شفافیت سلامت: بات زنده است؟ کدام نسخه؟ چه مدت روشن بوده؟"""
    started_at = context.bot_data.get("started_at")
    if started_at is not None:
        seconds = max(0, int(time.time() - started_at))
        if seconds < 60:
            uptime = fa_digits(seconds) + " ثانیه"
        elif seconds < 3600:
            uptime = fa_digits(seconds // 60) + " دقیقه"
        else:
            uptime = (
                fa_digits(seconds // 3600) + " ساعت و " + fa_digits((seconds % 3600) // 60) + " دقیقه"
            )
    else:
        uptime = "—"

    await update.effective_message.reply_text(
        texts.STATUS_TEXT.format(
            build=context.bot_data.get("build_tag", "—"),
            mode=settings.telegram_mode,
            uptime=uptime,
            now=format_iran(utcnow(), "%H:%M"),
        )
    )


async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    tg_user = update.effective_user
    with get_session() as session:
        user = get_or_create_user(session, telegram_user_id=tg_user.id)
        accounts = get_business_accounts_for_user(session, user.id)
        has_business_account = bool(accounts)

    state.set_menu(context, state.MENU_MAIN)
    state.clear_rule_add_draft(context)
    keyboard = keyboards.main_menu_keyboard(
        has_business_account=has_business_account, is_admin=is_admin_user(tg_user.id)
    )
    await update.effective_message.reply_text(texts.MAIN_MENU_TITLE, reply_markup=keyboard)


async def show_connect_info(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """نمایش صفحه‌ی اعتماد + راهنمای اتصال — متن راهنما از پنل ادمین قابل ویرایش است."""
    with get_session() as session:
        template = get_connect_text(session)
    name = update.effective_user.first_name if update.effective_user else None
    await update.effective_message.reply_text(
        texts.TRUST_INTRO
        + "\n\n———\n\n"
        + texts.safe_format(template, name=name or "دوست عزیز"),
        reply_markup=keyboards.back_to_menu_keyboard(),
    )


# --- 💬 پاسخِ عمومی (وقتی پیام مشتری با هیچ قانونی مطابقت ندارد) ---


# برچسب‌هایی که هرگز نباید به‌عنوان «متن پاسخِ عمومیِ کاربر» ذخیره شوند
# (دکمه‌های منو که کاربر ممکن است با کیبورد قدیمی فشار بدهد).
_RESERVED_MENU_LABELS = frozenset(
    {
        texts.BTN_CONNECT,
        texts.BTN_MANAGE_RULES,
        texts.BTN_FALLBACK_REPLY,
        texts.BTN_ACCOUNT,
        texts.BTN_HELP,
        texts.BTN_BUY_PRO,
        texts.BTN_CONTACT_ADMIN,
        texts.BTN_ADMIN_PANEL,
        texts.BTN_RULE_TEST,
        texts.BTN_RULE_COPY,
        texts.BTN_NIGHT_GUARD,
        texts.BTN_NIGHT_TEXT,
        texts.BTN_NIGHT_DEFAULT_TEXT,
        texts.BTN_NIGHT_START,
        texts.BTN_NIGHT_END,
        texts.BTN_NIGHT_TZ,
        texts.BTN_NIGHT_ON,
        texts.BTN_NIGHT_OFF,
        texts.BTN_RULES_PAUSE_ALL,
        texts.BTN_RULES_RESUME_ALL,
        texts.BTN_SALAM_SET_FA,
        texts.BTN_SALAM_SET_EN,
        texts.BTN_SALAM_TURN_OFF,
    }
)


def _main_account(session, tg_user_id: int):
    """اکانتِ اصلیِ کاربر را برمی‌گرداند (MVP: هر کاربر یک اکانت اصلی دارد)."""
    user = get_or_create_user(session, telegram_user_id=tg_user_id)
    accounts = get_business_accounts_for_user(session, user.id)
    return accounts[0] if accounts else None


async def show_fallback_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """نمایش بخش «💬 هر پیامی به غیر از اینا» (اختیاری؛ پیش‌فرض: غیرفعال و بدون متن)."""
    with get_session() as session:
        account = _main_account(session, update.effective_user.id)
        if account is None:
            await update.effective_message.reply_text(
                texts.NO_BUSINESS_CONNECTION,
                reply_markup=keyboards.back_to_menu_keyboard(),
            )
            return
        is_pro = business_account_is_pro(account)
        enabled = bool(account.customer_reply_enabled)
        current = get_customer_reply_text(session, account)
        has_own = bool((account.customer_reply_text or "").strip())
        photos = get_customer_reply_media(session, account) if is_pro else []

    if not enabled:
        status = "🚫 غیرفعال"
    elif has_own:
        status = "✅ فعال"
    else:
        status = "⚠️ فعال ولی متنی تنظیم نشده — هیچ پیامی ارسال نمی‌شود"

    # پیش‌نمایش منو حداکثر ۵۰۰ کاراکتر (سقف ۴۰۹۶ تلگرام؛ متن ارسالی به مشتری کامل است)
    preview = (current[:500] + " …") if (has_own and current and len(current) > 500) else current
    body = texts.safe_format(
        texts.FALLBACK_REPLY_MENU_HEADER,
        status=status,
        text=preview if has_own else "— هنوز متنی تنظیم نکرده‌اید —",
    )
    if photos:
        body += f"\n\n🖼 تعداد عکس‌های همراه: {fa_digits(len(photos))}"

    # ثبت وضعیت: اگر کاربر از بخش عکس‌ها (یا هر جای دیگر) برگشته باشد،
    # وضعیت منو باید دقیقاً با کیبوردی که می‌بیند یکی باشد.
    state.set_menu(context, state.MENU_FALLBACK_REPLY)
    await update.effective_message.reply_text(
        body,
        reply_markup=keyboards.fallback_reply_menu_keyboard(
            is_enabled=enabled, is_pro=is_pro
        ),
    )


async def handle_fallback_menu_text(
    update: Update, context: ContextTypes.DEFAULT_TYPE, text: str
) -> bool:
    """پردازش دکمه‌های بخش «💬 هر پیامی به غیر از اینا»."""
    if text == texts.BTN_FALLBACK_EDIT:
        state.set_menu(context, state.MENU_FALLBACK_REPLY_EDIT)
        await update.effective_message.reply_text(
            texts.FALLBACK_REPLY_ASK, reply_markup=keyboards.cancel_only_keyboard()
        )
        return True

    if text in (texts.BTN_FALLBACK_TOGGLE_ON, texts.BTN_FALLBACK_TOGGLE_OFF):
        with get_session() as session:
            account = _main_account(session, update.effective_user.id)
            if account is None:
                return True
            # توجه: toggle_customer_reply شیء Account برمی‌گرداند نه bool،
            # بنابراین مقدار درخواستی را خودمان مشخص می‌کنیم.
            turn_on = text == texts.BTN_FALLBACK_TOGGLE_ON
            toggle_customer_reply(session, account, enabled=turn_on)
        await update.effective_message.reply_text(
            texts.FALLBACK_REPLY_TOGGLED_ON
            if turn_on
            else texts.FALLBACK_REPLY_TOGGLED_OFF
        )
        await show_fallback_menu(update, context)
        return True

    if text == texts.BTN_FALLBACK_RESET:
        with get_session() as session:
            account = _main_account(session, update.effective_user.id)
            if account is None:
                return True
            reset_customer_reply(session, account)
        await update.effective_message.reply_text(texts.FALLBACK_REPLY_RESET_DONE)
        await show_fallback_menu(update, context)
        return True

    if text == texts.BTN_FALLBACK_PHOTOS:
        with get_session() as session:
            account = _main_account(session, update.effective_user.id)
            if account is None:
                return True
            photos = get_customer_reply_media(session, account)
        state.set_menu(context, state.MENU_FALLBACK_REPLY_PHOTOS)
        await update.effective_message.reply_text(
            texts.FALLBACK_PHOTOS_ASK,
            reply_markup=keyboards.fallback_photos_keyboard(has_photos=bool(photos)),
        )
        return True

    if text == texts.BTN_FALLBACK_PHOTOS_CLEAR:
        with get_session() as session:
            account = _main_account(session, update.effective_user.id)
            if account is None:
                return True
            clear_customer_reply_media(session, account)
        await update.effective_message.reply_text(texts.FALLBACK_PHOTOS_CLEARED)
        await show_fallback_menu(update, context)
        return True

    if text == texts.BTN_PHOTOS_DONE:
        await show_fallback_menu(update, context)
        return True

    return False


async def handle_fallback_reply_edit_text(
    update: Update, context: ContextTypes.DEFAULT_TYPE, text: str
) -> bool:
    """ذخیره‌ی متن جدیدِ پاسخِ عمومی."""
    if text == texts.BTN_CANCEL:
        await show_fallback_menu(update, context)
        return True

    # محافظت: اگر کاربر (مثلاً با کیبورد قدیمی روی گوشی) یکی از دکمه‌های منو را
    # در حالتِ «در حال نوشتن متن» فشار بدهد، آن متن نباید به‌عنوان پاسخِ عمومی
    # ذخیره شود.
    if text in _RESERVED_MENU_LABELS:
        await update.effective_message.reply_text(texts.FALLBACK_EDIT_RESERVED_HINT)
        await show_fallback_menu(update, context)
        return True

    value = text.strip()
    if not value:
        await update.effective_message.reply_text(texts.FALLBACK_REPLY_ASK)
        return True

    with get_session() as session:
        account = _main_account(session, update.effective_user.id)
        if account is None:
            return True
        set_customer_reply(session, account, value)

    state.set_menu(context, state.MENU_FALLBACK_REPLY)
    await update.effective_message.reply_text(texts.FALLBACK_REPLY_UPDATED)
    await show_fallback_menu(update, context)
    return True


async def fallback_photo_router(
    update: Update, context: ContextTypes.DEFAULT_TYPE
) -> bool:
    """دریافت عکس‌های همراهِ پاسخِ عمومی (ویژه Pro / Pro Max)."""
    if state.get_menu(context) != state.MENU_FALLBACK_REPLY_PHOTOS:
        return False

    photo = update.effective_message.photo
    if not photo:
        return False

    with get_session() as session:
        account = _main_account(session, update.effective_user.id)
        if account is None:
            return True
        existing = get_customer_reply_media(session, account)
        if len(existing) >= TELEGRAM_MEDIA_GROUP_MAX:
            await update.effective_message.reply_text(
                texts.safe_format(
                    texts.FALLBACK_PHOTOS_LIMIT, limit=TELEGRAM_MEDIA_GROUP_MAX
                )
            )
            return True
        # بزرگترین سایز موجود
        set_customer_reply_media(session, account, [*existing, photo[-1].file_id])
        count = len(existing) + 1

    await update.effective_message.reply_text(
        texts.safe_format(texts.FALLBACK_PHOTOS_DONE, count=fa_digits(count))
    )
    return True


async def show_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    with get_session() as session:
        free_limit = get_free_rule_limit(session)
        pro_limit = get_pro_rule_limit(session)
        template = get_help_text_template(session)
    text = texts.safe_format(template, free_limit=free_limit, pro_limit=pro_limit)
    await update.effective_message.reply_text(text, reply_markup=keyboards.back_to_menu_keyboard())


async def show_account_info(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    tg_user = update.effective_user
    with get_session() as session:
        user = get_or_create_user(session, telegram_user_id=tg_user.id)
        accounts = get_business_accounts_for_user(session, user.id)
        if not accounts:
            await update.effective_message.reply_text(
                texts.NO_BUSINESS_CONNECTION, reply_markup=keyboards.back_to_menu_keyboard()
            )
            return

        account = accounts[0]  # نسخه فعلی MVP: هر کاربر یک Business Account اصلی دارد.
        if business_account_is_pro(account):
            expires_at = format_iran(account.pro_until)
            is_max = account.plan == PlanType.PRO_MAX
            rule_limit_text = (
                texts.ACCOUNT_RULE_LIMIT_UNLIMITED
                if is_max
                else texts.ACCOUNT_RULE_LIMIT_LIMITED.format(limit=get_rule_limit_for_account(session, account))
            )
            upgrade_note = texts.ACCOUNT_UPGRADE_NOTE_PRO_MAX if is_max else texts.ACCOUNT_UPGRADE_NOTE_PRO
            text = texts.ACCOUNT_INFO_PRO.format(
                plan_icon="🚀" if is_max else "⭐",
                plan="PRO MAX" if is_max else "PRO",
                expires_at=expires_at,
                rule_limit_text=rule_limit_text,
                upgrade_note=upgrade_note,
            )
        else:
            text = texts.ACCOUNT_INFO_FREE.format(rule_limit=get_free_rule_limit(session))

    await update.effective_message.reply_text(text, reply_markup=keyboards.back_to_menu_keyboard())


# --- خرید / ارتقای Pro و Pro Max ---


async def show_buy_pro(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    state.set_menu(context, state.MENU_BUY_PLAN_CHOICE)
    await update.effective_message.reply_text(
        texts.BUY_PRO_INFO, reply_markup=keyboards.buy_plan_choice_keyboard()
    )


async def handle_buy_plan_choice_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    mapping = {texts.BTN_PLAN_PRO: PlanType.PRO, texts.BTN_PLAN_PRO_MAX: PlanType.PRO_MAX}
    plan = mapping.get(text)
    if plan is None:
        return False

    with get_session() as session:
        options = list_pricing_options(session, plan=plan, only_enabled=True)
        if not options:
            await update.effective_message.reply_text(
                texts.BUY_NO_OPTIONS, reply_markup=keyboards.buy_plan_choice_keyboard()
            )
            return True

        context.user_data[state.BUY_SELECTED_PLAN] = plan.value
        state.set_menu(context, state.MENU_BUY_DURATION_CHOICE)
        plan_name = "Pro Max" if plan == PlanType.PRO_MAX else "Pro"
        await update.effective_message.reply_text(
            texts.BUY_DURATION_HEADER.format(plan=plan_name),
            reply_markup=keyboards.buy_duration_keyboard(options),
        )
    return True


async def _activate_free_plan(
    update: Update, context: ContextTypes.DEFAULT_TYPE, plan_value: str, duration_days: int
) -> None:
    """فعال‌سازی فوری پلن‌های رایگان (price == 0) بدون نیاز به پیام یا تأیید ادمین."""
    tg_user = update.effective_user
    with get_session() as session:
        user = get_or_create_user(
            session,
            telegram_user_id=tg_user.id,
            username=tg_user.username,
            first_name=tg_user.first_name,
            last_name=tg_user.last_name,
        )
        accounts = get_business_accounts_for_user(session, user.id)
        if not accounts:
            await update.effective_message.reply_text(
                texts.NO_BUSINESS_CONNECTION, reply_markup=keyboards.back_to_menu_keyboard()
            )
            return

        account = accounts[0]  # MVP: هر کاربر یک Business Account اصلی دارد
        account = activate_pro(
            session, account, plan=PlanType(plan_value), duration_days=duration_days
        )
        until_str = format_iran(account.pro_until)

    plan_name = "Pro Max" if plan_value == PlanType.PRO_MAX.value else "Pro"
    await update.effective_message.reply_text(
        texts.BUY_FREE_ACTIVATED.format(plan=plan_name, duration=duration_days, until=until_str)
    )
    await show_main_menu(update, context)


async def handle_buy_duration_choice_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
    pricing_id = keyboards.extract_id(text)
    if pricing_id is None:
        return False

    plan_value = context.user_data.get(state.BUY_SELECTED_PLAN, PlanType.PRO.value)
    with get_session() as session:
        option = get_pricing_option(session, pricing_id)
        if option is None:
            return False
        duration_days = option.duration_days
        price = option.price
        admin_username = get_admin_username(session)

    # 🆓 پلن رایگان (price == 0): بدون ادمین، همان لحظه فعال می‌شود
    if price == 0:
        await _activate_free_plan(update, context, plan_value, duration_days)
        return True

    if not admin_username:
        await update.effective_message.reply_text(
            texts.ADMIN_USERNAME_NOT_SET, reply_markup=keyboards.back_to_menu_keyboard()
        )
        return True

    plan_name = "Pro Max" if plan_value == PlanType.PRO_MAX.value else "Pro"
    text_out = texts.PAY_CONTACT_ADMIN.format(
        plan=plan_name,
        duration=duration_days,
        admin_username=admin_username,
        price=price,
    )
    await update.effective_message.reply_text(text_out, reply_markup=keyboards.back_to_menu_keyboard())
    await show_main_menu(update, context)
    return True


async def buy_pro_contact_admin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """دکمه سراسری «💬 ارتباط با ادمین» — یک دکمه که مستقیماً پیوی ادمین را باز می‌کند."""
    with get_session() as session:
        admin_username = (get_admin_username(session) or "").strip().lstrip("@")
    if not admin_username:
        await update.effective_message.reply_text(
            texts.ADMIN_CHAT_NOT_SET, reply_markup=keyboards.back_to_menu_keyboard()
        )
        return
    await update.effective_message.reply_text(
        texts.ADMIN_CHAT_INTRO,
        reply_markup=keyboards.admin_chat_inline_keyboard(admin_username),
    )
