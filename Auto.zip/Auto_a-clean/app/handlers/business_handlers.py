"""
هسته اصلی سیستم: مدیریت اتصال Business و پاسخ‌گویی خودکار به پیام‌های مشتریان.

ساختار طبق بخش ۱۲ Specification:
    Business Owner → Telegram Business Account → Connected Business Bot → Bot من
    → Business Message → Rule Engine → پاسخ از طرف Business Account

نکات پیاده‌سازی:
    - از business_connection_id رسمی Bot API استفاده می‌شود (نه userbot/session string).
    - جلوگیری از Loop (بخش ۲۷): پیام‌هایی که از طرف خود بات (یعنی صاحب کسب‌وکار از طریق
      اپ تلگرامش با استفاده از قابلیت Business Chat پاسخ می‌دهد) در فیلد
      Message.from.is_bot یا برابری chat.id با user_chat_id صاحب اتصال قابل‌تشخیص است؛
      همچنین Deduplication روی telegram_message_id انجام می‌شود.
"""
from __future__ import annotations

import asyncio
import logging

from telegram import Update
from telegram.ext import ContextTypes

from app import texts
from app.database import get_session
from app.models import (
    MessageDirection,
    MessageStatus,
    ResponseMediaType,
    TriggerType,
    utcnow,
)
from app.repository import (
    business_account_is_pro,
    disconnect_business_account,
    get_admin_username,
    get_customer_reply_media,
    get_customer_reply_text,
    get_business_account_by_connection_id,
    get_or_create_customer_chat,
    get_or_create_user,
    is_duplicate_message,
    list_rules,
    log_message,
    night_mark_sent,
    night_was_sent,
    to_engine_rules,
    upsert_business_connection,
)
from app.services.night_guard import NIGHT_GUARD_DEFAULT_TEXT, is_within_window, zone_for
from app.timeutil import to_iran
from app.rule_engine import EngineContext, EngineRule, RuleMediaItem, match_rule
from app.services.media_service import send_rule_response

logger = logging.getLogger(__name__)


async def on_business_connection(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """آپدیت business_connection: وقتی کاربری اکانت Business خود را وصل/قطع/تغییر می‌دهد."""
    bc = update.business_connection
    if bc is None:
        return

    if bc.is_enabled:
        # اتصال فعال → ثبت/به‌روزرسانی اتصال (+ زنده‌کردن اکانتِ قطع‌شده‌ی همان
        # کاربر اگر در مهلت بازیابی باشد — داخل upsert_business_connection).
        with get_session() as session:
            user = get_or_create_user(
                session,
                telegram_user_id=bc.user.id,
                username=bc.user.username,
                first_name=bc.user.first_name,
                last_name=bc.user.last_name,
            )
            can_reply = True
            if bc.rights is not None:
                can_reply = bool(getattr(bc.rights, "can_reply", True))

            upsert_business_connection(
                session,
                business_connection_id=bc.id,
                user=user,
                telegram_user_id=bc.user.id,
                is_enabled=bc.is_enabled,
                can_reply=can_reply,
            )
    else:
        # قطع دسترسی → «غیرفعال‌سازی نرم» (نه حذف): اکانت همان لحظه از لیست
        # کاربران ادمین و منوها حذف می‌شود ولی قوانین/پلن/داده‌ها تا پایان مهلت
        # بازیابی (۳۰ روز) حفظ می‌شوند تا اتصال مجدد، همه‌چیز را برگرداند.
        with get_session() as session:
            removed = disconnect_business_account(session, bc.id)
        if removed:
            logger.info(
                "Business account deactivated (soft) because user disconnected (connection=%s)",
                bc.id,
            )

    from app import texts

    try:
        if bc.is_enabled:
            await context.bot.send_message(chat_id=bc.user_chat_id, text=texts.CONNECTION_ESTABLISHED)
        else:
            await context.bot.send_message(chat_id=bc.user_chat_id, text=texts.CONNECTION_DISABLED)
    except Exception:
        logger.exception("Failed to notify user about business connection status")


async def on_business_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """آپدیت business_message: پیامی که در یک چت مدیریت‌شده توسط Business Connection رد و بدل شده."""
    message = update.business_message
    if message is None:
        return

    business_connection_id = message.business_connection_id
    if not business_connection_id:
        return

    # جلوگیری از Loop: پیام‌هایی که خودِ صاحب کسب‌وکار (نه مشتری) از طریق اپ Business ارسال کرده.
    with get_session() as session:
        account = get_business_account_by_connection_id(session, business_connection_id)
        if account is None or not account.is_enabled:
            return

        owner_telegram_id = account.owner.telegram_user_id
        if message.from_user and message.from_user.id == owner_telegram_id:
            # این پیام را خودِ صاحب کسب‌وکار فرستاده (نه مشتری) → پردازش نشود.
            return
        if message.from_user and message.from_user.is_bot:
            return

        # Deduplication (بخش ۲۷): هر پیام فقط یک‌بار پردازش شود.
        if is_duplicate_message(
            session, account.id, message.message_id, MessageDirection.INCOMING
        ):
            return

        incoming_text = message.text or message.caption or ""

        get_or_create_customer_chat(session, account.id, message.chat.id)

        # ⏸ توقف کامل همه‌ی پاسخ‌های خودکار: قوانین، «هر پیامی به غیر از اینا» و
        # نگهبان شبانه «همه» ساکت‌اند؛ پیام مشتری فقط ثبت می‌شود (IGNORED) تا
        # Dedup و شمارش‌ها سالم بمانند.
        if account.auto_reply_paused:
            log_message(
                session,
                business_account_id=account.id,
                telegram_chat_id=message.chat.id,
                telegram_message_id=message.message_id,
                direction=MessageDirection.INCOMING,
                text=incoming_text,
                matched_rule_id=None,
                status=MessageStatus.IGNORED,
            )
            return

        # 🌙 نگهبان شبانه — برای «همه‌ی پلن‌ها» فعال است (حتی Free؛ تصمیم محصول).
        # داخل بازه‌ی شبانه: پاسخ‌گویی قوانین متوقف می‌شود و به هر مشتریِ تازه فقط
        # «یک‌بار در شب» پیام «الان بسته‌ایم» می‌رود (تا اسپم نشود). الگوی دو-فاز
        # همین پروژه رعایت می‌شود: ارسال شبکه‌ای «بیرون» از session انجام می‌شود.
        night_job: tuple[int, str, str, str] | None = None
        if account.night_guard_enabled:
            # 🌍 زمانِ نگهبان به وقتِ «منطقه‌ی انتخابی صاحب حساب» است (پیش‌فرض تهران)
            _tz = zone_for(account)
            _tz_now = utcnow().astimezone(_tz)
            today = _tz_now.strftime("%Y-%m-%d")
            minutes_now = _tz_now.hour * 60 + _tz_now.minute
            if (
                is_within_window(
                    minutes_now, account.night_start_minute, account.night_end_minute
                )
                and not night_was_sent(session, account.id, message.chat.id, today)
            ):
                # ورودی مشتری ثبت می‌شود (بدون قانون منطبق و بدون پاسخ قانون) تا
                # Dedup و شمارش‌ها درست بمانند؛ IGNORED یعنی «جواب قانونی نداشت».
                log_message(
                    session,
                    business_account_id=account.id,
                    telegram_chat_id=message.chat.id,
                    telegram_message_id=message.message_id,
                    direction=MessageDirection.INCOMING,
                    text=incoming_text,
                    matched_rule_id=None,
                    status=MessageStatus.IGNORED,
                )
                night_text = (account.night_guard_text or "").strip() or NIGHT_GUARD_DEFAULT_TEXT
                night_job = (account.id, message.chat.id, night_text, today)

        if night_job is not None:
            account_id, chat_id, night_text, night_today = night_job
        else:
            is_pro = business_account_is_pro(account)
            rules = list_rules(session, account.id, only_enabled=True)
            engine_rules = to_engine_rules(rules)

            ctx = EngineContext(
                is_pro=is_pro,
                incoming_text=incoming_text,
                rules=engine_rules,
            )
            matched = match_rule(ctx)

            # «هر پیامی به غیر از اینا» (Fallback) — کاملاً اختیاری.
            # تنها زمانی ارسال می‌شود که:
            #   ۱) هیچ قانون «برابر دقیق» و «شامل شدن» منطبق نشده باشد،
            #   ۲) کاربر این قابلیت را خودش روشن کرده باشد،
            #   ۳) و خودش متنی نوشته باشد.
            # در غیر این صورت: «بدون قانون منطبق ⇒ بدون پاسخ» (بات ساکت می‌ماند).
            fallback_text: str | None = None
            if matched is None:
                own_text = (get_customer_reply_text(session, account) or "").strip()
                if account.customer_reply_enabled and own_text:
                    fallback_text = texts.safe_format(
                        own_text,
                        name=(message.from_user.first_name if message.from_user else None)
                        or (message.from_user.username if message.from_user else None)
                        or "دوست عزیز",
                        business=(
                            account.owner.first_name or account.owner.username or "ما"
                        ),
                        support="",
                    ).strip() or None

            will_reply = matched is not None or fallback_text is not None

            log_message(
                session,
                business_account_id=account.id,
                telegram_chat_id=message.chat.id,
                telegram_message_id=message.message_id,
                direction=MessageDirection.INCOMING,
                text=incoming_text,
                matched_rule_id=matched.id if matched else None,
                status=MessageStatus.SUCCESS if will_reply else MessageStatus.IGNORED,
            )

            if matched is None:
                if fallback_text is None:
                    return
                # همان مسیر ارسالِ قانون را طی می‌کنیم، فقط با یک قانونِ موقتِ متنی
                # تا تلاشِ مجدد، ثبت لاگ و ارسال مدیا دقیقاً مثل قبل کار کند.
                # عکس‌های همراه متن (مخصوص Pro / Pro Max)
                # عکس‌های «در غیر این صورت» برای همه‌ی پلن‌ها ارسال می‌شوند
                media_items: tuple = ()
                file_ids = get_customer_reply_media(session, account)
                media_items = tuple(
                    RuleMediaItem(telegram_file_id=fid, sort_order=i)
                    for i, fid in enumerate(file_ids)
                )

                matched = EngineRule(
                    id=0,
                    trigger_type=TriggerType.EXACT,
                    trigger_value="",
                    response_text=fallback_text,
                    response_media_type=ResponseMediaType.PHOTO if media_items
                    else ResponseMediaType.NONE,
                    media_items=media_items,
                    priority=0,
                    enabled=True,
                    requires_pro=False,
                    is_system=True,
                )

        if night_job is not None:
            account_id, chat_id, night_text, night_today = night_job
        else:
            chat_id = message.chat.id
            account_id = account.id  # قبل از بسته شدن session ذخیره می‌شود (رفع DetachedInstanceError)

    # 🌙 ارسال پیام شبانه — بیرون از session (همان الگوی مسیر قوانین)؛ سپس پایان:
    # مسیر قوانین اصلاً نباید اجرا شود (در شب، جای پاسخ قانون را پیام «بسته‌ایم» می‌گیرد).
    if night_job is not None:
        away_rule = EngineRule(
            id=0,
            trigger_type=TriggerType.EXACT,
            trigger_value="",
            response_text=night_text,
            response_media_type=ResponseMediaType.NONE,
            media_items=(),
            priority=0,
            enabled=True,
            requires_pro=False,
            is_system=True,
        )
        sent_message_id: int | None = None
        status = MessageStatus.FAILED
        for attempt in range(1, 4):
            try:
                sent_message_id = await send_rule_response(
                    context=context,
                    business_connection_id=business_connection_id,
                    chat_id=chat_id,
                    rule=away_rule,
                )
                status = MessageStatus.SUCCESS
                break
            except Exception:
                if attempt == 3:
                    logger.exception(
                        "Failed to send night-guard message after 3 attempts (business_account_id=%s, chat_id=%s)",
                        account_id,
                        chat_id,
                    )
                else:
                    logger.warning("Night-guard send attempt %d/3 failed, retrying...", attempt)
                    await asyncio.sleep(attempt * 0.75)

        with get_session() as session:
            # فقط در صورت ارسال موفق «امشب فرستادیم» ثبت می‌شود؛ در صورت شکست،
            # پیام بعدی همان مشتری دوباره تلاش می‌کند (هیچ‌وقت بی‌پیام نمی‌ماند).
            if sent_message_id is not None:
                night_mark_sent(session, account_id, chat_id, night_today)
            log_message(
                session,
                business_account_id=account_id,
                telegram_chat_id=chat_id,
                telegram_message_id=sent_message_id or message.message_id,
                direction=MessageDirection.OUTGOING,
                text=away_rule.response_text,
                matched_rule_id=None,
                status=status,
            )
        return

    # ارسال پاسخ خارج از session (برای جلوگیری از نگه‌داشتن Connection حین I/O شبکه).
    #
    # نکته مهم (رفع یک باگ واقعی قابلیت‌اطمینان): خطاهای شبکه‌ای گذرا (مثلاً
    # httpx.ReadError/NetworkError — دقیقاً چیزی که در محیط واقعی این پروژه هم رخ
    # داده) قبلاً بدون هیچ تلاش مجددی مستقیم FAILED لاگ می‌شدند و مشتری برای همیشه
    # بدون پاسخ می‌ماند، چون این‌جور خطاها معمولاً لحظه‌ای هستند و چند صدم ثانیه بعد
    # برطرف می‌شوند. حالا حداکثر ۳ بار (با کمی مکث افزایشی بین هر تلاش) امتحان می‌شود.
    sent_message_id: int | None = None
    status = MessageStatus.FAILED
    max_attempts = 3
    for attempt in range(1, max_attempts + 1):
        try:
            sent_message_id = await send_rule_response(
                context=context,
                business_connection_id=business_connection_id,
                chat_id=chat_id,
                rule=matched,
            )
            status = MessageStatus.SUCCESS
            break
        except Exception:
            if attempt == max_attempts:
                logger.exception(
                    "Failed to send rule response after %d attempts (business_account_id=%s, chat_id=%s)",
                    max_attempts,
                    account_id,
                    chat_id,
                )
            else:
                logger.warning(
                    "Send attempt %d/%d failed, retrying...", attempt, max_attempts
                )
                await asyncio.sleep(attempt * 0.75)

    with get_session() as session:
        log_message(
            session,
            business_account_id=account_id,
            telegram_chat_id=chat_id,
            # اگر ارسال ناموفق بود (sent_message_id=None) از incoming message_id به‌عنوان
            # کلید یکتای موقت استفاده می‌شود تا Dedup به‌هم نریزد؛ در حالت موفق، شناسه
            # واقعی پیام خروجی ثبت می‌شود.
            telegram_message_id=sent_message_id or message.message_id,
            direction=MessageDirection.OUTGOING,
            text=matched.response_text,
            matched_rule_id=matched.id,
            status=status,
        )
