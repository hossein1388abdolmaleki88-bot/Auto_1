"""بررسی عضویت اجباری پیش از اجازه استفاده از منوی اصلی ربات (بخش ۱۰)."""
from __future__ import annotations

import logging

from telegram import Update
from telegram.ext import ContextTypes

from app import keyboards, texts
from app.models import ForceJoinChannel
from app.database import get_session
from app.repository import is_force_join_enabled, list_force_join_channels
from app.services.force_join_service import check_all_memberships

logger = logging.getLogger(__name__)


async def _ensure_invite_links(
    context: ContextTypes.DEFAULT_TYPE, channels: list[ForceJoinChannel]
) -> None:
    """برای کانال‌هایی که لینک دعوت ندارند (معمولاً کانال‌های عددی/خصوصی)، یک
    لینک دعوت واقعی از API تلگرام می‌گیرد و در دیتابیس ذخیره می‌کند تا دکمه‌ی
    عضویت همیشه به یک آدرس معتبر برسد. اگر بات ادمین کانال نباشد یا خطایی رخ
    بدهد، بی‌صدا رد می‌شود (در این صورت آن کانال دکمه نمی‌گیرد)."""
    need = [
        ch
        for ch in channels
        if not (ch.invite_link or "").strip()
        and not (ch.channel_id or "").strip().startswith("@")
    ]
    if not need:
        return

    created = {}
    for ch in need:
        try:
            link = await context.bot.create_chat_invite_link(chat_id=int(ch.channel_id))
        except Exception:
            logger.warning("Could not create invite link for channel %s", ch.channel_id)
            continue
        if link is not None and getattr(link, "invite_link", None):
            created[ch.id] = link.invite_link

    if not created:
        return
    with get_session() as session:
        for channel_id, invite_link in created.items():
            ch = session.get(ForceJoinChannel, channel_id)
            if ch is not None:
                ch.invite_link = invite_link


async def ensure_membership_or_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """
    اگر Force Join فعال باشد و کاربر عضو همه کانال‌ها نباشد، پیام عضویت اجباری نمایش
    داده و False برمی‌گرداند (یعنی جریان عادی باید متوقف شود).
    در غیر این‌صورت True برمی‌گرداند.
    """
    with get_session() as session:
        if not is_force_join_enabled(session):
            return True
        channels = list_force_join_channels(session, only_enabled=True)
        if not channels:
            return True

    tg_user = update.effective_user
    is_member, not_joined = await check_all_memberships(context.bot, channels, tg_user.id)
    if is_member:
        return True

    message = update.effective_message
    # کانال‌ها به‌صورت «دکمه» نمایش داده می‌شوند (نه لینک متنی داخل پیام)
    await _ensure_invite_links(context, not_joined)
    if not_joined:
        await message.reply_text(
            texts.FORCE_JOIN_PROMPT,
            reply_markup=keyboards.force_join_channels_inline_keyboard(not_joined),
        )
    await message.reply_text(
        texts.FORCE_JOIN_CHECK_HINT, reply_markup=keyboards.force_join_keyboard()
    )
    return False


async def force_join_check_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    with get_session() as session:
        channels = list_force_join_channels(session, only_enabled=True)

    tg_user = update.effective_user
    is_member, not_joined = await check_all_memberships(context.bot, channels, tg_user.id)

    if is_member:
        await update.effective_message.reply_text(texts.FORCE_JOIN_SUCCESS)
        from app.handlers.user_handlers import show_main_menu

        await show_main_menu(update, context)
    else:
        await _ensure_invite_links(context, not_joined)
        if not_joined:
            await update.effective_message.reply_text(
                texts.FORCE_JOIN_NOT_COMPLETE,
                reply_markup=keyboards.force_join_channels_inline_keyboard(not_joined),
            )
        await update.effective_message.reply_text(
            texts.FORCE_JOIN_CHECK_HINT, reply_markup=keyboards.force_join_keyboard()
        )
