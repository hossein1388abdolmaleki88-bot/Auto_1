"""
Rule Engine — کاملاً مستقل از Telegram و از ORM.

طبق بخش ۱۶ Specification:
    Input:  business_account, customer_chat, incoming_message
    Output: matched_rule یا None

ترتیب بررسی:
    1. EXACT
    2. CONTAINS
    (در هر مرحله، Ruleهای با priority بزرگ‌تر زودتر بررسی می‌شوند)

فقط Ruleهای enabled و مجاز برای پلن فعلی (is_pro) بررسی می‌شوند.
اگر هیچ Ruleای Match نشد → matched_rule=None برگردانده می‌شود و هیچ پاسخی نباید ارسال شود.

این ماژول عمداً به SQLAlchemy یا python-telegram-bot وابسته نیست تا بتوان آن را
مستقل و بدون هیچ dependency خارجی تست کرد (به همین دلیل به‌جای مدل‌های ORM از
dataclass استفاده شده است). لایه‌ی repository مسئول تبدیل ردیف‌های دیتابیس به
این dataclassها پیش از فراخوانی Engine است.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from app import texts


class TriggerType(str, Enum):
    EXACT = "EXACT"
    CONTAINS = "CONTAINS"


class ResponseMediaType(str, Enum):
    NONE = "NONE"
    PHOTO = "PHOTO"
    MULTIPLE_PHOTOS = "MULTIPLE_PHOTOS"
    TEXT_AND_PHOTOS = "TEXT_AND_PHOTOS"


@dataclass(frozen=True)
class RuleMediaItem:
    telegram_file_id: str
    sort_order: int = 0


@dataclass(frozen=True)
class EngineRule:
    """نمایش سبک‌وزن یک Rule برای مصرف داخل Rule Engine."""

    id: int
    trigger_type: TriggerType
    trigger_value: str | None
    response_text: str | None
    response_media_type: ResponseMediaType
    media_items: tuple[RuleMediaItem, ...] = field(default_factory=tuple)
    priority: int = 0
    enabled: bool = True
    requires_pro: bool = True
    is_system: bool = False


@dataclass(frozen=True)
class EngineContext:
    """اطلاعات لازم برای اجرای Rule Engine روی یک پیام ورودی."""

    is_pro: bool
    incoming_text: str
    rules: tuple[EngineRule, ...]


def _normalize(text: str) -> str:
    """
    نرمال‌سازی متن برای مقایسه‌ی EXACT/CONTAINS.

    رفع یک باگ واقعی و بسیار رایج در متن فارسی: حروف عربیِ «ي» (U+064A) و «ك»
    (U+0643) از نظر ظاهری تقریباً با معادل فارسی‌شان «ی» (U+06CC) و «ک»
    (U+06A9) یکسان دیده می‌شوند، ولی از نظر کد یونیکد کاملاً متفاوت‌اند. خیلی
    از کیبوردهای گوشی (به‌خصوص iOS، یا کیبورد عربی) پیش‌فرض کاراکتر عربی را
    تایپ می‌کنند، در حالی که صاحب کسب‌وکار موقع ساخت Rule با کیبورد فارسی
    استاندارد تایپ کرده — نتیجه این بود که پیام مشتری با چشم دقیقاً همان
    عبارتِ Rule را داشت، ولی چون کدِ حروف فرق داشت، CONTAINS/EXACT تطبیق پیدا
    نمی‌کرد و به‌جایش پاسخ پیش‌فرض/عمومی ارسال می‌شد.

    علاوه بر این، ZWNJ (نیم‌فاصله، خیلی رایج در تایپ فارسی: مثلاً «می‌خواهم»)
    و انواع فاصله‌ی یونیکدی دیگر هم به فاصله‌ی معمولی نگاشت می‌شوند تا تفاوت
    نیم‌فاصله باعث عدم تطابق نشود، و چند فاصله‌ی پشت‌سرهم به یکی کاهش می‌یابد.
    """
    # کاراکترهای عربی → معادل استاندارد فارسی
    text = text.replace("ي", "ی").replace("ك", "ک")
    # ZWNJ (نیم‌فاصله، U+200C) و ZWSP (U+200B) → فاصله‌ی معمولی
    text = text.replace("\u200c", " ").replace("\u200b", " ")
    # چند فاصله‌ی پشت‌سرهم (که همین جایگزینی‌های بالا هم ممکن است ایجاد کند) → یک فاصله
    text = " ".join(text.split())
    return text.strip().lower()


def _rule_allowed(rule: EngineRule, is_pro: bool) -> bool:
    """آیا این Rule مجاز به اجرا است؟

    منطق قبلی (`rule.requires_pro and not is_pro → رد`) یک باگِ واقعی و
    بسیار گیج‌کننده ایجاد می‌کرد: هر Ruleای که کاربر در زمان Pro می‌ساخت
    (یا در نسخه‌های قدیمی‌تر که مقدار پیش‌فرض ستون `requires_pro` برابر True
    بود) بعداً روی حساب Free کاملاً نادیده گرفته می‌شد — در حالی که در پنل
    کاربر نمایش داده می‌شد. نتیجه: کاربر قانون می‌ساخت، قانون در فهرست بود،
    ولی هیچ‌وقت اجرا نمی‌شد و پیامِ عمومی جای آن را می‌گرفت.

    تصمیم جدید (ساده، قابل پیش‌بینی و همان چیزی که کاربر انتظار دارد):
    «هر قانونی که در پنل فعال است، اجرا می‌شود». محدودیتِ تعداد قانون هم
    همان‌طور که بود در زمانِ ساخت اعمال می‌شود (سقف پلن)، نه در زمان اجرا.

    یادداشت: پارامتر is_pro نگه داشته شده تا تغییرِ امضا باعث شکستنِ
    فراخوانی‌ها نشود؛ اکنون فقط برای خواناییِ آینده استفاده می‌شود.
    """
    del is_pro  # عمداً استفاده نمی‌شود (توضیح در docstring)
    return bool(rule.enabled)


def _sorted_by_priority(rules: list[EngineRule]) -> list[EngineRule]:
    # priority بزرگ‌تر = اولویت بالاتر؛ در تساوی، ترتیب id برای پایداری (deterministic) حفظ می‌شود.
    return sorted(rules, key=lambda r: (-r.priority, r.id))


def match_rule(ctx: EngineContext) -> EngineRule | None:
    """
    قانون منطبق با پیام ورودی را طبق ترتیب مشخص‌شده در Specification برمی‌گرداند.
    اگر هیچ Ruleای منطبق نشد، None برمی‌گرداند.
    """
    allowed_rules = [r for r in ctx.rules if _rule_allowed(r, ctx.is_pro)]

    normalized_incoming = _normalize(ctx.incoming_text)

    # مرحله ۱: EXACT
    exact_rules = _sorted_by_priority(
        [
            r
            for r in allowed_rules
            if r.trigger_type == TriggerType.EXACT
            and r.trigger_value is not None
            and _normalize(r.trigger_value) == normalized_incoming
        ]
    )
    if exact_rules:
        return exact_rules[0]

    # مرحله ۲: CONTAINS
    contains_rules = _sorted_by_priority(
        [
            r
            for r in allowed_rules
            if r.trigger_type == TriggerType.CONTAINS
            and r.trigger_value is not None
            and _normalize(r.trigger_value) in normalized_incoming
        ]
    )
    if contains_rules:
        return contains_rules[0]

    return None


# Rule داخلی رایگان (بخش ۱۷ Specification) — قابل حذف یا ویرایش توسط کاربر Free نیست.
FREE_DEFAULT_RULE = EngineRule(
    id=0,
    trigger_type=TriggerType.EXACT,
    trigger_value="سلام",
    response_text=texts.DEFAULT_SALAM_RESPONSE,
    response_media_type=ResponseMediaType.NONE,
    priority=0,
    enabled=True,
    requires_pro=False,
    is_system=True,
)
