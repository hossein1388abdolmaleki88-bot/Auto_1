"""
بارگذاری تنظیمات پروژه از متغیرهای محیطی (ENV).
هیچ مقدار حساسی (توکن، رمز) نباید Hard-Code شود؛ همه از .env خوانده می‌شوند.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

# مسیر ریشه پروژه (پوشه‌ای که app/ داخلش است) — صرف‌نظر از اینکه پردازش از کجا
# اجرا شده (Current Working Directory). این برای ساخت مسیر پیش‌فرض دیتابیس لازم
# است؛ در غیر این‌صورت هر بار که بات از یک پوشه/روش متفاوت اجرا شود (مثلاً در
# Pydroid یا هر اجراکننده دیگری که cwd ثابتی ندارد)، یک فایل app.db خالیِ *جدید*
# در یک مسیر متفاوت ساخته می‌شد و کل دیتابیس (کاربران، قوانین، اشتراک‌ها) از
# دید بات گم می‌شد — نه اینکه واقعاً پاک شود، فقط فایل درست پیدا نمی‌شد.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
_DEFAULT_DB_PATH = PROJECT_ROOT / "app.db"

load_dotenv(PROJECT_ROOT / ".env")

# ⚠️ مقادیر پیش‌فرض داخل کد (به درخواست صریح صاحب پروژه):
# اگر .env یا متغیر محیطی موجود باشد همان اولویت دارد؛ این‌ها فقط جایگزین
# نبودنشان هستند. توجه: توکن داخل سورس = ریسک امنیتی — اگر ریپو عمومی است،
# بعد از هر اشتراک‌گذاری توکن را از BotFather ریوک کنید.
BOT_TOKEN_DEFAULT = "8809217484:AAGcNUqEts1etyRn6RPSpmStppqn_AmCAMs"
ADMIN_IDS_DEFAULT = "6816275778"
ADMIN_USERNAME_DEFAULT = "Hovssin"


def _get_bool(name: str, default: bool = False) -> bool:
    val = os.getenv(name)
    if val is None:
        return default
    return val.strip().lower() in {"1", "true", "yes", "on"}


def _get_int_list(name: str, default: str = "") -> list[int]:
    raw = os.getenv(name, default)
    result = []
    for part in raw.split(","):
        part = part.strip()
        if part:
            try:
                result.append(int(part))
            except ValueError:
                pass
    return result


@dataclass(frozen=True)
class Settings:
    bot_token: str = field(default_factory=lambda: os.getenv("BOT_TOKEN", BOT_TOKEN_DEFAULT))
    database_url: str = field(
        default_factory=lambda: os.getenv("DATABASE_URL", f"sqlite:///{_DEFAULT_DB_PATH}")
    )
    secret_key: str = field(default_factory=lambda: os.getenv("SECRET_KEY", "change-me"))

    telegram_mode: str = field(default_factory=lambda: os.getenv("TELEGRAM_MODE", "polling"))
    webhook_url: str = field(default_factory=lambda: os.getenv("TELEGRAM_WEBHOOK_URL", ""))
    webhook_secret: str = field(
        default_factory=lambda: os.getenv("TELEGRAM_WEBHOOK_SECRET", "")
    )
    webhook_listen: str = field(default_factory=lambda: os.getenv("WEBHOOK_LISTEN", "0.0.0.0"))
    webhook_port: int = field(default_factory=lambda: int(os.getenv("WEBHOOK_PORT", "8443")))

    admin_telegram_ids: list[int] = field(
        default_factory=lambda: _get_int_list("ADMIN_TELEGRAM_IDS", ADMIN_IDS_DEFAULT)
    )
    admin_username: str = field(
        default_factory=lambda: os.getenv("ADMIN_USERNAME", ADMIN_USERNAME_DEFAULT)
    )

    default_pro_price: int = field(default_factory=lambda: int(os.getenv("DEFAULT_PRO_PRICE", "250000")))
    default_pro_duration_days: int = field(
        default_factory=lambda: int(os.getenv("DEFAULT_PRO_DURATION_DAYS", "30"))
    )

    def validate(self) -> list[str]:
        """اعتبارسنجی حداقلی تنظیمات. لیست خطاها را برمی‌گرداند (خالی یعنی سالم)."""
        errors = []
        if not self.bot_token:
            errors.append("BOT_TOKEN تنظیم نشده است.")
        if not self.admin_telegram_ids:
            errors.append(
                "ADMIN_TELEGRAM_IDS تنظیم نشده است — هیچ‌کس دسترسی پنل ادمین نخواهد داشت."
            )
        if self.telegram_mode not in {"polling", "webhook"}:
            errors.append("TELEGRAM_MODE باید 'polling' یا 'webhook' باشد.")
        if self.telegram_mode == "webhook" and not self.webhook_url:
            errors.append("در حالت webhook باید TELEGRAM_WEBHOOK_URL تنظیم شود.")
        return errors


settings = Settings()
