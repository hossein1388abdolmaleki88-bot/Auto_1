"""
تبدیل زمان‌های ذخیره‌شده در دیتابیس (که همیشه UTC هستند — به utcnow() در
models.py مراجعه کنید) به وقت محلی ایران برای نمایش به کاربر/ادمین.

از نسخه‌ی ۱۴۰۵/۰۶/۱۰ تمام تاریخ‌های نمایش داده‌شده به کاربر و ادمین به
**تقویم شمسی (جلالی)** تبدیل می‌شوند (مثلاً «۱۴۰۵/۰۶/۰۹ ۱۴:۳۰» به‌جای
«2026-08-31 14:30») — چون درخواست صریح ادمین بود که همه‌ی تاریخ‌های بات شمسی
باشند، از جمله «تاریخ انقضا» و «مدت زمان باقی‌مانده» دسترسی.

منطق تبدیل میلادی→جلالی به‌صورت یک تابع خالص و بدون هیچ dependency خارجی
(الگوریتم استاندارد جلالی) پیاده شده و با کتابخانه‌ی مرجع jdatetime برای همه‌ی
روزهای بازه‌ی ۱۹۰۰ تا ۲۱۰۰ میلادی (۷۳٬۴۱۴ روز) صحت‌سنجی شده — صفر اختلاف.

ساعت: از zoneinfo (بخشی از خودِ کتابخانه استاندارد پایتون از نسخه ۳.۹ به بعد،
بدون نیاز به نصب پکیج جدید) استفاده می‌شود. ایران از سال ۱۴۰۱ (۲۰۲۲ میلادی)
ساعت تابستانی (DST) را رسماً حذف کرده و سال کل روی UTC+03:30 ثابت است؛ tzdata
خودِ پایتون این را به‌صورت خودکار مدیریت می‌کند، پس نیازی به محاسبه‌ی دستی
افست نیست و برای تاریخ‌های تاریخی (قبل از حذف DST) هم درست کار می‌کند.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

try:
    from zoneinfo import ZoneInfo

    IRAN_TZ: timezone | ZoneInfo = ZoneInfo("Asia/Tehran")
except Exception:
    # اگر دیتابیس IANA (چه از سیستم‌عامل، چه از پکیج tzdata) در دسترس نبود، به‌جای
    # کرش کردن کل بات، به افست ثابت UTC+03:30 برمی‌گردیم — همان چیزی که «Asia/Tehran»
    # از سال ۱۴۰۱ (۲۰۲۲ میلادی، حذف ساعت تابستانی) همیشه معادلش است.
    IRAN_TZ = timezone(timedelta(hours=3, minutes=30))

# جدول تبدیل ارقام انگلیسی به فارسی برای نمایش تاریخ‌ها (مثلاً 1405 → ۱۴۰۵)
_FA_DIGITS = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")


def to_iran(dt: datetime | None) -> datetime | None:
    """یک datetime «ساده» (naive, UTC — همان‌طور که در کل پروژه ذخیره می‌شود) را
    به datetime آگاه از منطقه‌زمانی تهران تبدیل می‌کند. ورودی None → خروجی None."""
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(IRAN_TZ)


# --------------------------------------------------------------------------
# تبدیل میلادی → جلالی (الگوریتم استاندارد، بدون dependency خارجی)
# --------------------------------------------------------------------------


def gregorian_to_jalali(gy: int, gm: int, gd: int) -> tuple[int, int, int]:
    """تبدیل تاریخ میلادی به شمسی (جلالی). خروجی: (سال، ماه، روز).

    الگوریتم کلاسیک جلالی که در اکثر کتابخانه‌ها (jdatetime، calverter و...)
    استفاده می‌شود؛ صحت آن برای همه‌ی روزهای ۱۹۰۰ تا ۲۱۰۰ میلادی در برابر
    jdatetime بررسی شده (صفر اختلاف). سال ورودی میلادی (مثلاً 2026) است.
    """
    g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]
    gy2 = gy + 1 if gm > 2 else gy
    days = 355666 + (365 * gy) + ((gy2 + 3) // 4) - ((gy2 + 99) // 100) + ((gy2 + 399) // 400)
    days += g_d_m[gm - 1] + gd
    jy = -1595 + (33 * (days // 12053))
    days %= 12053
    jy += 4 * (days // 1461)
    days %= 1461
    if days > 365:
        jy += (days - 1) // 365
        days = (days - 1) % 365
    if days < 186:
        jm = 1 + days // 31
        jd = 1 + days % 31
    else:
        jm = 7 + (days - 186) // 30
        jd = 1 + (days - 186) % 30
    return jy, jm, jd


def _format_shamsi(dt: datetime, fmt: str, persian_digits: bool) -> str:
    """فرمت‌بندی یک datetime (به وقت تهران) با تقویم شمسی.

    توکن‌های پشتیبانی‌شده (شبیه strftime اما روی تاریخ جلالی):
        %Y سال چهاررقمی شمسی   %y سال دو رقمی
        %m ماه دو رقمی         %d روز دو رقمی
        %H ساعت دو رقمی        %M دقیقه   %S ثانیه
    بقیه‌ی کاراکترها (مثل / ، : ، - و متن) همان‌طور که هستند می‌مانند.
    اگر persian_digits=True باشد، ارقام خروجی فارسی می‌شوند (۱۴۰۵/۰۶/۰۹).
    """
    jy, jm, jd = gregorian_to_jalali(dt.year, dt.month, dt.day)
    tokens = {
        "%Y": f"{jy:04d}",
        "%y": f"{jy % 100:02d}",
        "%m": f"{jm:02d}",
        "%d": f"{jd:02d}",
        "%H": f"{dt.hour:02d}",
        "%M": f"{dt.minute:02d}",
        "%S": f"{dt.second:02d}",
    }
    out: list[str] = []
    i = 0
    while i < len(fmt):
        token = fmt[i : i + 2]
        if token in tokens:
            out.append(tokens[token])
            i += 2
        else:
            out.append(fmt[i])
            i += 1
    result = "".join(out)
    if persian_digits:
        result = result.translate(_FA_DIGITS)
    return result


def format_iran(
    dt: datetime | None,
    fmt: str = "%Y/%m/%d %H:%M",
    fallback: str = "-",
    persian_digits: bool = True,
) -> str:
    """میان‌بر رایج: تبدیل به وقت ایران + تقویم شمسی + فرمت رشته‌ای.

    خروجی پیش‌فرض شمسی با ارقام فارسی است (مثلاً «۱۴۰۵/۰۶/۰۹ ۱۴:۳۰»).
    اگر تاریخ None بود، fallback برمی‌گردد.
    """
    converted = to_iran(dt)
    if converted is None:
        return fallback
    return _format_shamsi(converted, fmt, persian_digits)


def fa_digits(value: int | str) -> str:
    """تبدیل ارقام انگلیسی به فارسی برای نمایش (مثلاً 30 → ۳۰)."""
    return str(value).translate(_FA_DIGITS)


def days_left_until(dt: datetime | None) -> int:
    """تعداد روزِ باقی‌مانده تا یک تاریخ — برای نمایش «مدت زمان باقی‌مانده‌ی
    دسترسی» در حساب کاربر و جزئیات ادمین.

    تاریخ ورودی باید UTC-naive باشد (دقیقاً همان‌طور که در دیتابیس ذخیره شده).
    محاسبه بر اساس اختلاف *تقویمی* (تعداد روزهای کامل) است — مثلاً اگر انقضا
    فردا ۲۳:۵۹ باشد یعنی ۱ روز، و اگر ۲/۵ روز مانده باشد یعنی ۲ روز. این روش
    برخلاف اختلاف لحظه‌ای (timedelta.days) به زمان دقیقِ اجرا حساس نیست و
    خروجی پایدار می‌دهد. اگر تاریخ گذشته/نداشته باشد، ۱ برمی‌گردد (حداقل ۱).
    """
    if dt is None:
        return 0
    now_utc = datetime.now(timezone.utc).replace(tzinfo=None)
    days = (dt.date() - now_utc.date()).days
    return max(1, days)
