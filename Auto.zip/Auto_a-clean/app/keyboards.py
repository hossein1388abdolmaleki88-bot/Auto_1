"""
سازنده‌های Reply Keyboard.

طبق درخواست کاربر، دکمه‌ها باید در کیبورد پایین صفحه (Reply Keyboard) باشند نه
زیر پیام (Inline Keyboard)، طوری که وقتی کاربر «بازگشت» می‌زند، دکمه‌های سطح
قبلی دوباره ظاهر شوند.

محدودیت مهم Telegram API: KeyboardButton (بر خلاف InlineKeyboardButton) نمی‌تواند
لینک (url) داشته باشد. برای لینک‌هایی مثل «عضویت در کانال» یا «چت با ادمین»، لینک
به‌صورت متن قابل‌کلیک (Telegram خودش لینک‌های t.me را Auto-Link می‌کند) داخل پیام
نوشته می‌شود؛ دکمه‌ها فقط برای اکشن‌های داخلی بات (بررسی مجدد، بازگشت و غیره)
استفاده می‌شوند.

هر دکمه‌ی دارای شناسه‌ی پویا (مثل ردیف‌های Rule یا کاربر) با پیشوند "#<id> "
ساخته می‌شود تا در روتر پیام‌های متنی بتوان id را استخراج کرد.
"""
from __future__ import annotations

import inspect
import re

from telegram import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
)

from app import texts
from app.models import BusinessAccount, ForceJoinChannel, Rule

_ID_PATTERN = re.compile(r"#(\d+)")


def extract_id(text: str) -> int | None:
    """استخراج شناسه عددی از برچسب دکمه‌های پویا (مثل '🟢 #12 CONTAINS: کرج')."""
    match = _ID_PATTERN.search(text)
    if not match:
        return None
    return int(match.group(1))


# ─────────────────────────────────────────────────────────────
#  رنگ دکمه‌ها (Bot API 9.4 / Telegram بعد از ۹ فوریه ۲۰۲۶)
# ─────────────────────────────────────────────────────────────
# سه رنگ در دسترس است:
#   primary (آبی)  → اقدام اصلی و پیش‌فرضِ هر صفحه
#   success (سبز)  → اقدام مثبت / تأیید / ساخت چیز جدید
#   danger  (قرمز) → اقدام خطرناک، حذف یا انصراف
# کلاینت‌های قدیمی‌تر رنگ را نادیده می‌گیرند و دکمه عادی می‌بینند؛
# یعنی این تغییر روی هیچ نسخه‌ای خرابی ایجاد نمی‌کند.
PRIMARY = "primary"
SUCCESS = "success"
DANGER = "danger"

# python-telegram-bot از نسخه‌ی ۲۲.۷ پارامتر style را به‌صورت بومی دارد؛ روی
# نسخه‌های قدیمی‌تر همان مقدار از طریق api_kwargs به API فرستاده می‌شود.
try:
    _STYLE_SUPPORTED = "style" in inspect.signature(KeyboardButton.__init__).parameters
except (TypeError, ValueError):  # pragma: no cover
    _STYLE_SUPPORTED = False


# نقشه‌ی رنگِ هر دکمه. هر دکمه‌ای اینجا نباشد، «بی‌رنگ» (خنثی) می‌ماند.
# نقشه‌ی رنگِ هر دکمه (نام ثابت در texts.py → رنگ).
# هر دکمه‌ای اینجا نباشد، «بی‌رنگ» (خنثی) می‌ماند. از getattr استفاده
# می‌شود تا اگر ثابتی در نسخه‌ای وجود نداشت، خطا رخ ندهد.
_BTN_STYLE_RULES: list[tuple[str, str | None]] = [
    ("BTN_CONNECT", PRIMARY),
    ("BTN_BUY_PRO", SUCCESS),
    ("BTN_CONTACT_ADMIN", PRIMARY),
    ("BTN_ADMIN_PANEL", PRIMARY),
    ("BTN_MANAGE_RULES", None),
    ("BTN_ACCOUNT", None),
    ("BTN_HELP", None),
    ("BTN_BACK_TO_MENU", None),
    ("BTN_CANCEL", DANGER),
    ("BTN_PHOTOS_DONE", SUCCESS),
    ("BTN_FORCE_JOIN_CHECK", SUCCESS),
    ("BTN_RULE_ADD", SUCCESS),
    ("BTN_RULE_TOGGLE", None),
    ("BTN_RULE_DELETE", DANGER),
    ("BTN_RULE_TEST", PRIMARY),
    ("BTN_RULE_COPY", None),
    ("BTN_NIGHT_GUARD", PRIMARY),
    ("BTN_RULES_PAUSE_ALL", DANGER),
    ("BTN_RULES_RESUME_ALL", SUCCESS),
    ("BTN_NIGHT_ON", SUCCESS),
    ("BTN_NIGHT_TZ", PRIMARY),
    ("BTN_NIGHT_OFF", DANGER),
    ("BTN_NIGHT_DEFAULT_TEXT", DANGER),
    ("BTN_BACK_TO_RULES", None),
    ("BTN_FREE_HELLO_RULE_ON", None),
    ("BTN_FREE_HELLO_RULE_OFF", None),
    ("BTN_SALAM_SET_FA", SUCCESS),
    ("BTN_SALAM_SET_EN", SUCCESS),
    ("BTN_SALAM_TURN_OFF", DANGER),
    ("BTN_TRIGGER_EXACT", None),
    ("BTN_TRIGGER_CONTAINS", None),
    ("BTN_ADMIN_ACTIVATE_PRO", SUCCESS),
    ("BTN_ADMIN_RENEW_PRO", SUCCESS),
    ("BTN_ADMIN_CANCEL_PRO", DANGER),
    ("BTN_ADMIN_DELETE_USER", DANGER),
    ("BTN_ADMIN_DELETE_USER_CONFIRM", DANGER),
    ("BTN_ADMIN_BROADCAST_SEND", SUCCESS),
    ("BTN_ADMIN_BROADCAST_CANCEL", DANGER),
    ("BTN_ADMIN_BACK", None),
    ("BTN_ADMIN_EDIT_CONNECT_TEXT", None),
    ("BTN_FALLBACK_REPLY", None),
    ("BTN_FALLBACK_EDIT", PRIMARY),
    ("BTN_FALLBACK_TOGGLE_ON", SUCCESS),
    ("BTN_FALLBACK_TOGGLE_OFF", DANGER),
    ("BTN_FALLBACK_RESET", DANGER),
    ("BTN_FALLBACK_PHOTOS", None),
    ("BTN_FALLBACK_PHOTOS_CLEAR", DANGER),
    ("BTN_ADMIN_RESET_CONNECT_TEXT", DANGER),
    ("BTN_ADMIN_CLEAR_CUSTOMER_REPLIES", DANGER),
    ("BTN_ADMIN_CLEAR_CONFIRM", DANGER),
    ("BTN_ADMIN_CLEAR_CANCEL", None),
]

BTN_STYLES: dict[str, str | None] = {
    value: style
    for value, style in ((getattr(texts, name, None), st) for name, st in _BTN_STYLE_RULES)
    if value is not None
}


def _classify_style(text: str) -> str | None:
    """اگر دکمه در نقشه نبود، بر اساس شکلکِ اولش حدس می‌زنیم."""
    if text in BTN_STYLES:
        return BTN_STYLES[text]
    if text.startswith(("🗑", "❌")):
        return DANGER
    if text.startswith(("✅", "➕")):
        return SUCCESS
    return None


def _make_button(spec) -> KeyboardButton:
    """ساخت دکمه از یک رشته ('متن') یا تاپل ('متن', 'رنگ')."""
    if isinstance(spec, tuple):
        label, style = spec
    else:
        label, style = spec, None
    style = style or _classify_style(label)
    if style and _STYLE_SUPPORTED:
        return KeyboardButton(label, style=style)
    if style:
        return KeyboardButton(label, api_kwargs={"style": style})
    return KeyboardButton(label)


def _kb(rows) -> ReplyKeyboardMarkup:
    """ساخت کیبورد؛ هر خانه می‌تواند رشته یا تاپلِ (متن، رنگ) باشد."""
    return ReplyKeyboardMarkup(
        [[_make_button(spec) for spec in row] for row in rows], resize_keyboard=True
    )


def _inline_button(label: str, url: str | None = None, style: str | None = None) -> InlineKeyboardButton:
    """ساخت دکمه‌ی اینلاین (برای لینک‌هایی که باید «دکمه» باشند نه متنِ لینک)."""
    if style and _STYLE_SUPPORTED:
        return InlineKeyboardButton(label, url=url, style=style)
    if style:
        return InlineKeyboardButton(label, url=url, api_kwargs={"style": style})
    return InlineKeyboardButton(label, url=url)


def _inline_kb(rows) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [[_inline_button(label, url, style) for (label, url, style) in row] for row in rows]
    )


def main_menu_keyboard(has_business_account: bool, is_admin: bool) -> ReplyKeyboardMarkup:
    """
    دکمه‌ی «🔗 اتصال اکانت تلگرام» فقط وقتی نمایش داده می‌شود که کاربر اکانت
    Business متصلِ *فعالی* نداشته باشد (اکانت قطع‌شده در مهلت بازیابی هم به‌عنوان
    «بدون اتصال» حساب می‌شود تا کاربر بتواند دوباره وصل شود). برای کاربری که
    متصل است، «مدیریت قوانین» نمایش داده می‌شود — Free هم می‌تواند قانون رایگان
    «سلام» را فعال/غیرفعال کند و هم (تا سقف مجاز خودش) قانون اختصاصی بسازد.
    """
    if has_business_account:
        rows = [
            [texts.BTN_BUY_PRO, texts.BTN_ACCOUNT],
            [texts.BTN_HELP, texts.BTN_MANAGE_RULES],
        ]
    else:
        rows = [
            [texts.BTN_CONNECT, texts.BTN_BUY_PRO],
            [texts.BTN_ACCOUNT, texts.BTN_HELP],
        ]
    rows.append([texts.BTN_CONTACT_ADMIN])
    if is_admin:
        rows.append([texts.BTN_ADMIN_PANEL])
    return _kb(rows)


def buy_plan_choice_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_PLAN_PRO, texts.BTN_PLAN_PRO_MAX], [texts.BTN_BACK_TO_MENU]])


def pricing_duration_option_label(duration_days: int, price: int, pricing_id: int) -> str:
    # استثنا (خواسته‌ی صاحب ربات): قیمت‌های Pro/Pro Max تک‌زبانه می‌مانند.
    return f"{duration_days} روز — {price:,} تومان #{pricing_id}"


def buy_duration_keyboard(options: list) -> ReplyKeyboardMarkup:
    """options: list[PricingPlan] (فقط enabled) برای پلن انتخاب‌شده."""
    rows = [[pricing_duration_option_label(opt.duration_days, opt.price, opt.id)] for opt in options]
    rows.append([texts.BTN_BACK_TO_MENU])
    return _kb(rows)


def back_to_menu_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_BACK_TO_MENU]])


def cancel_only_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_CANCEL]])


def force_join_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_FORCE_JOIN_CHECK]])


def force_join_channels_inline_keyboard(channels) -> InlineKeyboardMarkup:
    """هر کانالِ عضویت اجباری به‌صورت یک «دکمه» (نه لینک متنی) نمایش داده می‌شود."""
    rows = []
    for ch in channels:
        label = f"📢 عضویت در {ch.title or ch.channel_id}"
        url = _channel_url(ch)
        if url:
            rows.append([(label, url, PRIMARY)])
    return _inline_kb(rows)


def _channel_url(channel) -> str | None:
    """آدرس قابل‌کلیک کانال، یا None اگر آدرس مطمئنی در دسترس نباشد.

    نکته‌ی مهم: برای کانال‌های عددی (مثل -100123...) هیچ آدرس عمومیِ قابل‌اعتمادی
    وجود ندارد — فرمت t.me/c/<id>/1 فقط وقتی کار می‌کند که پیام شماره‌ی ۱ در کانال
    موجود باشد وگرنه لینک می‌شکند. برای این کانال‌ها handler تلگرام سعی می‌کند
    لینک دعوت واقعی را از API بگیرد و در دیتابیس ذخیره کند؛ تا وقتی لینکی نباشد،
    دکمه‌ای هم ساخته نمی‌شود تا کاربر به لینک خراب هدایت نشود.
    """
    if channel.invite_link:
        return channel.invite_link
    cid = (channel.channel_id or "").strip()
    if cid.startswith("@"):
        return f"https://t.me/{cid.lstrip('@')}"
    return None


def admin_chat_inline_keyboard(admin_username: str) -> InlineKeyboardMarkup:
    """دکمه‌ی مستقیمِ چت با ادمین (یک لمس → باز شدن پیوی ادمین)."""
    username = (admin_username or "").strip().lstrip("@")
    return _inline_kb([[(f"💬 گفتگو با @{username}", f"https://t.me/{username}", PRIMARY)]])


def force_join_links_text(channels: list[ForceJoinChannel]) -> str:
    lines = []
    for ch in channels:
        link = ch.invite_link or (
            f"https://t.me/{ch.channel_id.lstrip('@')}" if ch.channel_id.startswith("@") else ch.channel_id
        )
        lines.append(f"📢 {ch.title or ch.channel_id}\n{link}")
    return "\n\n".join(lines)


# --- مدیریت قوانین (کاربر Pro) ---


def rule_button_label(rule: Rule) -> str:
    value = (rule.trigger_value or rule.trigger_type.value)[:24]
    status_icon = "🟢" if rule.enabled else "🔴"
    return f"{status_icon} #{rule.id} {rule.trigger_type.value}: {value}"


def rules_list_keyboard(
    custom_rules: list[Rule], free_rule_enabled: bool, auto_reply_paused: bool = False
) -> ReplyKeyboardMarkup:
    rows = [[texts.BTN_FREE_HELLO_RULE_ON if free_rule_enabled else texts.BTN_FREE_HELLO_RULE_OFF]]
    for rule in custom_rules:
        rows.append([rule_button_label(rule)])
    rows.append([texts.BTN_RULE_ADD])
    # 🧪 شبیه‌ساز: تست امن قوانین با پیام فرضی مشتری، قبل از دیدن مشتری واقعی
    rows.append([texts.BTN_RULE_TEST])
    # 🌙 نگهبان شبانه — برای همه‌ی پلن‌ها (حتی Free)
    rows.append([texts.BTN_NIGHT_GUARD])
    # ⏸ توقف کامل: قوانین + fallback + نگهبان شبانه، همه با یک کلید
    rows.append([texts.BTN_RULES_RESUME_ALL if auto_reply_paused else texts.BTN_RULES_PAUSE_ALL])
    # نقطه‌ی ورود «💬 هر پیامی به غیر از اینا» (اختیاری؛ پیش‌فرض غیرفعال و بدون متن)
    # عمداً همین‌جا کنار بقیه‌ی قوانین قرار گرفته، نه یک منوی جدا در منوی اصلی،
    # چون مفهوماً بخشی از «مدیریت قوانین» همین کاربر است.
    rows.append([texts.BTN_FALLBACK_REPLY])
    rows.append([texts.BTN_BACK_TO_MENU])
    return _kb(rows)


def salam_lang_keyboard() -> ReplyKeyboardMarkup:
    """🟢 زیرمنوی انتخاب زبان پیام «سلام» — فقط برای همین بخش (فارسی/انگلیسی/خاموش)."""
    return _kb(
        [
            [texts.BTN_SALAM_SET_FA, texts.BTN_SALAM_SET_EN],
            [texts.BTN_SALAM_TURN_OFF],
            [texts.BTN_BACK_TO_RULES],
        ]
    )


def rule_test_keyboard() -> ReplyKeyboardMarkup:
    """کیبورد منوی شبیه‌ساز — کاربر فقط متن می‌فرستد یا برمی‌گردد."""
    return _kb([[texts.BTN_BACK_TO_RULES], [texts.BTN_BACK_TO_MENU]])


def night_guard_menu_keyboard(enabled: bool) -> ReplyKeyboardMarkup:
    """کیبورد منوی 🌙 نگهبان شبانه — دکمه‌ی روشن/خاموش بسته به وضعیت فعلی عوض می‌شود."""
    toggle = texts.BTN_NIGHT_OFF if enabled else texts.BTN_NIGHT_ON
    return _kb(
        [
            [texts.BTN_NIGHT_TEXT, texts.BTN_NIGHT_DEFAULT_TEXT],
            [texts.BTN_NIGHT_START, texts.BTN_NIGHT_END],
            [texts.BTN_NIGHT_TZ],
            [toggle],
            [texts.BTN_BACK_TO_RULES],
        ]
    )


def night_guard_text_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_NIGHT_DEFAULT_TEXT, texts.BTN_CANCEL], [texts.BTN_BACK_TO_RULES]])


def night_guard_time_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_CANCEL], [texts.BTN_BACK_TO_RULES]])


def rule_detail_keyboard(rule: Rule) -> ReplyKeyboardMarkup:
    rows = []
    if not rule.is_system:
        rows.append([texts.BTN_RULE_TOGGLE])
        rows.append([texts.BTN_RULE_COPY, texts.BTN_RULE_DELETE])
    rows.append([texts.BTN_BACK_TO_RULES])
    return _kb(rows)


def trigger_type_keyboard() -> ReplyKeyboardMarkup:
    return _kb(
        [
            [texts.BTN_TRIGGER_EXACT],
            [texts.BTN_TRIGGER_CONTAINS],
            [texts.BTN_TRIGGER_FALLBACK],
            [texts.BTN_CANCEL],
        ]
    )


def photo_step_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_PHOTOS_DONE], [texts.BTN_CANCEL]])


# --- Admin ---


def admin_panel_keyboard() -> ReplyKeyboardMarkup:
    return _kb(
        [
            [texts.BTN_ADMIN_USERS, texts.BTN_ADMIN_PRICE],
            [texts.BTN_ADMIN_RULE_LIMITS, texts.BTN_ADMIN_BROADCAST],
            [texts.BTN_ADMIN_FORCE_JOIN, texts.BTN_ADMIN_STATS],
            [texts.BTN_ADMIN_CONTENT, texts.BTN_ADMIN_BACKUP_NOW],
            [texts.BTN_BACK_TO_MENU],
        ]
    )


def admin_back_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_ADMIN_BACK]])


def admin_user_detail_keyboard(account: BusinessAccount) -> ReplyKeyboardMarkup:
    rows = []
    if account.plan.value in ("PRO", "PRO_MAX"):
        rows.append([texts.BTN_ADMIN_RENEW_PRO])
        rows.append([texts.BTN_ADMIN_CANCEL_PRO])
    else:
        rows.append([texts.BTN_ADMIN_ACTIVATE_PRO])
    rows.append([texts.BTN_ADMIN_DELETE_USER])
    rows.append([texts.BTN_ADMIN_BACK])
    return _kb(rows)


def admin_user_delete_confirm_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_ADMIN_DELETE_USER_CONFIRM], [texts.BTN_ADMIN_BACK]])


def admin_activate_plan_choice_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_PLAN_PRO, texts.BTN_PLAN_PRO_MAX], [texts.BTN_ADMIN_BACK]])


def admin_activate_duration_keyboard(options: list) -> ReplyKeyboardMarkup:
    rows = [[pricing_duration_option_label(opt.duration_days, opt.price, opt.id)] for opt in options]
    rows.append([texts.BTN_ADMIN_BACK])
    return _kb(rows)


def admin_price_menu_keyboard() -> ReplyKeyboardMarkup:
    return _kb(
        [
            [texts.BTN_ADMIN_MANAGE_PRICING],
            [texts.BTN_ADMIN_EDIT_PRICE, texts.BTN_ADMIN_EDIT_DURATION],
            [texts.BTN_ADMIN_BACK],
        ]
    )


def admin_rule_limits_keyboard() -> ReplyKeyboardMarkup:
    return _kb(
        [
            [texts.BTN_ADMIN_EDIT_RULE_LIMIT],
            [texts.BTN_ADMIN_EDIT_PRO_RULE_LIMIT],
            [texts.BTN_ADMIN_BACK],
        ]
    )


def admin_content_keyboard() -> ReplyKeyboardMarkup:
    return _kb(
        [
            [texts.BTN_ADMIN_EDIT_SUPPORT_USERNAME],
            [texts.BTN_ADMIN_EDIT_HELP_TEXT],
            [texts.BTN_ADMIN_EDIT_CONNECT_TEXT],
            [texts.BTN_ADMIN_BACK],
        ]
    )


def admin_edit_help_text_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_ADMIN_RESET_HELP_TEXT], [texts.BTN_ADMIN_BACK]])


def fallback_reply_menu_keyboard(
    *, is_enabled: bool, is_pro: bool
) -> ReplyKeyboardMarkup:
    """منوی بخش «💬 پاسخِ عمومی» (ارسال وقتی هیچ قانونی منطبق نشد)."""
    rows: list[list[str]] = [[texts.BTN_FALLBACK_EDIT]]
    rows.append(
        [
            texts.BTN_FALLBACK_TOGGLE_OFF
            if is_enabled
            else texts.BTN_FALLBACK_TOGGLE_ON
        ]
    )
    rows.append([texts.BTN_FALLBACK_RESET])
    if is_pro:
        rows.append([texts.BTN_FALLBACK_PHOTOS])
    rows.append([texts.BTN_BACK_TO_MENU])
    return _kb(rows)


def fallback_photos_keyboard(*, has_photos: bool) -> ReplyKeyboardMarkup:
    rows: list[list[str]] = []
    if has_photos:
        rows.append([texts.BTN_FALLBACK_PHOTOS_CLEAR])
    rows.append([texts.BTN_PHOTOS_DONE])
    rows.append([texts.BTN_CANCEL])
    return _kb(rows)


def admin_edit_connect_text_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_ADMIN_RESET_CONNECT_TEXT], [texts.BTN_ADMIN_BACK]])


def admin_clear_confirm_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_ADMIN_CLEAR_CONFIRM], [texts.BTN_ADMIN_CLEAR_CANCEL]])


def admin_broadcast_confirm_keyboard() -> ReplyKeyboardMarkup:
    return _kb([[texts.BTN_ADMIN_BROADCAST_SEND], [texts.BTN_ADMIN_BROADCAST_CANCEL]])


def admin_pricing_option_label(plan_value: str, duration_days: int, price: int, pricing_id: int) -> str:
    """
    نکته مهم: عمداً مقادیر ساده (str/int) می‌گیرد، نه خودِ آبجکت ORM «PricingPlan».
    این تابع قبلاً مستقیم آبجکت ORM می‌گرفت و در صورت فراخوانی بعد از بسته‌شدن
    session، با DetachedInstanceError کرش می‌کرد (چون attributeهای ORM بدون
    session زنده قابل خواندن نیستند مگر expire_on_commit=False تنظیم شده باشد).
    با گرفتن مقادیر ساده، این تابع دیگر به هیچ session‌ای وابسته نیست و کرش این
    کلاس اصلاً ممکن نیست — صرف‌نظر از اینکه فراخواننده کِی/کجا صدایش بزند.
    """
    plan_name = "Pro Max" if plan_value == "PRO_MAX" else "Pro"
    return f"{plan_name} — {duration_days} روز — {price:,} تومان #{pricing_id}"


def admin_pricing_list_keyboard(options: list) -> ReplyKeyboardMarkup:
    """
    options: list of plain (id, plan_value, duration_days, price) tuples — نه
    خودِ آبجکت‌های ORM. عمداً این‌طور طراحی شده تا این تابع اصلاً به عمر session
    وابسته نباشد؛ تبدیل PricingPlan → tuple باید توسط فراخواننده (همان‌جا که
    session هنوز باز است) انجام شود، نه اینجا.
    """
    rows = [
        [admin_pricing_option_label(plan_value, duration_days, price, pricing_id)]
        for (pricing_id, plan_value, duration_days, price) in options
    ]
    rows.append([texts.BTN_ADMIN_BACK])
    return _kb(rows)


def admin_force_join_keyboard(enabled: bool) -> ReplyKeyboardMarkup:
    toggle_label = texts.BTN_ADMIN_FJ_TOGGLE_OFF if enabled else texts.BTN_ADMIN_FJ_TOGGLE_ON
    return _kb(
        [
            [toggle_label],
            [texts.BTN_ADMIN_FJ_ADD_CHANNEL],
            [texts.BTN_ADMIN_FJ_LIST_CHANNELS],
            [texts.BTN_ADMIN_BACK],
        ]
    )


def force_join_channel_button_label(channel: ForceJoinChannel) -> str:
    return f"🗑 #{channel.id} {channel.title or channel.channel_id}"


def admin_force_join_channels_keyboard(channels: list[ForceJoinChannel]) -> ReplyKeyboardMarkup:
    rows = [[force_join_channel_button_label(ch)] for ch in channels]
    rows.append([texts.BTN_ADMIN_BACK])
    return _kb(rows)
