"""
بررسی عضویت اجباری کاربر در کانال‌های تنظیم‌شده، با استفاده از متد رسمی getChatMember.

طبق بخش ۱۰ Specification:
    اگر Telegram API اجازه بررسی وضعیت عضویت یک کاربر را ندهد (مثلاً چون ربات ادمین
    کانال نیست، یا کانال Private است و ربات دسترسی ندارد)، این محدودیت مدیریت می‌شود:
    آن کانال را به‌صورت "نامشخص" علامت می‌زنیم و کاربر را مسدود نمی‌کنیم — چون فرض
    غیرواقعی درباره‌ی عضویت او نمی‌سازیم، اما همچنین کاربر را به‌خاطر خطای پیکربندی
    ادمین جریمه نمی‌کنیم. این رفتار به‌صراحت در README مستند شده تا ادمین از آن مطلع باشد.
"""
from __future__ import annotations

from telegram import Bot
from telegram.error import BadRequest, Forbidden
from telegram.ext import ContextTypes

from app.models import ForceJoinChannel

MEMBER_STATUSES_OK = {"member", "administrator", "creator"}


async def check_membership(
    bot: Bot, channel: ForceJoinChannel, telegram_user_id: int
) -> bool | None:
    """
    True  → کاربر عضو است
    False → کاربر عضو نیست
    None  → وضعیت قابل تشخیص نیست (خطای دسترسی ربات)؛ نباید فرض غیرواقعی ساخته شود.
    """
    try:
        member = await bot.get_chat_member(chat_id=channel.channel_id, user_id=telegram_user_id)
        return member.status in MEMBER_STATUSES_OK
    except (BadRequest, Forbidden):
        # ربات ادمین کانال نیست یا کانال یافت نشد / کاربر هرگز با کانال تعامل نداشته.
        return None
    except Exception:
        return None


async def check_all_memberships(
    bot: Bot, channels: list[ForceJoinChannel], telegram_user_id: int
) -> tuple[bool, list[ForceJoinChannel]]:
    """
    تمام کانال‌های فعال را بررسی می‌کند.
    خروجی: (is_member_of_all, not_joined_channels)
    کانال‌هایی که وضعیت‌شان قابل تشخیص نیست (None) به‌صورت محافظه‌کارانه در دسته
    "عضو نشده" قرار می‌گیرند تا ادمین متوجه مشکل پیکربندی شود، اما پیام مناسب
    (FORCE_JOIN_CHECK_UNAVAILABLE) به کاربر نمایش داده می‌شود.
    """
    not_joined = []
    unknown = False
    for channel in channels:
        if not channel.enabled:
            continue
        result = await check_membership(bot, channel, telegram_user_id)
        if result is False:
            not_joined.append(channel)
        elif result is None:
            unknown = True
            not_joined.append(channel)
    is_all_member = not not_joined
    return is_all_member, not_joined
