"""
شبیه‌ساز قانون (Rule Tester) — قلب قابلیت «🧪 تست قوانین».

هدف: کاربر قبل از اینکه حتی یک مشتری واقعی پیام بدهد، ببیند پیامِ فرضیِ مشتری
کدام قانون را فعال می‌کند و دقیقاً چه پاسخی ارسال می‌شد. این هم «واو» لحظه‌ی
اول است هم کشنده‌ی ترسِ آبرو («اگر بات جواب مسخره بدهد چه؟»).

این ماژول عمداً خالص (pure) است — نه تلگرام می‌شناسد نه دیتابیس — تا بدون هیچ
dependency بیرونی تست شود (همان الگوی app/rule_engine.py).

نکته‌ی حریم خصوصی: شبیه‌سازی کاملاً در حافظه انجام می‌شود؛ متنِ تست‌شده هیچ‌جا
ذخیره نمی‌شود و در message_logs هم ثبت نمی‌شود.
"""
from __future__ import annotations

from dataclasses import dataclass

from app.rule_engine import EngineContext, EngineRule, TriggerType, match_rule


@dataclass(frozen=True)
class RuleTestOutcome:
    """نتیجه‌ی شبیه‌سازی یک پیام فرضی روی قوانین فعلی کاربر."""

    # قانون منطبق (None یعنی هیچ قانونی Match نشد)
    matched: EngineRule | None
    # آیا پاسخ از مسیر «پاسخ عمومی» (هر پیامی به غیر از اینا) می‌رفت؟
    via_fallback: bool
    # متن نهایی‌ای که ارسال می‌شد (متن قانون یا متن پاسخ عمومی) — None یعنی هیچی
    final_response_text: str | None
    # تعداد عکسی که همراه پاسخ ارسال می‌شد
    final_photos_count: int


def preview_response(
    *,
    rules: tuple[EngineRule, ...],
    incoming_text: str,
    fallback_enabled: bool,
    fallback_text: str | None,
    fallback_photos_count: int = 0,
) -> RuleTestOutcome:
    """شبیه‌سازی دقیق مسیر تصمیم‌گیری on_business_message (بدون لاگ و ارسال).

    ترتیب منطق عمداً یک‌به‌یک همان business_handlers.on_business_message است:
        ۱) Rule Engine روی قوانین فعال (EXACT اول، بعد CONTAINS، بعد priority)
        ۲) اگر هیچ‌کدام نخورد و «پاسخ عمومی» فعال و دارای متن بود → همان مسیر
        ۳) در غیر این صورت → مشتری بی‌جواب می‌ماند
    """
    ctx_engine = match_rule(
        EngineContext(is_pro=True, incoming_text=incoming_text, rules=rules)
    ) if rules else None

    if ctx_engine is not None:
        return RuleTestOutcome(
            matched=ctx_engine,
            via_fallback=False,
            final_response_text=ctx_engine.response_text,
            final_photos_count=len(ctx_engine.media_items),
        )

    clean_fallback = (fallback_text or "").strip()
    if fallback_enabled and clean_fallback:
        return RuleTestOutcome(
            matched=None,
            via_fallback=True,
            final_response_text=clean_fallback,
            final_photos_count=fallback_photos_count,
        )

    return RuleTestOutcome(
        matched=None, via_fallback=False, final_response_text=None, final_photos_count=0
    )


def trigger_label(rule: EngineRule) -> str:
    """برچسب فارسی نوع شرط قانون برای نمایش در نتیجه‌ی تست."""
    if rule.trigger_type == TriggerType.EXACT:
        return "برابر دقیق"
    return "شامل شدن"
