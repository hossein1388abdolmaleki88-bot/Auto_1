"""
ارسال پاسخ یک Rule منطبق‌شده از طریق Telegram Bot API با business_connection_id.

طبق بخش ۱۹ Specification:
    فقط متن            → sendMessage
    فقط یک عکس         → sendPhoto (با caption در صورت وجود متن)
    چند عکس            → sendMediaGroup (caption روی اولین آیتم قرار می‌گیرد)
    متن + یک/چند عکس    → caption یا پیام جداگانه، بسته به محدودیت Telegram API

محدودیت‌های مهم Telegram API که رعایت شده‌اند:
    - caption هر رسانه حداکثر ۱۰۲۴ کاراکتر است؛ متن‌های طولانی‌تر جدا با sendMessage ارسال می‌شوند.
    - sendMediaGroup بین ۲ تا ۱۰ آیتم می‌پذیرد؛ اگر فقط یک عکس باشد از sendPhoto استفاده می‌شود.
"""
from __future__ import annotations

from telegram import InputMediaPhoto
from telegram.ext import ContextTypes

from app.rule_engine import EngineRule

TELEGRAM_CAPTION_LIMIT = 1024
TELEGRAM_MEDIA_GROUP_MAX = 10


async def send_rule_response(
    *,
    context: ContextTypes.DEFAULT_TYPE,
    business_connection_id: str,
    chat_id: int,
    rule: EngineRule,
) -> int | None:
    """
    پاسخ Rule منطبق‌شده را طبق نوع رسانه ارسال می‌کند.
    خروجی: message_id اولین پیام ارسالی (برای ثبت در MessageLog) یا None اگر چیزی ارسال نشد.
    """
    text = (rule.response_text or "").strip() or None
    photos = list(rule.media_items)[:TELEGRAM_MEDIA_GROUP_MAX]

    if not photos:
        if text:
            sent = await context.bot.send_message(
                chat_id=chat_id,
                text=text,
                business_connection_id=business_connection_id,
            )
            return sent.message_id
        return None

    # آیا متن به‌عنوان caption روی عکس جا می‌شود؟
    caption_fits = bool(text) and len(text) <= TELEGRAM_CAPTION_LIMIT
    first_message_id: int | None = None

    if len(photos) == 1:
        sent = await context.bot.send_photo(
            chat_id=chat_id,
            photo=photos[0].telegram_file_id,
            caption=text if caption_fits else None,
            business_connection_id=business_connection_id,
        )
        first_message_id = sent.message_id
        if text and not caption_fits:
            await context.bot.send_message(
                chat_id=chat_id,
                text=text,
                business_connection_id=business_connection_id,
            )
        return first_message_id

    # چند عکس → sendMediaGroup؛ caption روی اولین آیتم قرار می‌گیرد.
    media_group = []
    for idx, item in enumerate(photos):
        caption = text if (idx == 0 and caption_fits) else None
        media_group.append(InputMediaPhoto(media=item.telegram_file_id, caption=caption))

    sent_list = await context.bot.send_media_group(
        chat_id=chat_id,
        media=media_group,
        business_connection_id=business_connection_id,
    )
    first_message_id = sent_list[0].message_id if sent_list else None
    if text and not caption_fits:
        await context.bot.send_message(
            chat_id=chat_id,
            text=text,
            business_connection_id=business_connection_id,
        )
    return first_message_id
