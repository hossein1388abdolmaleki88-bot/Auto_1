"""
🌙 نگهبان شبانه — سرویس خالص (بدون تلگرام، بدون دیتابیس).

قابلیت: در بازه‌ی ساعات شب که صاحب کسب‌وکار مشخص می‌کند، به پیام مشتری‌ها یک
پیام «الان بسته‌ایم» ارسال می‌شود — به‌جای پاسخ قوانین — و به هر مشتری فقط
«یک‌بار در هر شب» (تا اسپم نشود).

⚠️ این قابلیت برای «همه‌ی پلن‌ها» در دسترس است، حتی Free — تصمیم محصول صریح.

این ماژول عمداً pure است (مثل rule_engine.py) تا بدون هیچ dependency بیرونی
تست شود. منطق زمانی:
    - همه‌ی ورودی‌های زمانی «دقیقه از نیمه‌شب» (0..1439) به وقت تهران هستند.
    - بازه می‌تواند از نیمه‌شب بگذرد (مثلاً 23:00 تا 09:00).
    - شروع == پایان یعنی تنظیم ناقص → بازه فعال در نظر گرفته نمی‌شود (و در
      لحظه‌ی فعال‌سازی هم جلوی ذخیره‌ی بازه‌ی برابر گرفته می‌شود).
"""
from __future__ import annotations

import json
from zoneinfo import ZoneInfo, available_timezones

# متن پیش‌فرض پیام شبانه — اگر کاربر متن ننوشته باشد همین ارسال می‌شود.
NIGHT_GUARD_DEFAULT_TEXT = (
    "🌙 همین حالا بسته‌ایم.\n"
    "پیامت رسید و ثبت شد — اولین ساعت کاری جواب می‌دم. مرسی که پیام دادی 🌅\n"
    "🌙 We're closed right now. Your message is noted — I'll reply first thing during working hours. Thanks for reaching out 🌅"
)

_FA_DIGITS_TO_EN = str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")

# 🌍 منطقه‌ی زمانی نگهبان شبانه — پیش‌فرض تهران (حساب‌های قدیمی هیچ تغییری حس نمی‌کنند)
DEFAULT_TIMEZONE = "Asia/Tehran"

_TZ_LOWER_MAP: dict[str, str] | None = None


def _tz_lower_map() -> dict[str, str]:
    """نگاشت حروف‌کوچکِ همه‌ی منطقه‌های IANA → نام استاندارد (با کش)."""
    global _TZ_LOWER_MAP
    if _TZ_LOWER_MAP is None:
        _TZ_LOWER_MAP = {z.lower(): z for z in available_timezones()}
    return _TZ_LOWER_MAP


def resolve_timezone(raw: str | None) -> str | None:
    """«asia/tehran» یا «europe berlin» → نام استاندارد IANA («Asia/Tehran»).

    بزرگ/کوچک بودن حروف و فاصله به‌جای «_» مهم نیست. نامعتبر → None.
    """
    text = (raw or "").strip()
    if not text:
        return None
    # «europe berlin» (فاصله) هم باید «europe/berlin» در نظر گرفته شود
    candidates = [text, text.replace(" ", "_"), text.replace(" ", "/")]
    for candidate in candidates:
        try:
            ZoneInfo(candidate)  # مسیر سریع: نام دقیق و معتبر
            return candidate
        except Exception:
            pass
    lowered = text.lower()
    for candidate in candidates:
        found = _tz_lower_map().get(candidate.lower())
        if found:
            return found
    return None


def zone_for(account) -> ZoneInfo:
    """ZoneInfo فعالِ حساب برای نگهبان شبانه (None/نامعتبر → پیش‌فرض تهران)."""
    raw = getattr(account, "night_guard_timezone", None)
    if raw:
        canonical = resolve_timezone(raw)
        if canonical:
            return ZoneInfo(canonical)
    return ZoneInfo(DEFAULT_TIMEZONE)


def is_within_window(minutes_now: int, start_minute: int | None, end_minute: int | None) -> bool:
    """آیا دقیقه‌ی فعلی داخل بازه‌ی شبانه است؟

    - start < end  → بازه‌ی عادی داخل یک روز (مثل 13:00 تا 18:00)
    - start > end  → بازه‌ی عبوری از نیمه‌شب (مثل 23:00 تا 09:00)
    - start == end یا None بودن → بازه‌ی معتبری نیست → خیر
    - مرزها: لحظه‌ی شروع شامل بازه است، لحظه‌ی پایان شامل نیست.
    """
    if start_minute is None or end_minute is None:
        return False
    if not (0 <= minutes_now <= 1439):
        return False
    if start_minute == end_minute:
        return False
    if start_minute < end_minute:
        return start_minute <= minutes_now < end_minute
    # عبور از نیمه‌شب: مثلاً 23:00 تا 09:00 → ساعت >= 23 یا < 09
    return minutes_now >= start_minute or minutes_now < end_minute


def parse_hhmm(raw: str) -> int | None:
    """تبدیل ورودی ساعت کاربر به «دقیقه از نیمه‌شب».

    پذیرش: «23:00»، «۹:۳۰» (ارقام فارسی)، «7:05». خروجی None یعنی نامعتبر.
    فقط فرمت HH:MM (با دو بخش) پذیرفته می‌شود تا ابهام نباشد.
    """
    if raw is None:
        return None
    text = str(raw).strip().translate(_FA_DIGITS_TO_EN)
    parts = text.split(":")
    if len(parts) != 2:
        return None
    hours_part, minutes_part = parts[0].strip(), parts[1].strip()
    if not (hours_part.isdigit() and minutes_part.isdigit()):
        return None
    # «۹:۵» پذیرفته می‌شود (معادل 9:05) ولی ارقام طولانی‌تر رد می‌شود
    if len(hours_part) > 2 or len(minutes_part) > 2:
        return None
    hours, minutes = int(hours_part), int(minutes_part)
    if hours > 23 or minutes > 59:
        return None
    return hours * 60 + minutes


def format_minutes(minutes: int | None) -> str:
    """نمایش «دقیقه از نیمه‌شب» به شکل HH:MM (ارقام انگلیسی؛ لایه‌ی نمایش فارسی‌سازی می‌کند)."""
    if minutes is None:
        return "—"
    minutes = max(0, min(1439, minutes))
    return f"{minutes // 60:02d}:{minutes % 60:02d}"


# ---------------------------------------------------------------------------
# وضعیت «به این مشتری امشب پیام دادیم؟» — JSON در ستون night_sent_state
# ساختار: {"<chat_id>": "YYYY-MM-DD"} (تاریخ به وقت تهران)
# هنگام ثبتِ امشب، ورودی‌های تاریخ‌های گذشته پاک می‌شوند تا فایل بی‌نهایت بزرگ نشود.
# ---------------------------------------------------------------------------


def night_was_sent(state_json: str | None, chat_id: int, today: str) -> bool:
    """آیا به این chat_id در تاریخ today (وقت تهران) پیام شبانه داده‌ایم؟"""
    if not state_json:
        return False
    try:
        state = json.loads(state_json)
    except (ValueError, TypeError):
        return False
    if not isinstance(state, dict):
        return False
    return state.get(str(chat_id)) == today


def night_mark_sent(state_json: str | None, chat_id: int, today: str) -> str:
    """ثبت ارسال امشب + پاک‌سازی ورودی‌های تاریخ‌های گذشته. JSON جدید را برمی‌گرداند."""
    state: dict = {}
    if state_json:
        try:
            loaded = json.loads(state_json)
            if isinstance(loaded, dict):
                state = {str(k): str(v) for k, v in loaded.items()}
        except (ValueError, TypeError):
            state = {}
    # پاک‌سازی: هر ورودی‌ای که مالِ امروز نیست مالِ دیروز یا قبل است → دیگر لازم نیست
    state = {chat: day for chat, day in state.items() if day == today}
    state[str(chat_id)] = today
    return json.dumps(state, ensure_ascii=False, separators=(",", ":"))


def night_should_send_now(
    *,
    minutes_now: int,
    start_minute: int | None,
    end_minute: int | None,
    state_json: str | None,
    chat_id: int,
    today: str,
) -> bool:
    """تصمیم نهایی: آیا همین پیامِ همین مشتری باید پیام شبانه بگیرد؟
    (داخل بازه باشیم + قبلاً امشب به همین مشتری نداده باشیم)"""
    if not is_within_window(minutes_now, start_minute, end_minute):
        return False
    return not night_was_sent(state_json, chat_id, today)
