"""
لایه Repository — تمام دسترسی‌های دیتابیس اینجا متمرکز شده‌اند.
Handlerهای تلگرام مستقیماً با SQLAlchemy Session کار نمی‌کنند، همه از این توابع
استفاده می‌کنند تا منطق Multi-Tenant (هر Business فقط داده‌های خودش) یک‌جا و
قابل‌اعتماد پیاده‌سازی شود.
"""
from __future__ import annotations

import logging

import json
import re

from datetime import datetime, timedelta, timezone

from sqlalchemy import text,  delete, func, select
from sqlalchemy.orm import Session

from app.config import settings as app_settings
from app import texts
logger = logging.getLogger(__name__)

from app.models import (
    BusinessAccount,
    BusinessConnection,
    CustomerChat,
    ForceJoinChannel,
    MediaType,
    MessageDirection,
    MessageLog,
    MessageStatus,
    PlanType,
    PricingPlan,
    ResponseMediaType as ORMResponseMediaType,
    Rule,
    RuleMedia,
    Setting,
    TriggerType as ORMTriggerType,
    User,
    utcnow,
)
from app.rule_engine import (
    EngineRule,
    ResponseMediaType as EngineResponseMediaType,
    RuleMediaItem,
    TriggerType as EngineTriggerType,
)

# مهلت بازیابی پس از قطع دسترسی (روز): در این بازه اگر کاربر دوباره اکانتش را
# وصل کند، همان اکانتِ قبلی با همه‌ی قوانین/پلن/آمار زنده می‌شود؛ بعد از این
# مهلت، job روزانه‌ی پاک‌سازی آن را برای همیشه حذف می‌کند.
DISCONNECT_GRACE_DAYS = 30


# مقادیر Enum مدل ORM (app.models) و Enum مصرفی Rule Engine (app.rule_engine) عمداً
# دو کلاس جدا هستند (برای استقلال Engine از SQLAlchemy) اما مقادیر رشته‌ای یکسان دارند.
TriggerType = ORMTriggerType
ResponseMediaType = ORMResponseMediaType

# --------------------------------------------------------------------------
# Settings
# --------------------------------------------------------------------------

SETTING_PRO_PRICE = "pro_price"
SETTING_PRO_DURATION_DAYS = "pro_duration_days"
SETTING_FORCE_JOIN_ENABLED = "force_join_enabled"
SETTING_FREE_RULE_LIMIT = "free_rule_limit"
SETTING_PRO_RULE_LIMIT = "pro_rule_limit"
SETTING_ADMIN_USERNAME = "admin_username"
SETTING_HELP_TEXT = "help_text"
SETTING_CONNECT_TEXT = "connect_text"
# فقط یک نشانه‌ی داخلی برای «آیا اصلاح یک‌باره‌ی پیش‌فرض پاسخ عمومی اجرا شده یا نه»
# (به fix_customer_reply_default_off_once مراجعه کنید) — تنظیمی نیست که جایی از
# پنل قابل مشاهده/ویرایش باشد.
SETTING_CUSTOMER_REPLY_FIX_APPLIED = "_fix_customer_reply_default_off_applied"

# پیش از انقضای Pro/Pro Max، چند روز مانده به کاربر اطلاع داده شود.
EXPIRY_WARNING_DAYS = 2

# مدت‌های استاندارد قابل خرید (روز) — برای هر دو پلن Pro و Pro Max یک ردیف قیمت
# در جدول pricing_plans ساخته می‌شود. مقادیر پیش‌فرض؛ ادمین از پنل تغییرشان می‌دهد.
DEFAULT_DURATIONS_DAYS = (10, 30, 60, 365)
DEFAULT_SEED_PRICES = {
    # (plan, duration_days): price تومان
    (PlanType.PRO, 10): 90000,
    (PlanType.PRO, 30): 250000,
    (PlanType.PRO, 60): 450000,
    (PlanType.PRO, 365): 2200000,
    (PlanType.PRO_MAX, 10): 150000,
    (PlanType.PRO_MAX, 30): 400000,
    (PlanType.PRO_MAX, 60): 750000,
    (PlanType.PRO_MAX, 365): 3800000,
}

DEFAULTS = {
    SETTING_PRO_PRICE: "250000",
    SETTING_PRO_DURATION_DAYS: "30",
    SETTING_FORCE_JOIN_ENABLED: "false",
    # تعداد قوانین اختصاصی (غیر از رول سیستمی «سلام») که یک کاربر Free
    # مجاز به ساختن آن‌هاست.
    SETTING_FREE_RULE_LIMIT: "2",
    # سقف قوانین اختصاصی برای کاربر Pro (Pro Max همیشه نامحدود است).
    SETTING_PRO_RULE_LIMIT: "15",
    # خالی یعنی «هنوز از پنل تغییر نکرده» → get_admin_username() به ADMIN_USERNAME
    # در .env برمی‌گردد (پایین‌تر توضیح داده شده).
    SETTING_ADMIN_USERNAME: "",
    # خالی یعنی «هنوز از پنل تغییر نکرده» → get_help_text_template() به
    # texts.DEFAULT_HELP_TEXT برمی‌گردد.
    SETTING_HELP_TEXT: "",
}


def get_setting(session: Session, key: str) -> str:
    row = session.get(Setting, key)
    if row is None:
        return DEFAULTS.get(key, "")
    return row.value


def set_setting(session: Session, key: str, value: str) -> None:
    row = session.get(Setting, key)
    if row is None:
        row = Setting(key=key, value=value)
        session.add(row)
    else:
        row.value = value
        row.updated_at = utcnow()
    session.flush()


def get_pro_price(session: Session) -> int:
    return int(get_setting(session, SETTING_PRO_PRICE))


def set_pro_price(session: Session, price: int) -> None:
    set_setting(session, SETTING_PRO_PRICE, str(price))


def get_pro_duration_days(session: Session) -> int:
    return int(get_setting(session, SETTING_PRO_DURATION_DAYS))


def set_pro_duration_days(session: Session, days: int) -> None:
    set_setting(session, SETTING_PRO_DURATION_DAYS, str(days))


def get_free_rule_limit(session: Session) -> int:
    return int(get_setting(session, SETTING_FREE_RULE_LIMIT))


def set_free_rule_limit(session: Session, limit: int) -> None:
    set_setting(session, SETTING_FREE_RULE_LIMIT, str(limit))


def get_pro_rule_limit(session: Session) -> int:
    return int(get_setting(session, SETTING_PRO_RULE_LIMIT))


def set_pro_rule_limit(session: Session, limit: int) -> None:
    set_setting(session, SETTING_PRO_RULE_LIMIT, str(limit))


def get_admin_username(session: Session) -> str:
    """یوزرنیم پشتیبانی/خرید که به کاربران در فلوی خرید Pro/Pro Max نمایش داده
    می‌شود. اگر ادمین هنوز از پنل چیزی ست نکرده باشد (مقدار خالی در دیتابیس)،
    به‌صورت خودکار به ADMIN_USERNAME در .env برمی‌گردد — یعنی این تابع همیشه
    باید به‌جای settings.admin_username مستقیم در همه‌ی هندلرها استفاده شود."""
    value = get_setting(session, SETTING_ADMIN_USERNAME)
    return value or app_settings.admin_username


def set_admin_username(session: Session, username: str) -> None:
    set_setting(session, SETTING_ADMIN_USERNAME, username.strip().lstrip("@"))


def get_help_text_template(session: Session) -> str:
    """متن خام «❓ راهنما» (ممکن است شامل {free_limit}/{pro_limit} باشد) — قبل از
    نمایش باید safe_format شود، نه .format() مستقیم (چون متنی که ادمین تایپ
    می‌کند ممکن است آکولاد نامعتبر یا کلید ناشناخته داشته باشد و کرش کند)."""
    value = get_setting(session, SETTING_HELP_TEXT)
    return value or texts.DEFAULT_HELP_TEXT


def set_help_text_template(session: Session, text: str) -> None:
    set_setting(session, SETTING_HELP_TEXT, text)


def reset_help_text_template(session: Session) -> None:
    set_setting(session, SETTING_HELP_TEXT, "")


def lock_rule_limit_for_current_period(session: Session, account: BusinessAccount) -> None:
    """سقف قانون «فعلیِ زنده» (تنظیمات سراسری) را برای پلن *فعلی* این اکانت
    می‌خواند و روی خودِ اکانت قفل می‌کند (account.locked_rule_limit) — این سقف
    تا شروع دوره‌ی بعدی همین اکانت (خرید/تمدید Pro، یا انقضا و بازگشت به Free)
    دیگر دست‌نخورده می‌ماند، حتی اگر ادمین تنظیمات سراسری را بعداً عوض کند.
    باید در هر «شروع دوره‌ی جدید» صدا زده شود: ساخت اکانت تازه (Free)،
    activate_pro (خرید/تمدید Pro یا Pro Max)، و بازگشت به Free (چه با انقضای
    خودکار، چه با لغو دستی ادمین). برای Pro Max مقدار None (نامحدود) ذخیره
    می‌شود صرفاً برای وضوح؛ در عمل is_pro_max_active همیشه زودتر چک می‌شود و
    این مقدار اصلاً خوانده نمی‌شود.

    نکته مهم: عمداً از is_pro_active()/is_pro_max_active() (بررسی زمان‌محور)
    استفاده می‌شود، نه مستقیم از account.plan؛ چون این تابع همچنین از داخل
    get_rule_limit_for_account (برای قفل‌کردن تنبل ردیف‌های قدیمی) صدا زده
    می‌شود، جایی که ممکن است account.plan هنوز «PRO» باشد ولی pro_until از قبل
    گذشته باشد (تا وقتی Job ساعتی downgrade_expired_accounts اجرا شود) — در آن
    حالت باید بلافاصله سقف Free قفل شود، نه سقف Pro قدیمی."""
    if account.is_pro_max_active():
        account.locked_rule_limit = None
    elif account.is_pro_active():
        account.locked_rule_limit = get_pro_rule_limit(session)
    else:
        account.locked_rule_limit = get_free_rule_limit(session)


def get_rule_limit_for_account(session: Session, account: BusinessAccount) -> int | None:
    """سقف قوانین اختصاصی مجاز برای پلن فعلیِ *فعال* این اکانت.

    رفتار هر پلن:
      - Pro Max فعال        → None (نامحدود؛ هرگز سقف ندارد)
      - Pro فعال            → «قفل‌شده» در شروع دوره‌ی فعلی همین اکانت؛ اگر ادمین
                              سقف سراسری Pro را عوض کند، روی دوره‌های جاریِ از
                              قبل فعال تأثیر نمی‌گذارد (با تمدید/خرید بعدی اعمال
                              می‌شود).
      - Free (یا Pro منقضی) → مقدار *زنده* و لحظه‌ای تنظیمات سراسری Free —
                              یعنی هر وقت ادمین سقف Free را تغییر دهد، همان لحظه
                              برای همه‌ی کاربران Free اعمال می‌شود. (مقدار قفل‌شده‌ی
                              قدیمیِ Free دیگر خوانده نمی‌شود ولی همچنان نگه‌داری
                              می‌شود تا اگر بعداً پلن Pro شروع شد، منطق قفل Pro
                              دست‌نخورده کار کند.)

    خروجی None یعنی نامحدود (فقط Pro Max فعال).
    """
    if account.is_pro_max_active():
        return None
    if account.is_pro_active():
        if account.locked_rule_limit is not None:
            return account.locked_rule_limit
        # سازگاری با ردیف‌های قدیمی‌تر (قبل از افزودن این ستون؛ locked_rule_limit
        # هنوز NULL است): همین الان با مقدار زنده‌ی فعلی قفل می‌شود تا از این پس هم
        # رفتار «قفل تا پایان دوره» برایشان برقرار شود، نه اینکه برای همیشه فقط
        # fallback بمانند.
        lock_rule_limit_for_current_period(session, account)
        session.flush()
        return account.locked_rule_limit
    # کاربر Free (یا Pro منقضی‌شده) → همیشه سقف زنده‌ی Free، همین لحظه اعمال می‌شود.
    return get_free_rule_limit(session)


def plan_label(account: BusinessAccount) -> str:
    """برچسب فارسی پلن فعلیِ *فعال* اکانت (با در نظر گرفتن انقضا)."""
    if account.is_pro_max_active():
        return "Pro Max"
    if account.is_pro_active():
        return "Pro"
    return "Free"


def is_force_join_enabled(session: Session) -> bool:
    return get_setting(session, SETTING_FORCE_JOIN_ENABLED).lower() == "true"


def set_force_join_enabled(session: Session, enabled: bool) -> None:
    set_setting(session, SETTING_FORCE_JOIN_ENABLED, "true" if enabled else "false")


# --------------------------------------------------------------------------
# Users
# --------------------------------------------------------------------------


_UNSET = object()  # نشانه‌ی «این پارامتر اصلاً پاس داده نشده» — با None فرق دارد


def get_or_create_user(
    session: Session,
    telegram_user_id: int,
    username: str | None = _UNSET,
    first_name: str | None = _UNSET,
    last_name: str | None = _UNSET,
) -> User:
    """
    نکته مهم (رفع یک باگ واقعی): این تابع در جاهای مختلفی از کد صدا زده می‌شود —
    بعضی‌ها (مثل /start یا اتصال Business) اطلاعات کامل کاربر تلگرام را دارند و
    پاس می‌دهند؛ بعضی دیگر (مثل بازکردن یک منوی داخلی) فقط telegram_user_id را
    دارند و نمی‌خواهند username/first_name را دست بزنند. قبلاً پیش‌فرض این
    پارامترها None بود، و چون None با مقدار واقعی موجود در دیتابیس فرق داشت،
    هر بار که این تابع بدون این پارامترها صدا زده می‌شد، username/first_name
    واقعی کاربر با None بازنویسی (پاک) می‌شد. حالا پیش‌فرض یک شیء ویژه به اسم
    _UNSET است که یعنی «این مقدار اصلاً ارسال نشده»، نه «این مقدار خالی است»؛
    فقط وقتی صراحتاً چیزی (even None، برای کاربری که واقعاً یوزرنیم ندارد) پاس
    داده شود همان مقدار ذخیره می‌شود.
    """
    user = session.execute(
        select(User).where(User.telegram_user_id == telegram_user_id)
    ).scalar_one_or_none()
    if user is None:
        user = User(
            telegram_user_id=telegram_user_id,
            username=None if username is _UNSET else username,
            first_name=None if first_name is _UNSET else first_name,
            last_name=None if last_name is _UNSET else last_name,
        )
        session.add(user)
        session.flush()
    else:
        changed = False
        if username is not _UNSET and username != user.username:
            user.username = username
            changed = True
        if first_name is not _UNSET and first_name != user.first_name:
            user.first_name = first_name
            changed = True
        if last_name is not _UNSET and last_name != user.last_name:
            user.last_name = last_name
            changed = True
        if changed:
            user.updated_at = utcnow()
            session.flush()
    return user


def is_admin(telegram_user_id: int, admin_ids: list[int]) -> bool:
    return telegram_user_id in admin_ids


# --------------------------------------------------------------------------
# Business Connections / Accounts
# --------------------------------------------------------------------------


def upsert_business_connection(
    session: Session,
    *,
    business_connection_id: str,
    user: User,
    telegram_user_id: int,
    is_enabled: bool,
    can_reply: bool,
) -> BusinessConnection:
    """هنگام دریافت آپدیت business_connection فراخوانی می‌شود."""
    conn = session.execute(
        select(BusinessConnection).where(
            BusinessConnection.business_connection_id == business_connection_id
        )
    ).scalar_one_or_none()
    if conn is None:
        conn = BusinessConnection(
            business_connection_id=business_connection_id,
            user_id=user.id,
            telegram_user_id=telegram_user_id,
            is_enabled=is_enabled,
            can_reply=can_reply,
        )
        session.add(conn)
        session.flush()
    else:
        conn.is_enabled = is_enabled
        conn.can_reply = can_reply
        conn.updated_at = utcnow()
        session.flush()

    # اطمینان از وجود BusinessAccount مرتبط (پیش‌فرض FREE)
    account = session.execute(
        select(BusinessAccount).where(BusinessAccount.business_connection_id == conn.id)
    ).scalar_one_or_none()
    if account is None:
        # رفع یک باگ بسیار گیج‌کننده: وقتی کاربر اکانت را قطع و دوباره وصل
        # می‌کند، تلگرام یک business_connection_id **جدید** صادر می‌کند. نسخه‌ی
        # قبلی در این حالت یک BusinessAccount کاملاً جدید می‌ساخت؛ در نتیجه
        # همه‌ی قوانین، اشتراک و «پاسخِ عمومیِ» کاربر روی اکانتِ قبلی جا
        # می‌ماندند و اکانتِ جدید فقط قانونِ داخلیِ «سلام» را داشت — یعنی
        # به‌ظاهر «هر پیامی که می‌رسد، متنِ عمومی ارسال می‌شود».
        # حالا همان اکانتِ قبلیِ کاربر را به اتصالِ جدید متصل می‌کنیم.
        existing = (
            session.execute(
                select(BusinessAccount)
                .where(BusinessAccount.owner_user_id == user.id)
                .order_by(BusinessAccount.id)
            )
            .scalars()
            .first()
        )
        if existing is not None:
            existing.business_connection_id = conn.id
            existing.is_enabled = True
            # اکانتِ قطع‌شده (غیرفعال‌سازی نرم) دوباره زنده می‌شود — همان اکانت
            # قبلی با همه‌ی قوانین/پلن/چت‌ها، بدون ساخت حساب تکراری.
            existing.disconnected_at = None
            existing.updated_at = utcnow()
            session.flush()
        else:
            account = BusinessAccount(
                owner_user_id=user.id,
                business_connection_id=conn.id,
                is_enabled=True,
                plan=PlanType.FREE,
            )
            session.add(account)
            session.flush()
            lock_rule_limit_for_current_period(session, account)
            ensure_free_default_rule(session, account)
    else:
        account.is_enabled = is_enabled
        account.updated_at = utcnow()
        session.flush()

    return conn


def get_business_account_by_connection_id(
    session: Session, business_connection_id: str
) -> BusinessAccount | None:
    return session.execute(
        select(BusinessAccount)
        .join(BusinessConnection)
        .where(BusinessConnection.business_connection_id == business_connection_id)
    ).scalar_one_or_none()


def get_business_accounts_for_user(session: Session, user_id: int) -> list[BusinessAccount]:
    """اکانت‌های *فعال* کاربر — اکانت‌هایی که در مهلت بازیابی قطع شده‌اند اینجا
    برنمی‌گردند تا منوها («اتصال اکانت»، «مدیریت قوانین»، «حساب من») دقیقاً
    مانند حالت بدون‌اتصال رفتار کنند. با اتصال مجدد، همان اکانت زنده می‌شود و
    دوباره در همین لیست ظاهر می‌شود."""
    return list(
        session.execute(
            select(BusinessAccount).where(
                BusinessAccount.owner_user_id == user_id,
                BusinessAccount.disconnected_at.is_(None),
            )
        ).scalars()
    )


def business_account_is_pro(account: BusinessAccount) -> bool:
    """بررسی is_pro با در نظر گرفتن انقضا (بخش ۲۰ Specification)."""
    return account.is_pro_active()


# --------------------------------------------------------------------------
# Pro Activation (Admin)
# --------------------------------------------------------------------------


def activate_pro(
    session: Session,
    account: BusinessAccount,
    *,
    plan: PlanType = PlanType.PRO,
    duration_days: int | None = None,
    exact_until: datetime | None = None,
) -> BusinessAccount:
    """فعال‌سازی/تمدید Pro یا Pro Max. اگر exact_until داده شود، همان استفاده می‌شود؛
    در غیر این‌صورت duration_days (یا مدت پیش‌فرض تنظیمات) به تاریخ فعلی/باقیمانده اضافه می‌شود.
    اگر اکانت از قبل روی همان plan فعال بوده، مدت جدید به باقیمانده اضافه (تمدید) می‌شود؛
    در غیر این‌صورت (پلن قبلی متفاوت بوده یا منقضی شده) از هم‌اکنون شروع می‌شود."""
    now = utcnow()
    if exact_until is not None:
        account.pro_until = exact_until
    else:
        days = duration_days or get_pro_duration_days(session)
        base = account.pro_until if (account.plan == plan and account.pro_until and account.pro_until > now) else now
        account.pro_until = base + timedelta(days=days)
    account.plan = plan
    account.expiry_notice_sent = False
    account.updated_at = now
    lock_rule_limit_for_current_period(session, account)
    session.flush()
    return account


def get_customer_reply_text(session: Session, account: BusinessAccount) -> str:
    """متنِ «هر پیامی به غیر از اینا» که **خودِ** صاحب کسب‌وکار نوشته است.

    مهم: این تابع دیگر هیچ متن پیش‌فرضی برنمی‌گرداند. اگر کاربر متنی تنظیم
    نکرده باشد، رشته‌ی خالی برگردانده می‌شود و در نتیجه برای پیامی که با هیچ
    قانونی مطابقت ندارد، **هیچ پاسخی ارسال نمی‌شود**.
    """
    del session  # فقط برای حفظ امضای تابع
    return (account.customer_reply_text or "").strip()


def set_customer_reply(session: Session, account: BusinessAccount, text: str) -> BusinessAccount:
    """ذخیره‌ی متن پاسخ مشتری (و روشن کردن خودکار پاسخ‌گویی)."""
    cleaned = re.sub(r"\\{\\s*support\\s*\\}", "", text or "", flags=re.IGNORECASE)
    cleaned = re.sub(r"[ \\t]{2,}", " ", cleaned).strip()
    account.customer_reply_text = cleaned
    account.customer_reply_enabled = True
    account.updated_at = utcnow()
    session.flush()
    return account


def reset_customer_reply(session: Session, account: BusinessAccount) -> BusinessAccount:
    """بازگرداندن متن به پیش‌فرض (حذف متن سفارشی)."""
    account.customer_reply_text = None
    account.updated_at = utcnow()
    session.flush()
    return account


def get_customer_reply_media(session: Session, account: BusinessAccount) -> list[str]:
    """فایل‌آی‌دی عکس‌های همراهِ متن پاسخ به مشتری (خالی اگر تنظیم نشده باشد)."""
    raw = (account.customer_reply_media or "").strip()
    if not raw:
        return []
    try:
        data = json.loads(raw)
    except (ValueError, TypeError):
        return []
    if isinstance(data, list):
        return [str(item) for item in data if isinstance(item, (str, int))]
    return []


def set_customer_reply_media(
    session: Session, account: BusinessAccount, file_ids: list[str]
) -> BusinessAccount:
    """ذخیره‌ی عکس‌های همراه متن (لیست file_id به صورت JSON)."""
    account.customer_reply_media = json.dumps(file_ids, ensure_ascii=False)
    account.updated_at = utcnow()
    session.flush()
    return account


def clear_customer_reply_media(session: Session, account: BusinessAccount) -> BusinessAccount:
    account.customer_reply_media = None
    account.updated_at = utcnow()
    session.flush()
    return account


def toggle_customer_reply(
    session: Session, account: BusinessAccount, enabled: bool
) -> BusinessAccount:
    """روشن/خاموش کردن پاسخ خودکارِ پیش‌فرض (متن سفارشی دست‌نخورده باقی می‌ماند)."""
    account.customer_reply_enabled = enabled
    account.updated_at = utcnow()
    session.flush()
    return account


def cancel_pro(session: Session, account: BusinessAccount) -> BusinessAccount:
    account.plan = PlanType.FREE
    account.pro_until = None
    account.expiry_notice_sent = False
    account.updated_at = utcnow()
    lock_rule_limit_for_current_period(session, account)
    session.flush()
    return account


def _active_accounts_stmt(stmt):
    """لیست‌های «کاربران» ادمین فقط اکانت‌های فعال (غیرِ قطع‌شده) را نشان می‌دهند:
    کسی که دسترسی را قطع کرده با غیرفعال‌سازی نرم از لیست حذف می‌شود تا لیست
    صادق باشد؛ اکانت او تا پایان مهلت بازیابی نگه داشته می‌شود و سپس پاک می‌شود."""
    return stmt.where(BusinessAccount.disconnected_at.is_(None))


def delete_business_account(session: Session, account_id: int) -> bool:
    """حذف کامل یک Business Account (همان ورودی‌های لیست «👥 کاربران» ادمین) همراه
    با تمام داده‌های مرتبطش: اتصال Business، قوانین، عکس‌های قوانین، مشتریان و
    لاگ پیام‌ها.

    کاربرد اصلی: وقتی یک شخص اکانت Business خودش را قطع و دوباره وصل می‌کند، یک
    اتصال جدید با business_connection_id جدید ساخته می‌شود و در لیست کاربران دو
    ورودی (یکی قدیمیِ بی‌استفاده و یکی جدیدِ زنده) دیده می‌شود. ادمین می‌تواند
    ورودی قدیمی را حذف کند؛ ورودی جدید سر جایش می‌ماند.

    اگر این آخرین حسابِ صاحبش باشد، رکورد خودِ User هم حذف می‌شود تا آن کاربر
    کاملاً از بات پاک شود (دیگر در آمار و لیست «پیام همگانی» نباشد). اگر کاربر
    بعداً دوباره اتصال برقرار کند، یک رکورد User تازه ساخته می‌شود.

    نکته: چون SQLite FK constraints را به‌صورت پیش‌فرض اعمال نمی‌کند، رکوردهای
    وابسته صراحتاً (نه فقط با تکیه بر cascade ORM) حذف می‌شوند تا هیچ داده‌ی
    یتیمی (orphan) در دیتابیس باقی نماند.
    """
    account = session.get(BusinessAccount, account_id)
    if account is None:
        return False

    # اتصال Business مرتبط (رابطه‌ی ۱ به ۱) — بعد از حذف خودِ حساب حذف می‌شود؛
    # چون حذف زودهنگامِ connection باعث می‌شود SQLAlchemy بخواهد ستون NOT NULL
    # business_connection_id در حساب را NULL کند و خطا بدهد.
    connection = session.get(BusinessConnection, account.business_connection_id)

    session.execute(delete(MessageLog).where(MessageLog.business_account_id == account.id))
    session.execute(
        delete(RuleMedia).where(
            RuleMedia.rule_id.in_(
                select(Rule.id).where(Rule.business_account_id == account.id)
            )
        )
    )
    session.execute(delete(Rule).where(Rule.business_account_id == account.id))
    session.execute(delete(CustomerChat).where(CustomerChat.business_account_id == account.id))
    session.flush()

    owner_user_id = account.owner_user_id
    session.delete(account)
    session.flush()

    if connection is not None:
        session.delete(connection)
        session.flush()

    # اگر این آخرین حسابِ این کاربر بود، خودِ User هم پاک می‌شود.
    remaining = session.execute(
        select(func.count())
        .select_from(BusinessAccount)
        .where(BusinessAccount.owner_user_id == owner_user_id)
    ).scalar_one()
    if remaining == 0:
        user = session.get(User, owner_user_id)
        if user is not None:
            session.delete(user)
            session.flush()
    return True


def has_disconnected_account(session: Session, owner_user_id: int) -> bool:
    """آیا این کاربر اتصالی دارد که قطع شده و هنوز در مهلت بازیابی است؟"""
    return (
        session.execute(
            select(func.count())
            .select_from(BusinessAccount)
            .where(
                BusinessAccount.owner_user_id == owner_user_id,
                BusinessAccount.disconnected_at.isnot(None),
            )
        ).scalar_one()
        > 0
    )


def disconnect_business_account(session: Session, business_connection_id: str) -> bool:
    """«غیرفعال‌سازی نرم» وقتی کاربر دسترسی بات را از تنظیمات اکانت خودش قطع می‌کند
    (آپدیت business_connection با is_enabled=False).

    به‌جای حذف فوری، اکانت علامت disconnected می‌خورد: از «لیست کاربران» ادمین
    حذف می‌شود و پاسخ‌گویی متوقف می‌شود، ولی قوانین، چت‌های مشتری و وضعیت پلن
    حفظ می‌شود تا اگر کاربر تا DISCONNECT_GRACE_DAYS روز دوباره وصل شد (با اتصال
    جدید)، همان اکانت دوباره فعال شود و همه‌چیز برگردد. بعد از گذشت مهلت بدون
    بازگشت، purge_disconnected_accounts آن را حذف کامل می‌کند.

    اگر اتصالی با این شناسه پیدا نشود False برمی‌گرداند."""
    account = get_business_account_by_connection_id(session, business_connection_id)
    if account is None:
        return False
    now = utcnow()
    account.is_enabled = False
    account.disconnected_at = now
    account.updated_at = now
    conn = session.get(BusinessConnection, account.business_connection_id)
    if conn is not None:
        conn.is_enabled = False
        conn.updated_at = now
    session.flush()
    return True


def purge_disconnected_accounts(session: Session, grace_days: int = DISCONNECT_GRACE_DAYS) -> int:
    """پاک‌سازی خودکار (job روزانه): اکانت‌هایی که بیش از grace_days روز پیش قطع
    شده‌اند و کاربر برنگشته را حذف کامل می‌کند (همراه با User اگر آخرین حسابش
    باشد). تعداد حذف‌شده‌ها را برمی‌گرداند."""
    cutoff = utcnow() - timedelta(days=grace_days)
    accounts = session.execute(
        select(BusinessAccount).where(
            BusinessAccount.disconnected_at.isnot(None),
            BusinessAccount.disconnected_at <= cutoff,
        )
    ).scalars().all()
    for account in accounts:
        delete_business_account(session, account.id)
    if accounts:
        session.flush()
    return len(accounts)


def downgrade_expired_accounts(session: Session) -> int:
    """کاربرانی که Pro/Pro Max آن‌ها منقضی شده را به FREE برمی‌گرداند. تعداد رکوردهای بروزشده را برمی‌گرداند."""
    now = utcnow()
    accounts = session.execute(
        select(BusinessAccount).where(
            BusinessAccount.plan.in_((PlanType.PRO, PlanType.PRO_MAX)),
            BusinessAccount.pro_until.isnot(None),
            BusinessAccount.pro_until <= now,
        )
    ).scalars().all()
    for account in accounts:
        account.plan = PlanType.FREE
        account.expiry_notice_sent = False
        account.updated_at = now
        # دوره‌ی قبلی (Pro/Pro Max) تمام شد → همین لحظه سقف Free فعلی قفل می‌شود
        # (نه اینکه تا ابد روی مقدار قدیمی Pro بماند یا فوراً به‌جای «قفل‌شده» به
        # تنظیمات زنده برگردد).
        lock_rule_limit_for_current_period(session, account)
    if accounts:
        session.flush()
    return len(accounts)


def get_accounts_expiring_soon(session: Session, days_ahead: int = EXPIRY_WARNING_DAYS) -> list[BusinessAccount]:
    """اکانت‌های Pro/Pro Max که ظرف `days_ahead` روز آینده منقضی می‌شوند و هنوز اعلان
    نگرفته‌اند. این تابع اعلان‌شده بودن آن‌ها را هم علامت می‌زند (side effect) تا فراخوان
    فقط پیام ارسال کند، بدون نگرانی از تکرار."""
    now = utcnow()
    threshold = now + timedelta(days=days_ahead)
    accounts = session.execute(
        select(BusinessAccount).where(
            BusinessAccount.plan.in_((PlanType.PRO, PlanType.PRO_MAX)),
            BusinessAccount.pro_until.isnot(None),
            BusinessAccount.pro_until > now,
            BusinessAccount.pro_until <= threshold,
            BusinessAccount.expiry_notice_sent.is_(False),
        )
    ).scalars().all()
    for account in accounts:
        _ = account.owner.telegram_user_id  # eager-load قبل از بسته شدن session
        account.expiry_notice_sent = True
    if accounts:
        session.flush()
    return accounts


# --------------------------------------------------------------------------
# Customer Chats
# --------------------------------------------------------------------------


def get_or_create_customer_chat(
    session: Session, business_account_id: int, telegram_chat_id: int
) -> tuple[CustomerChat, bool]:
    """رکورد CustomerChat را برمی‌گرداند و مشخص می‌کند آیا این اولین پیام است یا خیر.
    خروجی: (customer_chat, is_first_message)
    """
    chat = session.execute(
        select(CustomerChat).where(
            CustomerChat.business_account_id == business_account_id,
            CustomerChat.telegram_chat_id == telegram_chat_id,
        )
    ).scalar_one_or_none()
    now = utcnow()
    if chat is None:
        chat = CustomerChat(
            business_account_id=business_account_id,
            telegram_chat_id=telegram_chat_id,
            first_message_at=now,
            last_message_at=now,
            message_count=1,
        )
        session.add(chat)
        session.flush()
        return chat, True

    is_first = False
    chat.last_message_at = now
    chat.message_count += 1
    chat.updated_at = now
    session.flush()
    return chat, is_first


# --------------------------------------------------------------------------
# Rules
# --------------------------------------------------------------------------


def ensure_free_default_rule(session: Session, account: BusinessAccount) -> Rule:
    """Rule داخلی 'سلام' برای هر BusinessAccount جدید ساخته می‌شود (بخش ۱۷)."""
    existing = session.execute(
        select(Rule).where(Rule.business_account_id == account.id, Rule.is_system.is_(True))
    ).scalar_one_or_none()
    if existing:
        return existing
    rule = Rule(
        business_account_id=account.id,
        trigger_type=TriggerType.EXACT,
        trigger_value="سلام",
        response_text=texts.DEFAULT_SALAM_RESPONSE,
        response_media_type=ResponseMediaType.NONE,
        priority=0,
        enabled=True,
        is_system=True,
        requires_pro=False,
    )
    session.add(rule)
    session.flush()
    return rule


def list_rules(session: Session, business_account_id: int, only_enabled: bool = False) -> list[Rule]:
    stmt = select(Rule).where(Rule.business_account_id == business_account_id)
    if only_enabled:
        stmt = stmt.where(Rule.enabled.is_(True))
    stmt = stmt.order_by(Rule.priority.desc(), Rule.id.asc())
    return list(session.execute(stmt).scalars())


def count_custom_rules(session: Session, business_account_id: int) -> int:
    """تعداد قوانین اختصاصی (غیر سیستمی) یک Business Account — برای سنجش سقف Free."""
    stmt = select(func.count(Rule.id)).where(
        Rule.business_account_id == business_account_id, Rule.is_system.is_(False)
    )
    return session.execute(stmt).scalar_one()


def create_rule(
    session: Session,
    business_account_id: int,
    *,
    trigger_type: TriggerType,
    trigger_value: str | None,
    response_text: str | None,
    photo_file_ids: list[str] | None = None,
    priority: int = 0,
    requires_pro: bool = True,
) -> Rule:
    photo_file_ids = photo_file_ids or []
    if photo_file_ids and response_text:
        media_type = ResponseMediaType.TEXT_AND_PHOTOS
    elif photo_file_ids and len(photo_file_ids) > 1:
        media_type = ResponseMediaType.MULTIPLE_PHOTOS
    elif photo_file_ids:
        media_type = ResponseMediaType.PHOTO
    else:
        media_type = ResponseMediaType.NONE

    rule = Rule(
        business_account_id=business_account_id,
        trigger_type=trigger_type,
        trigger_value=trigger_value,
        response_text=response_text,
        response_media_type=media_type,
        priority=priority,
        enabled=True,
        is_system=False,
        requires_pro=requires_pro,
    )
    session.add(rule)
    session.flush()

    for idx, file_id in enumerate(photo_file_ids):
        session.add(
            RuleMedia(
                rule_id=rule.id,
                media_type=MediaType.PHOTO,
                telegram_file_id=file_id,
                sort_order=idx,
            )
        )
    session.flush()
    return rule


def delete_rule(session: Session, rule: Rule) -> bool:
    if rule.is_system:
        return False
    session.delete(rule)
    session.flush()
    return True


def toggle_rule(session: Session, rule: Rule, enabled: bool) -> Rule:
    rule.enabled = enabled
    rule.updated_at = utcnow()
    session.flush()
    return rule


def set_salam_rule(
    session: Session,
    rule: Rule,
    *,
    enabled: bool,
    response_text: str | None = None,
    trigger_value: str | None = None,
) -> Rule:
    """🟢 تنظیم وضعیت، متن و کلمه‌ی محرکِ قانون داخلی «سلام»
    (انتخاب زبان پاسخ — فقط همین بخش): فارسی → «سلام»، انگلیسی → «hello»."""
    rule.enabled = enabled
    if response_text is not None:
        rule.response_text = response_text
    if trigger_value is not None:
        rule.trigger_value = trigger_value
    rule.updated_at = utcnow()
    session.flush()
    return rule


def count_rule_matches(session: Session, rule_id: int) -> int:
    """این قانون تا حالا چند بار واقعاً جواب داده؟ (مخصوص نمایش در جزئیات قانون)

    فقط پیام‌های «ورودیِ موفق» شمرده می‌شوند — یعنی پیامی که با این قانون Match
    شده و پاسخش هم واقعاً ارسال شده. شمارش کاملاً عددی است؛ هیچ متن پیامی
    خوانده/نمایش داده نمی‌شود (سازگار با تعهد حریم خصوصی).
    """
    return session.execute(
        select(func.count())
        .select_from(MessageLog)
        .where(
            MessageLog.matched_rule_id == rule_id,
            MessageLog.direction == MessageDirection.INCOMING,
            MessageLog.status == MessageStatus.SUCCESS,
        )
    ).scalar_one()


def duplicate_rule(session: Session, rule: Rule) -> Rule:
    """ساخت یک نسخه‌ی مشابه از قانون (شرط، پاسخ، عکس‌ها و اولویت همان، فعال).

    قانون سیستمی (سلام) قابل کپی نیست — caller هم چک می‌کند. سقف پلن را هم
    caller قبل از صدا زدن چک می‌کند (مثل افزودن قانون جدید).
    """
    copy = Rule(
        business_account_id=rule.business_account_id,
        trigger_type=rule.trigger_type,
        trigger_value=rule.trigger_value,
        response_text=rule.response_text,
        response_media_type=rule.response_media_type,
        priority=rule.priority,
        enabled=True,
        is_system=False,
        requires_pro=rule.requires_pro,
    )
    session.add(copy)
    session.flush()

    for media in rule.media_items:
        session.add(
            RuleMedia(
                rule_id=copy.id,
                media_type=media.media_type,
                telegram_file_id=media.telegram_file_id,
                sort_order=media.sort_order,
            )
        )
    session.flush()
    return copy


# ------------------------------- 🌙 نگهبان شبانه -------------------------------
# برای «همه‌ی پلن‌ها» در دسترس است (حتی Free) — هیچ چک is_pro در این مسیر نیست.


def set_auto_reply_paused(session: Session, account: BusinessAccount, paused: bool) -> BusinessAccount:
    """⏸ توقف/از سرگیری «همه‌ی» پاسخ‌های خودکار این اکانت: قوانین + «هر پیامی به
    غیر از اینا» + نگهبان شبانه، همه با هم. فقط یک کلید، صفر استثنا."""
    account.auto_reply_paused = bool(paused)
    account.updated_at = utcnow()
    session.flush()
    return account


def get_night_guard_settings(session: Session, account: BusinessAccount) -> dict:
    """تنظیمات فعلی نگهبان شبانه یک اکانت (برای نمایش در منو)."""
    return {
        "enabled": bool(account.night_guard_enabled),
        "start_minute": account.night_start_minute,
        "end_minute": account.night_end_minute,
        "text": (account.night_guard_text or "").strip() or None,
    }


def set_night_guard(
    session: Session,
    account: BusinessAccount,
    *,
    enabled: bool | None = None,
    text: str | None = None,
    start_minute: int | None = None,
    end_minute: int | None = None,
    timezone: str | None = None,
) -> BusinessAccount:
    """به‌روزرسانی بخشی از تنظیمات نگهبان شبانه (فقط فیلدهای داده‌شده عوض می‌شوند؛
    text=None یعنی بازگشت به متن پیش‌فرض برنامه)."""
    now = utcnow()
    if enabled is not None:
        account.night_guard_enabled = bool(enabled)
    if text is not None:
        clean = text.strip()
        account.night_guard_text = clean or None
    if timezone is not None:
        clean_tz = timezone.strip()
        account.night_guard_timezone = clean_tz or None  # None → پیش‌فرض تهران
    if start_minute is not None:
        account.night_start_minute = max(0, min(1439, int(start_minute)))
    if end_minute is not None:
        account.night_end_minute = max(0, min(1439, int(end_minute)))
    account.updated_at = now
    session.flush()
    return account


def night_was_sent(session: Session, account_id: int, chat_id: int, today: str) -> bool:
    """آیا به این مشتری در تاریخ today (وقت تهران) پیام شبانه داده شده؟"""
    account = session.get(BusinessAccount, account_id)
    if account is None:
        return False
    from app.services.night_guard import night_was_sent as _was_sent

    return _was_sent(account.night_sent_state, chat_id, today)


def night_mark_sent(session: Session, account_id: int, chat_id: int, today: str) -> None:
    """ثبت ارسال پیام شبانه به این مشتری (+ پاک‌سازی ورودی‌های شب‌های گذشته)."""
    account = session.get(BusinessAccount, account_id)
    if account is None:
        return
    from app.services.night_guard import night_mark_sent as _mark

    account.night_sent_state = _mark(account.night_sent_state, chat_id, today)
    account.updated_at = utcnow()
    session.flush()


def migrate_first_message_rules(session: Session) -> int:
    """حذفِ کاملِ قابلیت «اولین پیام» (FIRST_MESSAGE).

    چون مقدار FIRST_MESSAGE از enum حذف شده، هر ردیفِ قدیمی با این مقدار در
    دیتابیس باعث خطای ValueError هنگام تبدیل می‌شد و کل ربات را از کار
    می‌انداخت. این تابع:

    * ردیف‌هایی که عبارتِ شرط دارند را به «شامل شدن» (CONTAINS) تبدیل می‌کند
      تا پاسخِ کاربر از دست نرود؛
    * ردیف‌های بدون عبارت را حذف می‌کند (بدون عبارت قابل اجرا نیستند).

    تابع بی‌خطر و تکرارپذیر است (بارهای بعد هیچ ردیفی تغییر نمی‌کند).
    """
    converted = session.execute(
        text(
            "UPDATE rules SET trigger_type = 'CONTAINS' "
            "WHERE trigger_type = 'FIRST_MESSAGE' "
            "AND trigger_value IS NOT NULL AND TRIM(trigger_value) <> ''"
        )
    ).rowcount or 0
    deleted = session.execute(
        text("DELETE FROM rules WHERE trigger_type = 'FIRST_MESSAGE'")
    ).rowcount or 0
    if converted or deleted:
        session.commit()
        logger.info(
            "Migration حذفِ «اولین پیام»: %s قانون تبدیل شد، %s قانون حذف شد.",
            converted,
            deleted,
        )
    return converted + deleted


def merge_duplicate_business_accounts(session: Session) -> int:
    """تعمیرِ اکانت‌های تکراریِ *موجود* در دیتابیس (رفع باگِ واقعیِ محیط تولید).

    سناریوی واقعی که گزارش شد: کاربر اکانت را قطع و دوباره وصل می‌کند؛ تلگرام
    business_connection_id جدیدی می‌دهد و نسخه‌های قدیمیِ برنامه یک
    BusinessAccount تازه می‌ساختند. نتیجه:

        اکانتِ قدیمی  → تمام قوانینِ کاربر
        اکانتِ جدید   → فعال است ولی فقط قانونِ داخلیِ «سلام» را دارد
        💥 رفتار مشاهده‌شده: «هر پیامی می‌رسد، پیامِ عمومی ارسال می‌شود»

    اصلاحِ قبلی فقط جلوی ساخته‌شدنِ تکراریِ *جدید* را می‌گیرد؛ این تابع وضعیتِ
    *از قبل خراب* را هم درست می‌کند:

    * برای هر کاربری که بیش از یک اکانت دارد، «اکانتِ اصلی» انتخاب می‌شود
      (اکانتی که به یک اتصالِ فعال وصل است؛ در غیر این صورت قدیمی‌ترین).
    * همه‌ی قوانینِ اکانت‌های دیگر به اکانتِ اصلی منتقل می‌شوند (به‌جز قانونِ
      داخلیِ تکراریِ «سلام» که بیش از یک نسخه از آن معنا ندارد).
    * «پاسخِ عمومی»، عکس‌های آن و پلنِ Pro در صورت نبودن روی اکانتِ اصلی
      منتقل می‌شوند.
    * اکانت‌های اضافی حذف می‌شوند تا آمارِ پنل ادمین هم درست باشد.

    تابع بی‌خطر و تکرارپذیر است (وقتی تکراری‌ای نباشد کاری نمی‌کند).
    """
    from sqlalchemy import func as _func

    dup_owners = [
        row[0]
        for row in session.execute(
            select(BusinessAccount.owner_user_id)
            .group_by(BusinessAccount.owner_user_id)
            .having(_func.count(BusinessAccount.id) > 1)
        ).all()
    ]
    if not dup_owners:
        return 0

    merged = 0
    for owner_id in dup_owners:
        accounts = list(
            session.execute(
                select(BusinessAccount)
                .where(BusinessAccount.owner_user_id == owner_id)
                .order_by(BusinessAccount.id)
            )
            .scalars()
            .all()
        )
        if len(accounts) < 2:
            continue

        # اکانتِ اصلی: ترجیحاً متصل به یک اتصالِ فعال
        active_conn_ids = {
            row[0]
            for row in session.execute(
                select(BusinessConnection.id).where(BusinessConnection.is_enabled.is_(True))
            ).all()
        }
        primary = next(
            (a for a in accounts if a.business_connection_id in active_conn_ids),
            accounts[0],
        )

        for other in accounts:
            if other.id == primary.id:
                continue
            # انتقال قوانین با SQLِ مستقیم (نهORM) چون رابطه‌ی rules روی
            # BusinessAccount حذفِ آبشاری (cascade) دارد و تغییرِ FK با ORM
            # پیش از حذفِ اکانت، در عمل قوانین را پاک می‌کرد.
            # ۱) قانونِ داخلیِ «سلام» تکراری معنا ندارد → حذف
            session.execute(
                text("DELETE FROM rules WHERE business_account_id = :oid AND is_system = 1"),
                {"oid": other.id},
            )
            # ۲) بقیه‌ی قوانین به اکانتِ اصلی منتقل می‌شوند
            session.execute(
                text(
                    "UPDATE rules SET business_account_id = :pid "
                    "WHERE business_account_id = :oid"
                ),
                {"pid": primary.id, "oid": other.id},
            )
            session.flush()

            # انتقالِ «در غیر این صورت» و پلن — فقط اگر اصلی خالی است
            if not (primary.customer_reply_text or "").strip() and (
                other.customer_reply_text or ""
            ).strip():
                primary.customer_reply_text = other.customer_reply_text
                primary.customer_reply_media = other.customer_reply_media
            if (other.plan != PlanType.FREE) and primary.plan == PlanType.FREE:
                primary.plan = other.plan
                primary.pro_until = other.pro_until

            session.delete(other)
            merged += 1

        session.flush()

    if merged:
        session.commit()
        logger.warning(
            "تعمیرِ اکانت‌های تکراری: %s اکانتِ اضافی ادغام و حذف شد.", merged
        )
    return merged


def fix_customer_reply_default_off_once(session: Session) -> int:
    """اصلاح یک‌باره‌ی داده‌ی موجود: مقدار پیش‌فرض `customer_reply_enabled` قبلاً
    True بود (یعنی «پاسخ عمومی» برای همه‌ی کاربران، حتی بدون انتخاب خودشان،
    روشن بود). این تابع همه‌ی ردیف‌های موجود که هنوز روی مقدار قدیمی (True)
    مانده‌اند را خاموش می‌کند — ولی فقط **یک‌بار** در کل عمر دیتابیس (با یک
    نشانه در جدول settings)، تا اگر کاربری بعداً خودش دوباره روشنش کرد، این
    تابع در اجراهای بعدی آن انتخاب دستی را برنگرداند."""
    if get_setting(session, SETTING_CUSTOMER_REPLY_FIX_APPLIED) == "1":
        return 0
    fixed = session.execute(
        text("UPDATE business_accounts SET customer_reply_enabled = 0 WHERE customer_reply_enabled = 1")
    ).rowcount or 0
    set_setting(session, SETTING_CUSTOMER_REPLY_FIX_APPLIED, "1")
    session.commit()
    if fixed:
        logger.warning(
            "اصلاح یک‌باره‌ی «پاسخ عمومی»: %s اکانت که پیش‌فرض قدیمی (فعال) داشتند، خاموش شدند.",
            fixed,
        )
    return fixed


def to_engine_rules(rules: list[Rule]) -> tuple[EngineRule, ...]:
    """تبدیل مدل‌های ORM به dataclassهای سبک‌وزن مورد استفاده Rule Engine."""
    result = []
    for r in rules:
        media_items = tuple(
            RuleMediaItem(telegram_file_id=m.telegram_file_id, sort_order=m.sort_order)
            for m in sorted(r.media_items, key=lambda m: m.sort_order)
        )
        # محافظت: ردیف‌های قدیمیِ دیتابیس ممکن است نوعِ شرطی داشته باشند که
        # دیگر وجود ندارد (مثلاً FIRST_MESSAGE که حذف شده). به‌جای کرش‌کردنِ
        # کل ربات، آن قانون را نادیده می‌گیریم.
        try:
            engine_trigger = EngineTriggerType(r.trigger_type.value)
        except (ValueError, AttributeError):
            logger.warning(
                "Rule id=%s نوع شرطِ نامعتبر (%s) دارد و نادیده گرفته شد.",
                r.id,
                getattr(r.trigger_type, "value", r.trigger_type),
            )
            continue
        result.append(
            EngineRule(
                id=r.id,
                trigger_type=engine_trigger,
                trigger_value=r.trigger_value,
                response_text=r.response_text,
                # محافظت: ردیف‌های قدیمی ممکن است response_media_type خالی
                # (NULL) داشته باشند — بدون این، AttributeError کل ربات را
                # برای آن کسب‌وکار از کار می‌انداخت.
                response_media_type=(
                    EngineResponseMediaType(r.response_media_type.value)
                    if getattr(r.response_media_type, "value", None)
                    else EngineResponseMediaType.NONE
                ),
                media_items=media_items,
                priority=r.priority,
                enabled=r.enabled,
                requires_pro=r.requires_pro,
                is_system=r.is_system,
            )
        )
    return tuple(result)


# --------------------------------------------------------------------------
# Message Log / Deduplication
# --------------------------------------------------------------------------


def is_duplicate_message(
    session: Session, business_account_id: int, telegram_message_id: int, direction: MessageDirection
) -> bool:
    existing = session.execute(
        select(MessageLog).where(
            MessageLog.business_account_id == business_account_id,
            MessageLog.telegram_message_id == telegram_message_id,
            MessageLog.direction == direction,
        )
    ).scalar_one_or_none()
    return existing is not None


def log_message(
    session: Session,
    *,
    business_account_id: int,
    telegram_chat_id: int,
    telegram_message_id: int,
    direction: MessageDirection,
    text: str | None,
    matched_rule_id: int | None,
    status: MessageStatus,
) -> MessageLog | None:
    if is_duplicate_message(session, business_account_id, telegram_message_id, direction):
        return None
    entry = MessageLog(
        business_account_id=business_account_id,
        telegram_chat_id=telegram_chat_id,
        telegram_message_id=telegram_message_id,
        direction=direction,
        text=text,
        matched_rule_id=matched_rule_id,
        status=status,
    )
    session.add(entry)
    session.flush()
    return entry


# --------------------------------------------------------------------------
# Pricing Plans (Pro / Pro Max × مدت)
# --------------------------------------------------------------------------


def ensure_default_pricing(session: Session) -> None:
    """اگر جدول pricing_plans خالی باشد (اجرای اول)، قیمت‌های پیش‌فرض ساخته می‌شوند.
    بعد از آن فقط ادمین از پنل قیمت‌ها را تغییر می‌دهد؛ این تابع چیزی را overwrite نمی‌کند."""
    existing = session.execute(select(func.count()).select_from(PricingPlan)).scalar_one()
    if existing:
        return
    for (plan, duration_days), price in DEFAULT_SEED_PRICES.items():
        session.add(PricingPlan(plan=plan, duration_days=duration_days, price=price, enabled=True))
    session.flush()


def list_pricing_options(
    session: Session, plan: PlanType | None = None, only_enabled: bool = False
) -> list[PricingPlan]:
    stmt = select(PricingPlan)
    if plan is not None:
        stmt = stmt.where(PricingPlan.plan == plan)
    if only_enabled:
        stmt = stmt.where(PricingPlan.enabled.is_(True))
    stmt = stmt.order_by(PricingPlan.plan.asc(), PricingPlan.duration_days.asc())
    return list(session.execute(stmt).scalars())


def get_pricing_option(session: Session, pricing_id: int) -> PricingPlan | None:
    return session.get(PricingPlan, pricing_id)


def set_pricing_price(session: Session, pricing_id: int, price: int) -> PricingPlan | None:
    option = session.get(PricingPlan, pricing_id)
    if option is None:
        return None
    option.price = price
    option.updated_at = utcnow()
    session.flush()
    return option


# --------------------------------------------------------------------------
# Force Join Channels
# --------------------------------------------------------------------------


def list_force_join_channels(session: Session, only_enabled: bool = False) -> list[ForceJoinChannel]:
    stmt = select(ForceJoinChannel)
    if only_enabled:
        stmt = stmt.where(ForceJoinChannel.enabled.is_(True))
    return list(session.execute(stmt).scalars())


def add_force_join_channel(
    session: Session, channel_id: str, title: str | None = None, invite_link: str | None = None
) -> ForceJoinChannel:
    channel = ForceJoinChannel(
        channel_id=channel_id, title=title, invite_link=invite_link, enabled=True
    )
    session.add(channel)
    session.flush()
    return channel


def remove_force_join_channel(session: Session, channel_id: int) -> bool:
    channel = session.get(ForceJoinChannel, channel_id)
    if channel is None:
        return False
    session.delete(channel)
    session.flush()
    return True


# --------------------------------------------------------------------------
# Admin: Users & Stats
# --------------------------------------------------------------------------


def list_all_business_accounts(session: Session, limit: int = 50, offset: int = 0) -> list[BusinessAccount]:
    stmt = select(BusinessAccount).order_by(BusinessAccount.created_at.desc()).limit(limit).offset(offset)
    return list(session.execute(_active_accounts_stmt(stmt)).scalars())


def list_all_business_accounts_full(session: Session) -> list[BusinessAccount]:
    """تمام Business Accountها بدون صفحه‌بندی — برای ارسال لیست کامل کاربران به‌صورت
    پیام متنی به ادمین (نه دکمه‌ای) استفاده می‌شود."""
    stmt = select(BusinessAccount).order_by(BusinessAccount.created_at.desc())
    return list(session.execute(_active_accounts_stmt(stmt)).scalars())


def count_business_accounts(session: Session) -> int:
    return session.execute(
        _active_accounts_stmt(select(func.count()).select_from(BusinessAccount))
    ).scalar_one()


def list_all_user_telegram_ids(session: Session) -> list[int]:
    """آیدی عددی تلگرام همه‌ی کاربرانی که تا الان با بات تعامل داشته‌اند (جدول
    users) — برای «پیام همگانی» ادمین استفاده می‌شود. شامل صاحبان Business
    Account هم می‌شود، چون آن‌ها هم اول یک رکورد User دارند."""
    return list(session.execute(select(User.telegram_user_id)).scalars())


def get_stats(session: Session) -> dict:
    now = utcnow()
    total_users = session.execute(select(func.count()).select_from(User)).scalar_one()
    total_accounts = session.execute(select(func.count()).select_from(BusinessAccount)).scalar_one()
    free_count = session.execute(
        select(func.count()).select_from(BusinessAccount).where(BusinessAccount.plan == PlanType.FREE)
    ).scalar_one()
    pro_count_flagged = session.execute(
        select(func.count()).select_from(BusinessAccount).where(BusinessAccount.plan == PlanType.PRO)
    ).scalar_one()
    pro_max_count_flagged = session.execute(
        select(func.count()).select_from(BusinessAccount).where(BusinessAccount.plan == PlanType.PRO_MAX)
    ).scalar_one()
    pro_active = session.execute(
        select(func.count())
        .select_from(BusinessAccount)
        .where(
            BusinessAccount.plan.in_((PlanType.PRO, PlanType.PRO_MAX)),
            BusinessAccount.pro_until.isnot(None),
            BusinessAccount.pro_until > now,
        )
    ).scalar_one()
    pro_expired = (pro_count_flagged + pro_max_count_flagged) - pro_active
    total_incoming = session.execute(
        select(func.count()).select_from(MessageLog).where(MessageLog.direction == MessageDirection.INCOMING)
    ).scalar_one()
    total_outgoing = session.execute(
        select(func.count()).select_from(MessageLog).where(MessageLog.direction == MessageDirection.OUTGOING)
    ).scalar_one()
    total_rules = session.execute(select(func.count()).select_from(Rule)).scalar_one()

    # تعداد قوانین «فعال» (فقط enabled=True؛ نوع قانون مهم نیست)
    active_rules = session.execute(
        select(func.count()).select_from(Rule).where(Rule.enabled.is_(True))
    ).scalar_one()
    active_exact_rules = session.execute(
        select(func.count())
        .select_from(Rule)
        .where(Rule.enabled.is_(True), Rule.trigger_type == ORMTriggerType.EXACT)
    ).scalar_one()
    active_contains_rules = session.execute(
        select(func.count())
        .select_from(Rule)
        .where(Rule.enabled.is_(True), Rule.trigger_type == ORMTriggerType.CONTAINS)
    ).scalar_one()
    active_system_rules = session.execute(
        select(func.count())
        .select_from(Rule)
        .where(Rule.enabled.is_(True), Rule.is_system.is_(True))
    ).scalar_one()

    return {
        "total_users": total_users,
        "total_business_accounts": total_accounts,
        "free_count": free_count,
        "pro_count": pro_count_flagged,
        "pro_max_count": pro_max_count_flagged,
        "pro_active": pro_active,
        "pro_expired": pro_expired,
        "total_incoming_messages": total_incoming,
        "total_outgoing_messages": total_outgoing,
        "total_rules": total_rules,
        "active_rules": active_rules,
        "active_exact_rules": active_exact_rules,
        "active_contains_rules": active_contains_rules,
        "active_system_rules": active_system_rules,
        "active_custom_rules": active_rules - active_system_rules,
    }


def get_connect_text(session: Session) -> str:
    """متن خام صفحه اتصال اکانت تلگرام (قابل ویرایش از پنل ادمین)."""
    value = (get_setting(session, SETTING_CONNECT_TEXT) or "").strip()
    return value or texts.CONNECT_ACCOUNT_INTRO


def set_connect_text(session: Session, text: str) -> None:
    """ذخیره متن اختصاصی ادمین برای صفحه اتصال."""
    set_setting(session, SETTING_CONNECT_TEXT, text)


def reset_connect_text(session: Session) -> None:
    """بازگرداندن متن اتصال به پیش فرض."""
    set_setting(session, SETTING_CONNECT_TEXT, "")
