# 🦅 چشم عقاب — پاسخ‌گوی خودکار Telegram Business

> **وقتی خوابی، مغازه‌ات فروش می‌کند.**
> ربات پاسخ‌گویی خودکار برای کسب‌وکارهایی که از قابلیت رسمی **Telegram Business** استفاده می‌کنند.

[![tests](https://github.com/hossein1388abdolmaleki88-bot/Auto_a/actions/workflows/tests.yml/badge.svg)](./.github/workflows/tests.yml)

---

## ✨ چی هست؟

مشتری به اکانت Business شما پیام می‌دهد → ربات در چند ثانیه بر اساس قوانینی که خودتان ساخته‌اید جواب می‌دهد — با پیام متنی و عکس. قیمت، آدرس، ساعات کاری، هر سوالی که تکرار می‌شود؛ دیگر هیچ پیامی بی‌جواب نمی‌ماند.

- ✅ بر پایه‌ی **Bot API رسمی** تلگرام (`business_connection_id`) — نه userbot، نه session string، نه لاگین با شماره
- ✅ رول‌انجین EXACT / CONTAINS با نرمال‌سازی هوشمند فارسی (ي/ی، ك/ک، نیم‌فاصله)
- ✅ پنل ادمین کامل: کاربران، قیمت‌گذاری، پیام همگانی، عضویت اجباری، آمار
- ✅ پلن‌های Free / Pro / Pro Max با سقف قانون قابل تنظیم
- ✅ Polling برای شروع سریع + Webhook برای پروداکشن

## 🔒 حریم خصوصی — اول اعتماد، بعد اتصال

اتصال اکانت یعنی اعتماد. ما این را جدی گرفته‌ایم:

| ✅ ذخیره می‌شود | ❌ هرگز ذخیره نمی‌شود |
|---|---|
| اسم و آیدی تلگرام شما | متن پیام‌های مشتریان شما |
| قوانینی که خودتان ساخته‌اید | شماره تلفن (حتی نمی‌پرسیم) |
| آمار عددی (بدون متن) | — |

- 📄 داخل ربات: `/privacy` — صفحه‌ی حریم خصوصی به زبان ساده
- 🟢 داخل ربات: `/status` — سلامت بات، نسخه‌ی در حال اجرا، مدت روشن‌بودن
- ⚠️ این ربات هرگز شماره تلفن، کد ورود یا پسورد نمی‌خواهد. هر کس چنین چیزی خواست، کلاهبردار است.
- 🔓 قطع اتصال = حذف کامل داده‌ها

---

## 🚀 راه‌اندازی سریع

### ۱) ساخت بات در BotFather
1. به [@BotFather](https://t.me/BotFather) پیام بده → `/newbot`
2. بعد از ساخت، برو به **Bot Settings → Business Mode** و بات را به‌عنوان «Connected Business Bot» فعال کن
3. توکن را کپی کن

### ۲) تنظیمات
```bash
git clone https://github.com/hossein1388abdolmaleki88-bot/Auto_a.git
cd Auto_a
cp .env.example .env
# حالا .env را باز کن و BOT_TOKEN و ADMIN_TELEGRAM_IDS را پر کن
```

### ۳) اجرا
```bash
pip install -r requirements.txt
python main.py
```

یا با Docker:
```bash
docker compose up -d --build
```

یا ۲۴/۷ روی VPS: راهنمای کامل در [`deploy/README.md`](deploy/README.md)

### ۴) اتصال اکانت Business
داخل تلگرام: **Settings → Telegram Business → Chatbots** → بات را وصل کن. تمام! از این به بعد ربات به پیام‌های مشتریان‌ات طبق قوانین پاسخ می‌دهد.

---

## 🤖 دستورهای ربات

| دستور | کار |
|---|---|
| `/start` | شروع و منوی اصلی |
| `/privacy` | صفحه‌ی حریم خصوصی |
| `/status` | سلامت و نسخه‌ی بات |
| `/admin` | پنل ادمین (فقط ادمین‌ها) |

---

## 🧪 تست‌ها

```bash
pip install -r requirements.txt pytest
python -m pytest tests/ -q
```

تست‌ها با هر push به‌صورت خودکار در GitHub Actions اجرا می‌شوند.

## 🏗 معماری

```
Business Owner → Telegram Business → Connected Bot (API رسمی)
    → business_message → Rule Engine (مستقل و تست‌پذیر)
    → پاسخ از طرف اکانت کسب‌وکار (sendMessage/sendPhoto)
```

| مسیر | نقش |
|---|---|
| `app/rule_engine.py` | تطبیق پیام با قوانین — مستقل از تلگرام و دیتابیس |
| `app/handlers/business_handlers.py` | هسته: دریافت پیام مشتری و ارسال پاسخ |
| `app/repository.py` | لایه‌ی دسترسی به داده |
| `app/handlers/` | منوها: کاربر، قوانین، ادمین، عضویت اجباری |
| `tests/` | تست‌های رول‌انجین، repository و زمان |

---

## 🇬🇧 English (summary)

**Eagle Eye** is an auto-reply bot for businesses using Telegram's official **Business API**. Customers message your business account; the bot instantly replies based on rules you define (exact/contains triggers, text + photo responses).

- ✅ Official Bot API only — no userbots, no sessions, no phone login
- ✅ **Privacy-first:** customer message *text* is never stored — only numeric stats. See `/privacy` in the bot
- ✅ Free / Pro / Pro Max plans, admin panel, force-join, broadcast
- ✅ Runs with polling (dev) or webhook (production), Docker included

```bash
cp .env.example .env   # set BOT_TOKEN + ADMIN_TELEGRAM_IDS
pip install -r requirements.txt
python main.py
```

Connect your account in Telegram: **Settings → Telegram Business → Chatbots**.

> ⚠️ This bot will never ask for your phone number, login code, or password.

---

## 📜 License

پروژه‌ی خصوصی — تمام حقوق محفوظ است.
