"""
🧭 تست سفرهای کامل از طریق «روتر واقعی» بات (app.bot._private_text_router).

این فایل قوی‌ترین لایه‌ی محافظ است: هر دکمه‌ای که هر کیبوردی رندر می‌کند،
«واقعاً فشرده می‌شود» (متنش به روتر اصلی داده می‌شود) و باید:
    ۱) هندل شود (پاسخی برسد) و
    ۲) پاسخ «دستور نامشخص» نگیرد.
باگ واقعی «🌙 نگهبان شبانه → دستور نامشخص» دیگر نمی‌تواند بی‌سر و صدا برگردد.
"""
import asyncio
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app import keyboards, repository, texts
from app.handlers import state
from app.models import (
    Base,
    BusinessAccount,
    BusinessConnection,
    PlanType,
    PricingPlan,
    Rule,
    TriggerType,
    User,
)

TG_ID = 6816275778  # همان ادمینِ پیش‌فرض داخل کد — کاربرِ این سفرها ادمین هم هست


class _Msg:
    def __init__(self, text: str):
        self.text = text
        self.replies: list[str] = []
        self.markups = []

    async def reply_text(self, text, reply_markup=None, **kw):
        self.replies.append(text)
        self.markups.append(reply_markup)


class _Bot:
    def __init__(self):
        self.calls = []

    def _rec(self, **kw):
        self.calls.append(kw)
        return SimpleNamespace(message_id=5000 + len(self.calls))

    async def send_message(self, **kw):
        return self._rec(**kw)

    async def send_document(self, **kw):
        return self._rec(**kw)

    async def get_chat_member(self, **kw):
        return SimpleNamespace(status="member")


class FullJourneyBase(unittest.TestCase):
    def setUp(self):
        import app.database as appdb

        self.db_path = f"/tmp/full-journey-{id(self)}.db"
        Path(self.db_path).unlink(missing_ok=True)
        self.engine = create_engine(
            f"sqlite:///{self.db_path}", connect_args={"check_same_thread": False}
        )
        Base.metadata.create_all(self.engine)
        self.session = sessionmaker(bind=self.engine, future=True, expire_on_commit=False)()
        self._old_engine, self._old_sl = appdb.engine, appdb.SessionLocal
        appdb.engine = self.engine
        appdb.SessionLocal = sessionmaker(bind=self.engine, future=True, expire_on_commit=False)

        # صاحب اکانت (و همان ادمین پیش‌فرض داخل کد)
        user = User(telegram_user_id=TG_ID, first_name="صاحب")
        self.session.add(user)
        self.session.flush()
        conn = BusinessConnection(
            business_connection_id="bc-j",
            user_id=user.id,
            telegram_user_id=TG_ID,
            is_enabled=True,
            can_reply=True,
        )
        self.session.add(conn)
        self.session.flush()
        self.account = BusinessAccount(
            owner_user_id=user.id,
            business_connection_id=conn.id,
            plan=PlanType.FREE,
            is_enabled=True,
        )
        self.session.add(self.account)
        self.session.flush()
        repository.ensure_default_pricing(self.session)
        repository.set_admin_username(self.session, "Hovssin")
        self.session.commit()

    def tearDown(self):
        import app.database as appdb

        appdb.engine, appdb.SessionLocal = self._old_engine, self._old_sl
        self.session.close()
        self.engine.dispose()
        Path(self.db_path).unlink(missing_ok=True)

    # --- ابزار فشردن دکمه از طریق «روتر واقعی» ---

    def _press_router(self, text: str, menu: str | None = None):
        from app.bot import _private_text_router

        if not hasattr(self, "ctx") or self.ctx is None:
            self._fresh_ctx()
        if menu is not None:
            state.set_menu(self.ctx, menu)
        msg = _Msg(text)
        update = SimpleNamespace(
            effective_user=SimpleNamespace(id=TG_ID, first_name="صاحب"),
            effective_message=msg,
            effective_chat=SimpleNamespace(id=TG_ID, type="private"),
        )
        asyncio.run(_private_text_router(update, self.ctx))
        if msg.replies:
            self.ctx_last_reply = msg.replies[-1]
        return msg

    def _assert_press(self, text: str, menu: str | None = None):
        """دکمه را فشار می‌دهد و تضمین می‌کند «دستور نامشخص» نگیرد."""
        msg = self._press_router(text, menu)
        self.assertTrue(msg.replies, f"دکمه‌ی {text!r} هیچ پاسخی نداد!")
        self.assertNotEqual(
            msg.replies[-1],
            texts.UNKNOWN_ACTION,
            f"دکمه‌ی {text!r} به «دستور نامشخص» خورد — دکمه‌ی رندرشده بدون هندلر!",
        )
        return msg

    # --- سازنده‌های رایج ---

    def _fresh_ctx(self):
        self.bot = _Bot()
        self.ctx = SimpleNamespace(user_data={}, bot_data={}, bot=self.bot)
        self.ctx_last_reply = ""
        return self.ctx

    def _rule_label(self, rule_id: int) -> str:
        """لیبل دکمه‌ی یک قانون را تازه از دیتابیس می‌سازد (بدون آبجکت منقضی)."""
        self.session.expire_all()
        return keyboards.rule_button_label(self.session.get(Rule, rule_id))

    def _go_rules_menu(self):
        self._fresh_ctx()
        self._assert_press(texts.BTN_MANAGE_RULES, menu=state.MENU_MAIN)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_RULES)


# ---------------------------------------------------------------------------
# ۱) منوی اصلی — تک‌تک دکمه‌ها (اکانت متصل)
# ---------------------------------------------------------------------------


class MainMenuJourneyTest(FullJourneyBase):
    def test_all_main_menu_buttons_connected(self):
        kb = keyboards.main_menu_keyboard(has_business_account=True, is_admin=True)
        labels = [b.text for row in kb.keyboard for b in row]
        for label in labels:
            if label == texts.BTN_ADMIN_PANEL:
                continue  # پنل ادمین در سفر جداگانه
            self._assert_press(label, menu=state.MENU_MAIN)
            state.set_menu(self.ctx, state.MENU_MAIN)

    def test_all_main_menu_buttons_not_connected(self):
        kb = keyboards.main_menu_keyboard(has_business_account=False, is_admin=False)
        labels = [b.text for row in kb.keyboard for b in row]
        for label in labels:
            if label in (texts.BTN_MANAGE_RULES, texts.BTN_ADMIN_PANEL):
                continue  # بدون اکانت رندر نمی‌شود
            self._assert_press(label, menu=state.MENU_MAIN)
            state.set_menu(self.ctx, state.MENU_MAIN)

    def test_connect_screen_contains_trust_and_english(self):
        msg = self._assert_press(texts.BTN_CONNECT, menu=state.MENU_MAIN)
        joined = "\n".join(msg.replies)
        self.assertIn("رسمی", joined)
        self.assertIn("Before connecting", joined)
        self.assertIn("/privacy", joined)


# ---------------------------------------------------------------------------
# ۲) پنل ادمین — دکمه‌های سطح اول
# ---------------------------------------------------------------------------


class AdminPanelJourneyTest(FullJourneyBase):
    def test_all_admin_first_level_buttons(self):
        # فایل‌های بکاپ ممکن است موجود نباشند — نمونه‌ی خالی بسازیم تا ارسال خطا ندهد
        root = Path(__file__).resolve().parents[1]
        db_file, pickle_file = root / "app.db", root / "bot_persistence.pickle"
        created = []
        for f in (db_file, pickle_file):
            if not f.exists():
                f.write_bytes(b"")
                created.append(f)
        try:
            self._fresh_ctx()
            self._assert_press(texts.BTN_ADMIN_PANEL, menu=state.MENU_MAIN)
            self.assertEqual(state.get_menu(self.ctx), state.MENU_ADMIN)

            kb = keyboards.admin_panel_keyboard()
            labels = [b.text for row in kb.keyboard for b in row]
            for label in labels:
                if label == texts.BTN_BACK_TO_MENU:
                    continue
                if label == texts.BTN_ADMIN_BACKUP_NOW:
                    # بکاپ با bot.send_document ارسال می‌شود (نه reply_text) —
                    # پس «هندل‌شدن» یعنی فراخوانی ارسال فایل توسط بات:
                    before = len(self.bot.calls)
                    msg = self._press_router(label, menu=state.MENU_ADMIN)
                    self.assertGreater(
                        len(self.bot.calls),
                        before,
                        "دکمه‌ی بکاپ هیچ فایلی نفرستاد!",
                    )
                    state.set_menu(self.ctx, state.MENU_ADMIN)
                    continue
                self._assert_press(label, menu=state.MENU_ADMIN)
                state.set_menu(self.ctx, state.MENU_ADMIN)
        finally:
            for f in created:
                f.unlink()


# ---------------------------------------------------------------------------
# ۳) سفر کامل قوانین: ساخت → لیست → جزئیات → کپی → آمار → حذف
# ---------------------------------------------------------------------------


class RuleLifecycleJourneyTest(FullJourneyBase):
    def test_full_rule_lifecycle(self):
        self._go_rules_menu()

        # ➕ افزودن قانون (کاربر Free: بدون مرحله‌ی عکس)
        self._assert_press(texts.BTN_RULE_ADD, menu=state.MENU_RULES)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_RULE_ADD_TRIGGER_TYPE)
        self._assert_press(texts.BTN_TRIGGER_EXACT, menu=state.MENU_RULE_ADD_TRIGGER_TYPE)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_RULE_ADD_TRIGGER_VALUE)
        self._assert_press("قیمت", menu=state.MENU_RULE_ADD_TRIGGER_VALUE)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_RULE_ADD_RESPONSE_TEXT)
        self._assert_press("لیست قیمت 👇", menu=state.MENU_RULE_ADD_RESPONSE_TEXT)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_RULES)

        self.session.expire_all()
        rules = repository.list_rules(self.session, self.account.id)
        custom = [r for r in rules if not r.is_system]
        self.assertEqual(len(custom), 1)
        first_id = custom[0].id
        self.assertEqual(custom[0].trigger_value, "قیمت")
        self.assertFalse(custom[0].requires_pro)  # کاربر Free

        def _custom_ids():
            self.session.expire_all()
            return [
                r.id
                for r in repository.list_rules(self.session, self.account.id)
                if not r.is_system
            ]

        # بازکردن جزئیات از روی دکمه‌ی لیست + تغییر وضعیت
        self._assert_press(self._rule_label(first_id), menu=state.MENU_RULES)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_RULE_DETAIL)
        self._assert_press(texts.BTN_RULE_TOGGLE, menu=state.MENU_RULE_DETAIL)
        self.session.expire_all()
        self.assertFalse(
            self.session.get(Rule, first_id).enabled, "تغییر وضعیت اعمال نشد"
        )
        self._assert_press(texts.BTN_RULE_TOGGLE, menu=state.MENU_RULE_DETAIL)

        # 📄 کپی — باید قانون دوم ساخته شود و به لیست برگردد
        self._assert_press(texts.BTN_RULE_COPY, menu=state.MENU_RULE_DETAIL)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_RULES)
        ids = _custom_ids()
        self.assertEqual(len(ids), 2)
        copy_id = next(i for i in ids if i != first_id)

        # 🎯 آمار در جزئیات — خط «دفعات اجرا» باید باشد
        msg = self._assert_press(self._rule_label(first_id), menu=state.MENU_RULES)
        self.assertIn("دفعات اجرا", msg.replies[-1])

        # 🗑 حذف قانون اول — کپی باید بماند
        self._assert_press(texts.BTN_RULE_DELETE, menu=state.MENU_RULE_DETAIL)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_RULES)
        self.assertEqual(_custom_ids(), [copy_id])


# ---------------------------------------------------------------------------
# ۴) شبیه‌ساز + ⏸ توقف/از سرگیری همه
# ---------------------------------------------------------------------------


class TesterAndPauseJourneyTest(FullJourneyBase):
    def test_tester_preview_then_pause_resume_all(self):
        # یک قانون می‌سازیم (خلاصه‌ی مسیرLifecycle بدون ادعا)
        self.session.add(
            Rule(
                business_account_id=self.account.id,
                trigger_type=TriggerType.CONTAINS,
                trigger_value="قیمت",
                response_text="لیست قیمت 👇",
                enabled=True,
                is_system=False,
                requires_pro=False,
            )
        )
        self.session.commit()

        self._go_rules_menu()
        self._assert_press(texts.BTN_RULE_TEST, menu=state.MENU_RULES)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_RULE_TEST)
        msg = self._assert_press("سلام قیمت دارید؟", menu=state.MENU_RULE_TEST)
        self.assertIn("اجرا می‌شد", "\n".join(msg.replies))
        self.assertIn("لیست قیمت 👇", "\n".join(msg.replies))
        self._assert_press(texts.BTN_BACK_TO_RULES, menu=state.MENU_RULE_TEST)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_RULES)

        # ⏸ توقف همه — با یک کلید
        self._assert_press(texts.BTN_RULES_PAUSE_ALL, menu=state.MENU_RULES)
        self.session.expire_all()
        self.assertTrue(
            self.session.get(BusinessAccount, self.account.id).auto_reply_paused
        )
        # کیبورد جدید باید دکمه‌ی ▶️ داشته باشد
        last_markup = None
        # (آخرین reply_markup از مسیر show_rules_menu)
        self._assert_press(texts.BTN_RULES_RESUME_ALL, menu=state.MENU_RULES)
        self.session.expire_all()
        self.assertFalse(
            self.session.get(BusinessAccount, self.account.id).auto_reply_paused
        )


# ---------------------------------------------------------------------------
# ۵) سفر خرید: پلن → مدت → پیام پرداخت
# ---------------------------------------------------------------------------


class BuyFlowJourneyTest(FullJourneyBase):
    def test_buy_pro_flow_reaches_admin_payment_message(self):
        self._fresh_ctx()
        self._assert_press(texts.BTN_BUY_PRO, menu=state.MENU_MAIN)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_BUY_PLAN_CHOICE)
        self._assert_press(texts.BTN_PLAN_PRO, menu=state.MENU_BUY_PLAN_CHOICE)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_BUY_DURATION_CHOICE)

        options = repository.list_pricing_options(
            self.session, plan=PlanType.PRO, only_enabled=True
        )
        self.assertTrue(options)
        label = keyboards.pricing_duration_option_label(
            options[0].duration_days, options[0].price, options[0].id
        )
        msg = self._assert_press(label, menu=state.MENU_BUY_DURATION_CHOICE)
        self.assertIn("t.me/Hovssin", "\n".join(msg.replies))
        # بعد از خرید، به منوی اصلی برمی‌گردد
        self.assertEqual(state.get_menu(self.ctx), state.MENU_MAIN)


# ---------------------------------------------------------------------------
# ۶) نگهبان شبانه — سفر کامل از طریق روتر
# ---------------------------------------------------------------------------


class NightGuardRouterJourneyTest(FullJourneyBase):
    def test_night_guard_full_setup(self):
        self._go_rules_menu()
        self._assert_press(texts.BTN_NIGHT_GUARD, menu=state.MENU_RULES)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_NIGHT_GUARD)

        # متن شب
        self._assert_press(texts.BTN_NIGHT_TEXT, menu=state.MENU_NIGHT_GUARD)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_NIGHT_GUARD_TEXT)
        self._assert_press("بسته‌ایم 🌙 صبح می‌آیم", menu=state.MENU_NIGHT_GUARD_TEXT)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_NIGHT_GUARD)

        # ساعت شروع: اول نامعتبر (در منو می‌ماند) بعد معتبر
        state.set_menu(self.ctx, state.MENU_NIGHT_GUARD_START)
        msg = self._assert_press("25:99", menu=state.MENU_NIGHT_GUARD_START)
        self.assertIn("درست نیست", "\n".join(msg.replies))
        self._assert_press("23:00", menu=state.MENU_NIGHT_GUARD_START)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_NIGHT_GUARD)

        # ساعت پایان
        self._assert_press(texts.BTN_NIGHT_END, menu=state.MENU_NIGHT_GUARD)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_NIGHT_GUARD_END)
        self._assert_press("9:30", menu=state.MENU_NIGHT_GUARD_END)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_NIGHT_GUARD)

        # فعال‌سازی و خاموشی
        self._assert_press(texts.BTN_NIGHT_ON, menu=state.MENU_NIGHT_GUARD)
        self.session.expire_all()
        acc = self.session.get(BusinessAccount, self.account.id)
        self.assertTrue(acc.night_guard_enabled)
        self.assertEqual(acc.night_guard_text, "بسته‌ایم 🌙 صبح می‌آیم")
        self._assert_press(texts.BTN_NIGHT_OFF, menu=state.MENU_NIGHT_GUARD)
        self.session.expire_all()
        self.assertFalse(
            self.session.get(BusinessAccount, self.account.id).night_guard_enabled
        )


# ---------------------------------------------------------------------------
# ۷) «هر پیامی به غیر از اینا» + کیبورد تریگر
# ---------------------------------------------------------------------------


class FallbackJourneyTest(FullJourneyBase):
    def test_fallback_menu_flow(self):
        self._go_rules_menu()
        self._assert_press(texts.BTN_FALLBACK_REPLY, menu=state.MENU_RULES)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_FALLBACK_REPLY)

        # ✍️ نوشتن متن
        self._assert_press(texts.BTN_FALLBACK_EDIT, menu=state.MENU_FALLBACK_REPLY)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_FALLBACK_REPLY_EDIT)
        self._assert_press("به‌زودی جواب می‌دهیم 🌱", menu=state.MENU_FALLBACK_REPLY_EDIT)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_FALLBACK_REPLY)

        # 🔔 فعال / 🔕 غیرفعال
        self._assert_press(texts.BTN_FALLBACK_TOGGLE_ON, menu=state.MENU_FALLBACK_REPLY)
        self.session.expire_all()
        self.assertTrue(
            self.session.get(BusinessAccount, self.account.id).customer_reply_enabled
        )
        self._assert_press(texts.BTN_FALLBACK_TOGGLE_OFF, menu=state.MENU_FALLBACK_REPLY)
        self.session.expire_all()
        self.assertFalse(
            self.session.get(BusinessAccount, self.account.id).customer_reply_enabled
        )

    def test_trigger_keyboard_fallback_button_routes(self):
        self._go_rules_menu()
        self._assert_press(texts.BTN_RULE_ADD, menu=state.MENU_RULES)
        # دکمه‌ی «💬 هر پیامی به غیر از اینا» داخل کیبورد تریگر → باید به منوی fallback برود
        self._assert_press(texts.BTN_TRIGGER_FALLBACK, menu=state.MENU_RULE_ADD_TRIGGER_TYPE)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_FALLBACK_REPLY)


# ---------------------------------------------------------------------------
# ۷٫۵) 🟢 پیام «سلام» — زیرمنوی انتخاب زبان (فارسی/انگلیسی/خاموش)
# ---------------------------------------------------------------------------


class SalamLanguageJourneyTest(FullJourneyBase):
    def setUp(self):
        super().setUp()
        repository.ensure_free_default_rule(self.session, self.account)
        self.session.commit()

    def _salam_rule(self):
        self.session.expire_all()
        return next(
            r
            for r in repository.list_rules(self.session, self.account.id)
            if r.is_system
        )

    def test_hello_button_opens_language_picker_and_choices_apply(self):
        self._go_rules_menu()

        # لمس دکمه‌ی «سلام» → زیرمنوی انتخاب زبان (نه تاگل مستقیم)
        self._assert_press(texts.BTN_FREE_HELLO_RULE_ON, menu=state.MENU_RULES)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_SALAM_LANG)
        self.assertIn("pick its language", self.ctx_last_reply)

        # 🇮🇷 فارسی → تریگر «سلام» + پاسخ فارسی
        self._assert_press(texts.BTN_SALAM_SET_FA, menu=state.MENU_SALAM_LANG)
        rule = self._salam_rule()
        self.assertTrue(rule.enabled)
        self.assertEqual(rule.response_text, texts.SALAM_RESPONSE_FA)
        self.assertEqual(rule.trigger_value, texts.SALAM_TRIGGER_FA)

        # 🇬🇧 انگلیسی → تریگر «hello» + پاسخ انگلیسی (همان زیرمنو، بدون خروج)
        self._assert_press(texts.BTN_SALAM_SET_EN, menu=state.MENU_SALAM_LANG)
        rule = self._salam_rule()
        self.assertTrue(rule.enabled)
        self.assertEqual(rule.response_text, texts.SALAM_RESPONSE_EN)
        self.assertEqual(rule.trigger_value, texts.SALAM_TRIGGER_EN)

        # 🔴 خاموش
        self._assert_press(texts.BTN_SALAM_TURN_OFF, menu=state.MENU_SALAM_LANG)
        rule = self._salam_rule()
        self.assertFalse(rule.enabled)
        # متن و تریگر انتخابی حفظ می‌شوند
        self.assertEqual(rule.response_text, texts.SALAM_RESPONSE_EN)
        self.assertEqual(rule.trigger_value, texts.SALAM_TRIGGER_EN)

        # 🔙 بازگشت به لیست قوانین
        self._assert_press(texts.BTN_BACK_TO_RULES, menu=state.MENU_SALAM_LANG)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_RULES)

    def _engine_rule(self):
        from app.models import ResponseMediaType
        from app.rule_engine import EngineRule

        rule = self._salam_rule()
        return EngineRule(
            id=rule.id,
            trigger_type=rule.trigger_type,
            trigger_value=rule.trigger_value,
            response_text=rule.response_text,
            response_media_type=ResponseMediaType.NONE,
            enabled=rule.enabled,
            requires_pro=rule.requires_pro,
            is_system=rule.is_system,
        )

    def test_engine_sends_owner_chosen_language_to_customer(self):
        """انگلیسی: مشتریِ «hello» (هر حالت حروف) → پاسخ انگلیسی؛ «سلام» دیگر مچ نمی‌شود."""
        from app.rule_engine import EngineContext, match_rule

        self._press_router(texts.BTN_SALAM_SET_EN, menu=state.MENU_SALAM_LANG)
        er = self._engine_rule()
        self.assertEqual(er.trigger_value, "hello")

        for word in ("hello", "Hello", "HELLO"):
            matched = match_rule(EngineContext(is_pro=False, incoming_text=word, rules=(er,)))
            self.assertIsNotNone(matched, word)
            self.assertEqual(matched.response_text, texts.SALAM_RESPONSE_EN)

        # تریگر عوض شده: «سلام» دیگر مچ نمی‌شود
        self.assertIsNone(
            match_rule(EngineContext(is_pro=False, incoming_text="سلام", rules=(er,)))
        )

    def test_engine_persian_choice_triggers_on_salam(self):
        """فارسی: مشتریِ «سلام» → پاسخ فارسی؛ «hello» مچ نمی‌شود."""
        from app.rule_engine import EngineContext, match_rule

        self._press_router(texts.BTN_SALAM_SET_FA, menu=state.MENU_SALAM_LANG)
        er = self._engine_rule()
        self.assertEqual(er.trigger_value, "سلام")
        matched = match_rule(EngineContext(is_pro=False, incoming_text="سلام", rules=(er,)))
        self.assertIsNotNone(matched)
        self.assertEqual(matched.response_text, texts.SALAM_RESPONSE_FA)
        self.assertIsNone(
            match_rule(EngineContext(is_pro=False, incoming_text="hello", rules=(er,)))
        )


# ---------------------------------------------------------------------------
# ۷٫۹) 🌍 منطقه زمانی نگهبان شبانه — دکمه + ورود متنی آزاد
# ---------------------------------------------------------------------------


class NightGuardTZJourneyTest(FullJourneyBase):
    def test_timezone_button_save_invalid_and_cancel(self):
        self._go_rules_menu()
        self._assert_press(texts.BTN_NIGHT_GUARD, menu=state.MENU_RULES)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_NIGHT_GUARD)

        # دکمه‌ی 🌍 → پیام راهنما با نمونه‌ی asia/Tehran
        self._assert_press(texts.BTN_NIGHT_TZ, menu=state.MENU_NIGHT_GUARD)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_NIGHT_GUARD_TZ)
        self.assertIn("asia/Tehran", self.ctx_last_reply)

        # ذخیره — حروف کوچک + فاصله به‌جای _
        msg = self._press_router("europe berlin", menu=state.MENU_NIGHT_GUARD_TZ)
        self.assertIn("Time zone saved", "\n".join(msg.replies))
        self.session.expire_all()
        acc = self.session.get(BusinessAccount, self.account.id)
        self.assertEqual(acc.night_guard_timezone, "Europe/Berlin")

        # نامعتبر → پیام خطا و ماندن در منو، بدون تغییر منطقه
        msg = self._press_router("Mars/Phobos", menu=state.MENU_NIGHT_GUARD_TZ)
        joined = "\n".join(msg.replies)
        self.assertIn("couldn't find", joined)
        self.session.expire_all()
        self.assertEqual(
            self.session.get(BusinessAccount, self.account.id).night_guard_timezone,
            "Europe/Berlin",
        )

        # انصراف → بازگشت به منوی نگهبان
        self._assert_press(texts.BTN_CANCEL, menu=state.MENU_NIGHT_GUARD_TZ)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_NIGHT_GUARD)

    def test_night_guard_menu_shows_timezone_and_start_uses_it(self):
        # منوی نگهبان باید منطقه‌ی فعلی و ساعت همان‌جا را نشان دهد
        self._go_rules_menu()
        self._assert_press(texts.BTN_NIGHT_GUARD, menu=state.MENU_RULES)
        self.assertIn("Asia/Tehran", self.ctx_last_reply)
        # ⏰ ساعت شروع → پیام باید منطقه را ذکر کند
        self._assert_press(texts.BTN_NIGHT_START, menu=state.MENU_NIGHT_GUARD)
        self.assertIn("Asia/Tehran", self.ctx_last_reply)


# ---------------------------------------------------------------------------
# ۸) کیبورد قدیمی کاربران + بازگشت سراسری
# ---------------------------------------------------------------------------


class LegacyAndGlobalJourneyTest(FullJourneyBase):
    def test_old_persian_only_button_gets_friendly_unknown(self):
        """کاربران قدیمی کیبورد فارسی-تنها دارند؛ باید «دستور نامشخص» دو‌زبانه با
        پیشنهاد /start بگیرند (رفتار مورد انتظار، نه کرش)."""
        msg = self._press_router("⚙️ مدیریت قوانین", menu=state.MENU_MAIN)
        self.assertEqual(msg.replies[-1], texts.UNKNOWN_ACTION)
        self.assertIn("/start", msg.replies[-1])

    def test_back_to_menu_from_anywhere(self):
        self._go_rules_menu()
        self._assert_press(texts.BTN_RULE_TEST, menu=state.MENU_RULES)
        self._assert_press(texts.BTN_BACK_TO_MENU, menu=state.MENU_RULE_TEST)
        self.assertEqual(state.get_menu(self.ctx), state.MENU_MAIN)

    def test_pricing_buttons_bilingual_extract_id_intact(self):
        """دکمه‌های دوزبانه نباید extract_id را بشکنند (قوانین/مدت‌ها با #id مسیریابی می‌شوند)."""
        rule = Rule(
            business_account_id=self.account.id,
            trigger_type=TriggerType.CONTAINS,
            trigger_value="قیمت",
            response_text="لیست",
            enabled=True,
            is_system=False,
            requires_pro=False,
        )
        self.session.add(rule)
        self.session.commit()
        label = keyboards.rule_button_label(rule)
        self.assertIsNotNone(keyboards.extract_id(label))

        opt = repository.list_pricing_options(self.session, plan=PlanType.PRO, only_enabled=True)[0]
        plabel = keyboards.pricing_duration_option_label(opt.duration_days, opt.price, opt.id)
        self.assertEqual(keyboards.extract_id(plabel), opt.id)


if __name__ == "__main__":
    unittest.main()
