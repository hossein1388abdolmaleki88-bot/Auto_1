"""
تست‌های تغییرات جدید لایه‌ی Repository (۱۴۰۵/۰۶/۱۰):

  ۱) سقف قانون Free «زنده» است — هر وقت ادمین آن را عوض کند، همین لحظه برای
     کاربران Free اعمال می‌شود (برخلاف سقف Pro که تا پایان دوره‌ی فعلی قفل است).
  ۲) حذف کاربر از پنل ادمین:
       - وقتی یک شخص دو حساب (اتصال دوباره) دارد، حذف یکی دیگری را نگه می‌دارد
         و رکورد User هم می‌ماند.
       - اگر آخرین حسابِ کاربر حذف شود، خودِ User هم پاک می‌شود.
  ۳) غیرفعال‌سازی نرم هنگام قطع دسترسی:
       - با قطع دسترسی، اکانت از «لیست کاربران» ادمین حذف می‌شود ولی قوانین و
         پلن حفظ می‌شود.
       - با اتصال مجدد، همان اکانت (بدون اکانت تکراری) با تمام داده‌ها بازیابی
         می‌شود.
       - بعد از ۳۰ روز بدون بازگشت، job پاک‌سازی آن را حذف کامل می‌کند.

بدون وابستگی به app.database (تا روی هر محیطی بدون تنظیم DATABASE_URL اجرا شود)
با یک SQLite درون‌حافظه‌ی مستقل کار می‌کند.
"""
import sys
import unittest
from datetime import timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app import repository
from app.models import (
    Base,
    ResponseMediaType,
    BusinessAccount,
    BusinessConnection,
    CustomerChat,
    MessageDirection,
    MessageLog,
    MessageStatus,
    PlanType,
    Rule,
    RuleMedia,
    TriggerType,
    User,
    utcnow,
)


_ENGINES: list = []


def make_session():
    engine = create_engine("sqlite:///:memory:")
    _ENGINES.append(engine)
    Base.metadata.create_all(engine)
    session = sessionmaker(bind=engine, future=True, expire_on_commit=False)()
    return session


class RepositoryTestBase(unittest.TestCase):
    def tearDown(self) -> None:
        for engine in _ENGINES:
            engine.dispose()
        _ENGINES.clear()


def seed_account(session, telegram_user_id: int, bc_id: str) -> tuple[User, BusinessConnection, BusinessAccount]:
    user = User(telegram_user_id=telegram_user_id, first_name="Test")
    session.add(user)
    session.flush()
    conn = BusinessConnection(
        business_connection_id=bc_id,
        user_id=user.id,
        telegram_user_id=telegram_user_id,
        is_enabled=True,
        can_reply=True,
    )
    session.add(conn)
    session.flush()
    account = BusinessAccount(
        owner_user_id=user.id,
        business_connection_id=conn.id,
        plan=PlanType.FREE,
        is_enabled=True,
    )
    session.add(account)
    session.flush()
    repository.lock_rule_limit_for_current_period(session, account)
    session.flush()
    return user, conn, account


def seed_account_for_existing_user(
    session, user: User, bc_id: str
) -> tuple[BusinessConnection, BusinessAccount]:
    """سناریوی «اتصال دوباره»: همان User قبلی، اما با business_connection_id جدید
    (چون تلگرام بعد از قطع و وصل، یک اتصال جدید می‌سازد)."""
    conn = BusinessConnection(
        business_connection_id=bc_id,
        user_id=user.id,
        telegram_user_id=user.telegram_user_id,
        is_enabled=True,
        can_reply=True,
    )
    session.add(conn)
    session.flush()
    account = BusinessAccount(
        owner_user_id=user.id,
        business_connection_id=conn.id,
        plan=PlanType.FREE,
        is_enabled=True,
    )
    session.add(account)
    session.flush()
    repository.lock_rule_limit_for_current_period(session, account)
    session.flush()
    return conn, account


class FreeLimitLiveTest(RepositoryTestBase):
    def test_free_limit_change_applies_immediately(self):
        session = make_session()
        _, _, account = seed_account(session, 111, "bc-1")

        # مقدار اولیه (پیش‌فرض ۲) قفل می‌شود
        repository.set_free_rule_limit(session, 2)
        session.flush()
        self.assertEqual(repository.get_rule_limit_for_account(session, account), 2)

        # ادمین سقف Free را عوض می‌کند → همین لحظه برای کاربر Free اعمال می‌شود
        # (با اینکه locked_rule_limit هنوز ۲ است)
        repository.set_free_rule_limit(session, 7)
        session.flush()
        self.assertEqual(repository.get_rule_limit_for_account(session, account), 7)
        self.assertEqual(account.locked_rule_limit, 2)  # قفل قدیمی دیگر خوانده نمی‌شود

        # کاهش هم همین‌طور فوری است
        repository.set_free_rule_limit(session, 1)
        session.flush()
        self.assertEqual(repository.get_rule_limit_for_account(session, account), 1)
        session.close()

    def test_pro_limit_stays_locked_per_period(self):
        session = make_session()
        _, _, account = seed_account(session, 222, "bc-2")

        # فعال‌سازی Pro → سقف Pro فعلی (پیش‌فرض ۱۵) قفل می‌شود
        repository.set_pro_rule_limit(session, 15)
        session.flush()
        repository.activate_pro(session, account, plan=PlanType.PRO, duration_days=30)
        session.flush()
        self.assertEqual(repository.get_rule_limit_for_account(session, account), 15)

        # ادمین سقف سراسری Pro را عوض می‌کند → روی دوره‌ی جاریِ فعال اثر ندارد
        repository.set_pro_rule_limit(session, 40)
        session.flush()
        self.assertEqual(repository.get_rule_limit_for_account(session, account), 15)
        session.close()

    def test_pro_max_unlimited(self):
        session = make_session()
        _, _, account = seed_account(session, 333, "bc-3")
        repository.activate_pro(session, account, plan=PlanType.PRO_MAX, duration_days=30)
        session.flush()
        self.assertIsNone(repository.get_rule_limit_for_account(session, account))
        session.close()


class DeleteAccountTest(RepositoryTestBase):
    def test_delete_one_of_two_keeps_the_other_and_user(self):
        session = make_session()
        # سناریوی واقعی: یک شخص قطع و دوباره وصل شده → دو حساب برای یک User
        user1, conn1, account1 = seed_account(session, 444, "bc-old")
        conn2, account2 = seed_account_for_existing_user(session, user1, "bc-new")
        self.assertNotEqual(account1.id, account2.id)

        # چند داده‌ی وابسته به حساب اول اضافه می‌کنیم تا حذف cascade را چک کنیم
        rule = Rule(
            business_account_id=account1.id,
            trigger_type=TriggerType.EXACT,
            trigger_value="hi",
            response_text="hello",
        )
        session.add(rule)
        session.flush()
        session.add(RuleMedia(rule_id=rule.id, media_type="PHOTO", telegram_file_id="f1", sort_order=0))
        session.add(
            CustomerChat(
                business_account_id=account1.id, telegram_chat_id=999, first_message_at=utcnow()
            )
        )
        session.add(
            MessageLog(
                business_account_id=account1.id,
                telegram_chat_id=999,
                telegram_message_id=1,
                direction=MessageDirection.INCOMING,
                text="hi",
                matched_rule_id=rule.id,
                status=MessageStatus.SUCCESS,
            )
        )
        session.flush()

        ok = repository.delete_business_account(session, account1.id)
        session.flush()
        self.assertTrue(ok)

        # حساب اول (قدیمی) و همه‌ی داده‌هایش حذف شده‌اند
        self.assertIsNone(session.get(BusinessAccount, account1.id))
        self.assertIsNone(session.get(BusinessConnection, conn1.id))
        self.assertIsNone(session.get(Rule, rule.id))
        self.assertIsNone(session.query(RuleMedia).filter(RuleMedia.rule_id == rule.id).first())
        self.assertIsNone(session.query(CustomerChat).filter(CustomerChat.business_account_id == account1.id).first())
        self.assertIsNone(session.query(MessageLog).filter(MessageLog.business_account_id == account1.id).first())

        # حساب دوم (جدید) و User سر جایش می‌مانند
        self.assertIsNotNone(session.get(BusinessAccount, account2.id))
        self.assertIsNotNone(session.get(BusinessConnection, conn2.id))
        self.assertIsNotNone(session.get(User, user1.id))
        session.close()

    def test_delete_last_account_removes_user(self):
        session = make_session()
        user, conn, account = seed_account(session, 555, "bc-single")
        self.assertTrue(repository.delete_business_account(session, account.id))
        session.flush()
        self.assertIsNone(session.get(BusinessAccount, account.id))
        self.assertIsNone(session.get(BusinessConnection, conn.id))
        self.assertIsNone(session.get(User, user.id))
        session.close()

    def test_delete_missing_account_returns_false(self):
        session = make_session()
        self.assertFalse(repository.delete_business_account(session, 999999))
        session.close()


class DisconnectSoftRemoveTest(RepositoryTestBase):
    """غیرفعال‌سازی نرم هنگام قطع دسترسی (درخواست ادمین): کاربر همان لحظه از
    «لیست کاربران» ادمین حذف می‌شود ولی قوانین و وضعیت پلن تا مهلت بازیابی حفظ
    می‌شود تا اگر دوباره وصل شد، همه‌چیز برگردد (بدون اکانت تکراری)."""

    def _seed_with_rule(self, session, telegram_user_id: int, bc_id: str):
        user, conn, account = seed_account(session, telegram_user_id, bc_id)
        rule = Rule(
            business_account_id=account.id,
            trigger_type=TriggerType.EXACT,
            trigger_value="hi",
            response_text="hello",
        )
        session.add(rule)
        session.flush()
        return user, conn, account, rule

    def test_disconnect_removes_from_admin_list_but_keeps_data(self):
        session = make_session()
        user, conn, account, rule = self._seed_with_rule(session, 888, "bc-soft")

        ok = repository.disconnect_business_account(session, "bc-soft")
        session.flush()
        self.assertTrue(ok)

        # اکانت حذف نشده؛ فقط غیرفعال شده و قوانین/پلن/کاربر سر جایش‌اند
        acc = session.get(BusinessAccount, account.id)
        self.assertIsNotNone(acc)
        self.assertFalse(acc.is_enabled)
        self.assertIsNotNone(acc.disconnected_at)
        self.assertIsNotNone(session.get(Rule, rule.id))
        self.assertIsNotNone(session.get(User, user.id))
        self.assertFalse(session.get(BusinessConnection, conn.id).is_enabled)

        # از «لیست کاربران» ادمین و شمارش حذف شده
        self.assertEqual(repository.count_business_accounts(session), 0)
        self.assertEqual(repository.list_all_business_accounts_full(session), [])
        self.assertTrue(repository.has_disconnected_account(session, user.id))
        session.close()

    def test_disconnect_missing_connection_returns_false(self):
        session = make_session()
        self.assertFalse(repository.disconnect_business_account(session, "bc-nope"))
        session.close()

    def test_reconnect_reactivates_same_account_and_preserves_data(self):
        session = make_session()
        user, conn_old, account, rule = self._seed_with_rule(session, 999, "bc-old")
        repository.activate_pro(session, account, plan=PlanType.PRO, duration_days=30)
        session.flush()
        pro_until = account.pro_until

        # کاربر دسترسی را قطع می‌کند → غیرفعال‌سازی نرم
        repository.disconnect_business_account(session, "bc-old")
        session.flush()

        # کاربر برمی‌گردد: تلگرام اتصال جدیدی می‌سازد (business_connection_id جدید)
        conn_new = repository.upsert_business_connection(
            session,
            business_connection_id="bc-new",
            user=user,
            telegram_user_id=user.telegram_user_id,
            is_enabled=True,
            can_reply=True,
        )
        session.flush()

        # همان اکانت قبلی دوباره فعال شده (نه اکانت تازه) و داده‌ها حفظ شده‌اند
        acc = session.get(BusinessAccount, account.id)
        self.assertIsNotNone(acc)
        self.assertTrue(acc.is_enabled)
        self.assertIsNone(acc.disconnected_at)
        self.assertEqual(acc.business_connection_id, conn_new.id)
        self.assertEqual(acc.pro_until, pro_until)  # پلن حفظ شده
        self.assertIsNotNone(session.get(Rule, rule.id))  # قانون حفظ شده

        # فقط یک اکانت برای این کاربر — بدون حساب تکراری
        self.assertEqual(len(repository.get_business_accounts_for_user(session, user.id)), 1)

        # دوباره در لیست ادمین است
        self.assertEqual(repository.count_business_accounts(session), 1)
        self.assertFalse(repository.has_disconnected_account(session, user.id))
        session.close()

    def test_purge_deletes_only_past_grace_period(self):
        session = make_session()
        # اکانتی که ۳۱ روز پیش قطع شده → پاک شود
        user1, _, account1 = seed_account(session, 1010, "bc-purge1")
        repository.disconnect_business_account(session, "bc-purge1")
        session.flush()
        session.get(BusinessAccount, account1.id).disconnected_at = utcnow() - timedelta(days=31)
        session.flush()
        # اکانتی که همین الان قطع شده → بماند
        user2, _, account2 = seed_account(session, 1111, "bc-purge2")
        repository.disconnect_business_account(session, "bc-purge2")
        session.flush()

        count = repository.purge_disconnected_accounts(session)
        session.flush()
        self.assertEqual(count, 1)
        self.assertIsNone(session.get(BusinessAccount, account1.id))
        self.assertIsNone(session.get(User, user1.id))
        self.assertIsNotNone(session.get(BusinessAccount, account2.id))
        self.assertIsNotNone(session.get(User, user2.id))
        session.close()


class MainMenuKeyboardTest(unittest.TestCase):
    """تغییرات منوی اصلی: دکمه‌ی «اتصال اکانت» فقط وقتی کاربر اتصال ندارد نمایش داده می‌شود."""

    def _labels(self, keyboard) -> list[str]:
        return [button.text for row in keyboard.keyboard for button in row]

    def test_connect_button_hidden_when_connected(self):
        from app import keyboards, texts

        kb = keyboards.main_menu_keyboard(has_business_account=True, is_admin=False)
        labels = self._labels(kb)
        self.assertNotIn(texts.BTN_CONNECT, labels)
        self.assertIn(texts.BTN_MANAGE_RULES, labels)
        self.assertIn(texts.BTN_BUY_PRO, labels)

    def test_connect_button_shown_when_not_connected(self):
        from app import keyboards, texts

        kb = keyboards.main_menu_keyboard(has_business_account=False, is_admin=False)
        labels = self._labels(kb)
        self.assertIn(texts.BTN_CONNECT, labels)
        self.assertNotIn(texts.BTN_MANAGE_RULES, labels)
        self.assertIn(texts.BTN_BUY_PRO, labels)

    def test_admin_button_always_shown_for_admin(self):
        from app import keyboards, texts

        kb = keyboards.main_menu_keyboard(has_business_account=True, is_admin=True)
        self.assertIn(texts.BTN_ADMIN_PANEL, self._labels(kb))


class RuleMatchCountTest(RepositoryTestBase):
    """🎯 آمار اجرای هر قانون: فقط «ورودیِ موفقِ» Match‌شده با آن قانون شمرده می‌شود."""

    def _rule(self, session, account):
        rule = Rule(
            business_account_id=account.id,
            trigger_type=TriggerType.EXACT,
            trigger_value="hi",
            response_text="hello",
        )
        session.add(rule)
        session.flush()
        return rule

    def _log(self, session, account, rule, msg_id, direction, status):
        session.add(
            MessageLog(
                business_account_id=account.id,
                telegram_chat_id=999,
                telegram_message_id=msg_id,
                direction=direction,
                text="hi" if direction == MessageDirection.INCOMING else None,
                matched_rule_id=rule.id,
                status=status,
            )
        )

    def test_counts_only_successful_incoming_matches(self):
        session = make_session()
        _, _, account = seed_account(session, 2020, "bc-stats")
        rule = self._rule(session, account)

        self._log(session, account, rule, 1, MessageDirection.INCOMING, MessageStatus.SUCCESS)
        self._log(session, account, rule, 2, MessageDirection.INCOMING, MessageStatus.SUCCESS)
        self._log(session, account, rule, 3, MessageDirection.INCOMING, MessageStatus.IGNORED)   # بی‌جواب مانده
        self._log(session, account, rule, 4, MessageDirection.OUTGOING, MessageStatus.SUCCESS)   # پاسخ خروجی — دوباره‌شمارش نشود
        # قانون دیگری که پیام متفاوتی را جواب داده — نباید در شمارش قانون اول بیاید
        other = Rule(
            business_account_id=account.id,
            trigger_type=TriggerType.CONTAINS,
            trigger_value="قیمت",
            response_text="list",
        )
        session.add(other)
        session.flush()
        self._log(session, account, other, 5, MessageDirection.INCOMING, MessageStatus.SUCCESS)
        session.flush()

        self.assertEqual(repository.count_rule_matches(session, rule.id), 2)
        self.assertEqual(repository.count_rule_matches(session, 999999), 0)
        session.close()

    def test_count_is_zero_for_fresh_rule(self):
        session = make_session()
        _, _, account = seed_account(session, 2021, "bc-stats2")
        rule = self._rule(session, account)
        self.assertEqual(repository.count_rule_matches(session, rule.id), 0)
        session.close()


class DuplicateRuleTest(RepositoryTestBase):
    """📄 کپی قانون: شرط/پاسخ/عکس‌ها/اولویت کپی می‌شود؛ کپی جدید فعال است."""

    def test_duplicate_copies_everything_and_is_enabled(self):
        session = make_session()
        _, _, account = seed_account(session, 3030, "bc-dup")
        rule = Rule(
            business_account_id=account.id,
            trigger_type=TriggerType.CONTAINS,
            trigger_value="قیمت",
            response_text="لیست قیمت:",
            response_media_type=ResponseMediaType.TEXT_AND_PHOTOS,
            priority=3,
            enabled=True,
            is_system=False,
            requires_pro=True,
        )
        session.add(rule)
        session.flush()
        session.add(RuleMedia(rule_id=rule.id, media_type="PHOTO", telegram_file_id="f1", sort_order=0))
        session.add(RuleMedia(rule_id=rule.id, media_type="PHOTO", telegram_file_id="f2", sort_order=1))
        session.flush()

        copy = repository.duplicate_rule(session, rule)
        session.flush()

        self.assertNotEqual(copy.id, rule.id)
        self.assertEqual(copy.business_account_id, rule.business_account_id)
        self.assertEqual(copy.trigger_type, TriggerType.CONTAINS)
        self.assertEqual(copy.trigger_value, "قیمت")
        self.assertEqual(copy.response_text, "لیست قیمت:")
        self.assertEqual(copy.priority, 3)
        self.assertTrue(copy.enabled)
        self.assertFalse(copy.is_system)
        self.assertEqual(
            [m.telegram_file_id for m in copy.media_items],
            ["f1", "f2"],
        )
        session.close()

    def test_duplicate_of_disabled_rule_still_starts_enabled(self):
        session = make_session()
        _, _, account = seed_account(session, 3031, "bc-dup2")
        rule = Rule(
            business_account_id=account.id,
            trigger_type=TriggerType.EXACT,
            trigger_value="salam",
            response_text="hi",
            enabled=False,
        )
        session.add(rule)
        session.flush()
        copy = repository.duplicate_rule(session, rule)
        session.flush()
        self.assertTrue(copy.enabled)
        session.close()


if __name__ == "__main__":
    unittest.main()
