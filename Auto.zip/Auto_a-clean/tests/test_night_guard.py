"""
تست‌های 🌙 نگهبان شبانه.

سه لایه:
    ۱) منطق خالص (بازه، پارس ساعت، وضعیت یک‌بار-در-شب) — بدون dependency
    ۲) لایه‌ی repository (ذخیره/خواندن تنظیمات و وضعیت ارسال)
    ۳) انتگرال: مسیر کامل on_business_message با اشیای تلگرامِ شبیه‌سازی‌شده
"""
import asyncio
import json
import sys
import unittest
from pathlib import Path as _Path
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

Path = _Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app import repository
from app.models import (
    Base,
    BusinessAccount,
    BusinessConnection,
    MessageDirection,
    MessageLog,
    MessageStatus,
    PlanType,
    Rule,
    TriggerType,
    User,
    utcnow,
)
from app.services.night_guard import (
    NIGHT_GUARD_DEFAULT_TEXT,
    format_minutes,
    is_within_window,
    night_mark_sent,
    night_should_send_now,
    night_was_sent,
    parse_hhmm,
)

_ENGINES = []


def make_session():
    engine = create_engine("sqlite:///:memory:")
    _ENGINES.append(engine)
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine, future=True, expire_on_commit=False)()


def seed_account(session, telegram_user_id: int, bc_id: str):
    user = User(telegram_user_id=telegram_user_id, first_name="Test")
    session.add(user)
    session.flush()
    conn = BusinessConnection(
        business_connection_id=bc_id,
        user_id=user.id,
        telegram_user_id=telegram_user_id,
        is_enabled=True,
        can_reply=True,
    )
    session.add(conn)
    session.flush()
    account = BusinessAccount(
        owner_user_id=user.id,
        business_connection_id=conn.id,
        plan=PlanType.FREE,
        is_enabled=True,
    )
    session.add(account)
    session.flush()
    return user, conn, account


# ---------------------------------------------------------------------------
# ۱) منطق خالص
# ---------------------------------------------------------------------------


class NightWindowTest(unittest.TestCase):
    def test_normal_window(self):
        # 13:00 تا 18:00
        self.assertTrue(is_within_window(13 * 60, 13 * 60, 18 * 60))  # شروع شامل
        self.assertTrue(is_within_window(15 * 60 + 30, 13 * 60, 18 * 60))
        self.assertFalse(is_within_window(18 * 60, 13 * 60, 18 * 60))  # پایان شامل نیست
        self.assertFalse(is_within_window(12 * 60 + 59, 13 * 60, 18 * 60))

    def test_overnight_window(self):
        # 23:00 تا 09:00 — از نیمه‌شب رد می‌شود
        self.assertTrue(is_within_window(23 * 60, 23 * 60, 9 * 60))
        self.assertTrue(is_within_window(2 * 60, 23 * 60, 9 * 60))
        self.assertTrue(is_within_window(8 * 60 + 59, 23 * 60, 9 * 60))
        self.assertFalse(is_within_window(9 * 60, 23 * 60, 9 * 60))
        self.assertFalse(is_within_window(12 * 60, 23 * 60, 9 * 60))

    def test_equal_or_missing_bounds_is_inactive(self):
        self.assertFalse(is_within_window(12 * 60, 12 * 60, 12 * 60))
        self.assertFalse(is_within_window(12 * 60, None, 9 * 60))
        self.assertFalse(is_within_window(12 * 60, 23 * 60, None))
        self.assertFalse(is_within_window(1500, 0, 100))  # دقیقه‌ی نامعتبر

    def test_parse_hhmm(self):
        self.assertEqual(parse_hhmm("23:00"), 1380)
        self.assertEqual(parse_hhmm("9:30"), 570)
        self.assertEqual(parse_hhmm("۹:۳۰"), 570)  # ارقام فارسی
        self.assertEqual(parse_hhmm("  07:05  "), 7 * 60 + 5)
        self.assertIsNone(parse_hhmm("24:00"))
        self.assertIsNone(parse_hhmm("12:60"))
        self.assertIsNone(parse_hhmm("abc"))
        self.assertIsNone(parse_hhmm("12"))
        self.assertIsNone(parse_hhmm(""))
        self.assertIsNone(parse_hhmm(None))

    def test_format_minutes(self):
        self.assertEqual(format_minutes(1380), "23:00")
        self.assertEqual(format_minutes(0), "00:00")
        self.assertEqual(format_minutes(None), "—")

    def test_resolve_timezone(self):
        from types import SimpleNamespace as NS

        from app.services.night_guard import DEFAULT_TIMEZONE, resolve_timezone, zone_for

        self.assertEqual(resolve_timezone("Asia/Tehran"), "Asia/Tehran")
        self.assertEqual(resolve_timezone("asia/tehran"), "Asia/Tehran")  # حروف کوچک
        self.assertEqual(resolve_timezone("EUROPE/BERLIN"), "Europe/Berlin")
        self.assertEqual(resolve_timezone("europe berlin"), "Europe/Berlin")  # فاصله به‌جای _
        self.assertIsNone(resolve_timezone("Mars/Phobos"))
        self.assertIsNone(resolve_timezone(""))
        self.assertIsNone(resolve_timezone(None))

        # zone_for: حساب با منطقه → همان؛ بدون منطقه/نامعتبر → پیش‌فرض تهران
        self.assertEqual(
            str(zone_for(NS(night_guard_timezone="asia/tehran"))), "Asia/Tehran"
        )
        self.assertEqual(
            str(zone_for(NS(night_guard_timezone="Europe/Berlin"))), "Europe/Berlin"
        )
        self.assertEqual(str(zone_for(NS(night_guard_timezone=None))), "Asia/Tehran")
        self.assertEqual(str(zone_for(NS(night_guard_timezone="Bogus/Zone"))), DEFAULT_TIMEZONE)

    def test_once_per_night_state(self):
        state = None
        self.assertFalse(night_was_sent(state, 111, "2026-09-10"))
        state = night_mark_sent(state, 111, "2026-09-10")
        self.assertTrue(night_was_sent(state, 111, "2026-09-10"))
        self.assertFalse(night_was_sent(state, 222, "2026-09-10"))  # مشتری دیگر
        self.assertFalse(night_was_sent(state, 111, "2026-09-11"))  # شب بعد

    def test_state_prunes_old_nights(self):
        state = '{"55": "2026-09-08", "66": "2026-09-09"}'
        state = night_mark_sent(state, 77, "2026-09-10")
        self.assertEqual(state, '{"77":"2026-09-10"}')  # قدیمی‌ها پاک شدند

    def test_should_send_now_combined(self):
        kwargs = dict(
            start_minute=23 * 60,
            end_minute=9 * 60,
            state_json=None,
            chat_id=1,
            today="2026-09-10",
        )
        self.assertTrue(night_should_send_now(minutes_now=23 * 60 + 5, **kwargs))
        self.assertFalse(night_should_send_now(minutes_now=12 * 60, **kwargs))  # بیرون بازه
        sent = night_mark_sent(None, 1, "2026-09-10")
        kwargs["state_json"] = sent
        self.assertFalse(night_should_send_now(minutes_now=23 * 60 + 5, **kwargs))


# ---------------------------------------------------------------------------
# ۲) لایه‌ی repository
# ---------------------------------------------------------------------------


class NightGuardRepoTest(unittest.TestCase):
    def tearDown(self):
        for engine in _ENGINES:
            engine.dispose()
        _ENGINES.clear()

    def test_defaults_are_off(self):
        session = make_session()
        _, _, account = seed_account(session, 4001, "bc-ng1")
        settings = repository.get_night_guard_settings(session, account)
        self.assertFalse(settings["enabled"])
        self.assertIsNone(settings["start_minute"])
        self.assertIsNone(settings["end_minute"])
        self.assertIsNone(settings["text"])
        session.close()

    def test_set_and_persist(self):
        session = make_session()
        _, _, account = seed_account(session, 4002, "bc-ng2")
        repository.set_night_guard(
            session, account, text="  بسته‌ایم 🌙  ", start_minute=1380, end_minute=540
        )
        repository.set_night_guard(session, account, enabled=True)
        session.flush()
        settings = repository.get_night_guard_settings(session, account)
        self.assertTrue(settings["enabled"])
        self.assertEqual(settings["start_minute"], 1380)
        self.assertEqual(settings["end_minute"], 540)
        self.assertEqual(settings["text"], "بسته‌ایم 🌙")  # بدون فضای اضافه
        session.close()

    def test_empty_text_returns_to_default(self):
        session = make_session()
        _, _, account = seed_account(session, 4003, "bc-ng3")
        repository.set_night_guard(session, account, text="متن")
        repository.set_night_guard(session, account, text="   ")
        self.assertIsNone(repository.get_night_guard_settings(session, account)["text"])
        session.close()

    def test_mark_and_was_sent_via_session(self):
        session = make_session()
        _, _, account = seed_account(session, 4004, "bc-ng4")
        repository.night_mark_sent(session, account.id, 555, "2026-09-10")
        session.flush()
        self.assertTrue(repository.night_was_sent(session, account.id, 555, "2026-09-10"))
        self.assertFalse(repository.night_was_sent(session, account.id, 556, "2026-09-10"))
        self.assertFalse(repository.night_was_sent(session, account.id, 555, "2026-09-11"))
        session.close()


# ---------------------------------------------------------------------------
# ۳) انتگرال: مسیر کامل on_business_message با اشیای شبیه‌سازی‌شده
# ---------------------------------------------------------------------------


class _FakeBot:
    """بوت شبیه‌سازی‌شده — send_message را ضبط می‌کند (بدون شبکه)."""

    def __init__(self):
        self.sent = []

    async def send_message(self, *, chat_id, text, business_connection_id=None, **kw):
        self.sent.append((chat_id, text))
        return SimpleNamespace(message_id=1000 + len(self.sent))


class NightGuardFlowTest(unittest.TestCase):
    """مسیر کامل on_business_message — با دیتابیس فایلی مشترک (هندلر از
    app.database.get_session استفاده می‌کند، پس engine سراسری به فایل تست
    اشاره داده می‌شود) و بوتِ شبیه‌سازی‌شده (بدون شبکه)."""

    def setUp(self):
        import app.database as appdb

        self.db_path = f"/tmp/ng-flow-{id(self)}.db"
        Path(self.db_path).unlink(missing_ok=True)
        url = f"sqlite:///{self.db_path}"  # sqlite:////tmp/... (absolute)
        self.engine = create_engine(url, connect_args={"check_same_thread": False})
        Base.metadata.create_all(self.engine)
        self.session = sessionmaker(bind=self.engine, future=True, expire_on_commit=False)()

        # هندلر با get_session() سراسری کار می‌کند → به همین فایل اشاره می‌دهیم
        self._old_engine, self._old_sl = appdb.engine, appdb.SessionLocal
        appdb.engine = self.engine
        appdb.SessionLocal = sessionmaker(
            bind=self.engine, future=True, expire_on_commit=False
        )

    def tearDown(self):
        import app.database as appdb

        appdb.engine, appdb.SessionLocal = self._old_engine, self._old_sl
        self.session.close()
        self.engine.dispose()
        Path(self.db_path).unlink(missing_ok=True)

    def _seed(
        self,
        *,
        night_enabled: bool,
        with_matching_rule: bool,
        night_window: tuple[int, int] | None = None,
        timezone: str | None = None,
    ):
        user = User(telegram_user_id=5001, first_name="صاحب")
        self.session.add(user)
        self.session.flush()
        conn = BusinessConnection(
            business_connection_id="bc-flow",
            user_id=user.id,
            telegram_user_id=5001,
            is_enabled=True,
            can_reply=True,
        )
        self.session.add(conn)
        self.session.flush()
        account = BusinessAccount(
            owner_user_id=user.id,
            business_connection_id=conn.id,
            plan=PlanType.FREE,
            is_enabled=True,
        )
        self.session.add(account)
        self.session.flush()
        if night_enabled:
            kwargs = dict(enabled=True)
            if night_window is not None:
                kwargs["start_minute"], kwargs["end_minute"] = night_window
            else:
                kwargs["start_minute"], kwargs["end_minute"] = 0, 1439
            if timezone is not None:
                kwargs["timezone"] = timezone
            repository.set_night_guard(self.session, account, **kwargs)
        if with_matching_rule:
            self.session.add(
                Rule(
                    business_account_id=account.id,
                    trigger_type=TriggerType.CONTAINS,
                    trigger_value="قیمت",
                    response_text="لیست قیمت 👇",
                    enabled=True,
                )
            )
        self.session.flush()
        self.session.commit()  # هندلر با connection جدا وصل می‌شود — باید commit شود
        return account

    def _run_handler(self, message_id: int, text: str) -> _FakeBot:
        from app.handlers import business_handlers

        message = SimpleNamespace(
            business_connection_id="bc-flow",
            message_id=message_id,
            chat=SimpleNamespace(id=777000),
            from_user=SimpleNamespace(id=42, is_bot=False, first_name="مشتری", username=None),
            text=text,
            caption=None,
        )
        bot = _FakeBot()
        asyncio.run(
            business_handlers.on_business_message(
                SimpleNamespace(business_message=message), SimpleNamespace(bot=bot)
            )
        )
        return bot

    def _refresh(self):
        self.session.expire_all()

    def test_timezone_berlin_window_follows_account_zone(self):
        """🌍 بازه‌ی تنظیم‌شده به وقتِ منطقه‌ی حساب (برلین) اعمال می‌شود — نه تهران.

        بازه: [الانِ برلین − ۱۲۰ دقیقه، الانِ برلین + ۶۰) — شامل «الانِ برلین» است
        ولی «الانِ تهران» (همیشه ۹۰ یا ۱۵۰ دقیقه جلوتر) را شامل نمی‌شود؛ پس اگر
        کد همچنان تهران را ملاک می‌گرفت، پیام شب ارسال نمی‌شد.
        """
        from zoneinfo import ZoneInfo

        now_berlin = datetime.now(ZoneInfo("Europe/Berlin"))
        now_tehran = datetime.now(ZoneInfo("Asia/Tehran"))
        berlin_minutes = now_berlin.hour * 60 + now_berlin.minute
        tehran_minutes = now_tehran.hour * 60 + now_tehran.minute
        start = (berlin_minutes - 120) % 1440
        end = (berlin_minutes + 60) % 1440

        self.assertTrue(is_within_window(berlin_minutes, start, end))
        self.assertFalse(is_within_window(tehran_minutes, start, end))

        account = self._seed(
            night_enabled=True,
            with_matching_rule=True,
            night_window=(start, end),
            timezone="Europe/Berlin",
        )
        bot = self._run_handler(4001, "سلام")  # هیچ قانونی مچ نمی‌شود → مسیر نگهبان
        self.assertEqual(len(bot.sent), 1, "پیام شب به وقت برلین باید ارسال می‌شد")
        self.assertIn("بسته", bot.sent[0][1])
        self._refresh()
        self.assertEqual(
            self.session.get(BusinessAccount, account.id).night_guard_timezone,
            "Europe/Berlin",
        )

    def test_night_replaces_rules_and_sends_once(self):
        account = self._seed(night_enabled=True, with_matching_rule=True)

        bot = self._run_handler(900, "سلام قیمت دارید؟")

        # فقط پیام شبانه ارسال شده (نه جواب قانون)
        self.assertEqual(len(bot.sent), 1)
        chat_id, text = bot.sent[0]
        self.assertEqual(chat_id, 777000)
        self.assertEqual(text, NIGHT_GUARD_DEFAULT_TEXT)

        # «امشب فرستادیم» ثبت شده
        self._refresh()
        from app.timeutil import to_iran

        today = to_iran(utcnow()).strftime("%Y-%m-%d")
        account = self.session.get(BusinessAccount, account.id)
        self.assertEqual(json.loads(account.night_sent_state).get("777000"), today)

        # لاگ‌ها: یک INCOMING (IGNORED) + یک OUTGOING (SUCCESS) — بدون اتصال به قانون
        logs = self.session.query(MessageLog).order_by(MessageLog.id).all()
        self.assertEqual(
            [(l.direction, l.status) for l in logs],
            [(MessageDirection.INCOMING, MessageStatus.IGNORED), (MessageDirection.OUTGOING, MessageStatus.SUCCESS)],
        )
        self.assertTrue(all(l.matched_rule_id is None for l in logs))

    def test_night_does_not_spam_second_message(self):
        self._seed(night_enabled=True, with_matching_rule=False)

        first = self._run_handler(900, "سلام؟")
        self.assertEqual(len(first.sent), 1)  # اولین پیام → پیام شبانه

        second = self._run_handler(901, "سلام؟؟")
        self.assertEqual(second.sent, [])  # دومین پیام همان شب → سکوت (بدون اسپم)

        # لاگ پیام دوم هم ثبت شده (Dedup سالم) و هیچ پاسخی به آن نرفته
        incoming = (
            self.session.query(MessageLog)
            .filter(
                MessageLog.telegram_message_id == 901,
                MessageLog.direction == MessageDirection.INCOMING,
            )
            .count()
        )
        self.assertEqual(incoming, 1)

    def test_custom_night_text_is_used(self):
        account = self._seed(night_enabled=False, with_matching_rule=False)
        repository.set_night_guard(
            self.session, account, enabled=True, text="بسته‌ایم 🌙 صبح می‌رسیم", start_minute=0, end_minute=1439
        )
        self.session.commit()

        bot = self._run_handler(905, "هستی؟")
        self.assertEqual(bot.sent, [(777000, "بسته‌ایم 🌙 صبح می‌رسیم")])

    def test_paused_stops_everything_and_resume_restores(self):
        """⏸ با توقف کامل: قوانین AND نگهبان شبانه هر دو ساکت می‌شوند؛ با از سرگیری، قانون برمی‌گردد."""
        from app import repository

        account = self._seed(night_enabled=True, with_matching_rule=True)
        repository.set_auto_reply_paused(self.session, account, True)
        self.session.commit()

        bot1 = self._run_handler(920, "سلام قیمت دارید؟")
        self.assertEqual(bot1.sent, [])  # نه قانون، نه نگهبان — همه ساکت

        repository.set_auto_reply_paused(self.session, account, False)
        self.session.commit()

        # از سرگیری شد؛ نگهبان هنوز فعاله → «اولین» پیام این مشتری در این شب
        # نبوده (توقف مانع ارسال شد) → نگهبان (درست) پیام شبانه می‌فرستد:
        bot2 = self._run_handler(921, "سلام قیمت دارید؟")
        self.assertEqual(len(bot2.sent), 1)
        self.assertIn("بسته", bot2.sent[0][1])  # نگهبان دوباره در چرخه است

        # حالا برای این مشتری «امشب فرستادیم» را دستی ثبت می‌کنیم تا مسیر
        # «قوانین» بعد از از سرگیری بررسی شود:
        from app.timeutil import to_iran

        today = to_iran(utcnow()).strftime("%Y-%m-%d")
        repository.night_mark_sent(self.session, account.id, 777000, today)
        self.session.commit()

        bot3 = self._run_handler(922, "سلام قیمت دارید؟")
        self.assertEqual(len(bot3.sent), 1)
        self.assertEqual(bot3.sent[0][1], "لیست قیمت 👇")  # قانون دوباره کار می‌کند

    def test_rules_work_when_night_disabled(self):
        self._seed(night_enabled=False, with_matching_rule=True)

        bot = self._run_handler(900, "سلام قیمت دارید؟")

        self.assertEqual(len(bot.sent), 1)
        self.assertEqual(bot.sent[0][1], "لیست قیمت 👇")  # جواب قانون — نه پیام شب
        # آمار قانون ثبت شد (فقط پیام ورودی شمرده می‌شود؛ خروجی هم matched دارد ولی شمارش آمار فقط INCOMING است)
        matched_incoming = (
            self.session.query(MessageLog)
            .filter(
                MessageLog.matched_rule_id.isnot(None),
                MessageLog.direction == MessageDirection.INCOMING,
            )
            .count()
        )
        self.assertEqual(matched_incoming, 1)


if __name__ == "__main__":
    unittest.main()
