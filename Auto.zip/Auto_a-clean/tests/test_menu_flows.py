"""
تست جریان دکمه‌ها (Button Flow) — جلوگیری از بازگشت باگ «دستور نامشخص».

باگ واقعی (۱۴۰۵/۰۶/۱۹): دکمه‌ی «🌙 نگهبان شبانه» در کیبورد لیست قوانین رندر
می‌شد ولی شاخه‌ی هندلش در handle_rules_menu_text جا افتاده بود → کاربر
«دستور نامشخص» می‌گرفت. این فایل هر دکمه‌ی هر کیبوردِ بخش قوانین را واقعاً
فشار می‌دهد (با update/context شبیه‌سازی‌شده) تا هر دکمه‌ی رندرشده حتماً
هندل‌شده باشد — برای همیشه.
"""
import asyncio
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app import keyboards, repository, texts
from app.handlers import rule_handlers, state
from app.models import (
    Base,
    BusinessAccount,
    BusinessConnection,
    PlanType,
    User,
)

TG_ID = 6001


class _FakeMessage:
    def __init__(self):
        self.replies = []

    async def reply_text(self, text, reply_markup=None, **kw):
        self.replies.append(text)


class _FakeBot:
    def __init__(self):
        self.sent = []

    async def send_message(self, **kw):
        self.sent.append(kw)
        return SimpleNamespace(message_id=1)


class MenuFlowTestBase(unittest.TestCase):
    def setUp(self):
        import app.database as appdb

        self.db_path = f"/tmp/menu-flow-{id(self)}.db"
        Path(self.db_path).unlink(missing_ok=True)
        self.engine = create_engine(f"sqlite:///{self.db_path}", connect_args={"check_same_thread": False})
        Base.metadata.create_all(self.engine)
        self.session = sessionmaker(bind=self.engine, future=True, expire_on_commit=False)()

        self._old_engine, self._old_sl = appdb.engine, appdb.SessionLocal
        appdb.engine = self.engine
        appdb.SessionLocal = sessionmaker(bind=self.engine, future=True, expire_on_commit=False)

        # یک کاربر Free با اکانت متصل
        user = User(telegram_user_id=TG_ID, first_name="صاحب")
        self.session.add(user)
        self.session.flush()
        conn = BusinessConnection(
            business_connection_id="bc-menu",
            user_id=user.id,
            telegram_user_id=TG_ID,
            is_enabled=True,
            can_reply=True,
        )
        self.session.add(conn)
        self.session.flush()
        self.account = BusinessAccount(
            owner_user_id=user.id,
            business_connection_id=conn.id,
            plan=PlanType.FREE,
            is_enabled=True,
        )
        self.session.add(self.account)
        self.session.flush()
        self.session.commit()

    def tearDown(self):
        import app.database as appdb

        appdb.engine, appdb.SessionLocal = self._old_engine, self._old_sl
        self.session.close()
        self.engine.dispose()
        Path(self.db_path).unlink(missing_ok=True)

    # --- ابزار فشردن دکمه ---

    def _update(self):
        return SimpleNamespace(
            effective_user=SimpleNamespace(id=TG_ID, first_name="صاحب"),
            effective_message=_FakeMessage(),
        )

    def _context(self):
        return SimpleNamespace(user_data={}, bot_data={})

    def _press(self, handler, text, context=None):
        """یک دکمه را مثل روتر واقعی فشار می‌دهد. خروجی: (هندل‌شد؟، update، context)"""
        update, ctx = self._update(), context or self._context()
        handled = asyncio.run(handler(update, ctx, text))
        return bool(handled), update, ctx

    def _menu(self, context):
        return state.get_menu(context)

    def _assert_handled(self, handler, text, expected_menu=None, context=None):
        handled, update, ctx = self._press(handler, text, context)
        self.assertTrue(handled, f"دکمه‌ی {text!r} هندل نشد → کاربر «دستور نامشخص» می‌گیرد!")
        self.assertTrue(update.effective_message.replies, f"دکمه‌ی {text!r} بدون هیچ پاسخی بود")
        if expected_menu is not None:
            self.assertEqual(self._menu(ctx), expected_menu)
        return update, ctx


# ---------------------------------------------------------------------------
# کیبورد «لیست قوانین» — تک‌تک دکمه‌ها
# ---------------------------------------------------------------------------


class RulesMenuButtonsTest(MenuFlowTestBase):
    def test_every_rules_menu_button_is_handled(self):
        """هیچ دکمه‌ای که در لیست قوانین رندر می‌شود نباید «دستور نامشخص» بدهد."""
        kb = keyboards.rules_list_keyboard(custom_rules=[], free_rule_enabled=True, auto_reply_paused=False)
        labels = [b.text for row in kb.keyboard for b in row]

        ctx = self._context()
        state.set_menu(ctx, state.MENU_RULES)
        for label in labels:
            if label == texts.BTN_BACK_TO_MENU:
                continue  # این دکمه در روتر سراسری bot.py هندل می‌شود (خارج از این هندلر)
            handled, update, _ = self._press(rule_handlers.handle_rules_menu_text, label, ctx)
            self.assertTrue(
                handled,
                f"دکمه‌ی {label!r} در لیست قوانین هندل نشده — همون باگ «دستور نامشخص»!",
            )
            state.set_menu(ctx, state.MENU_RULES)  # ریست برای دکمه‌ی بعدی

    def test_night_guard_button_opens_menu(self):
        """باگ بازتولیدشده: دکمه‌ی 🌙 باید منوی نگهبان شبانه را باز کند."""
        self._assert_handled(
            rule_handlers.handle_rules_menu_text,
            texts.BTN_NIGHT_GUARD,
            expected_menu=state.MENU_NIGHT_GUARD,
        )

    def test_rule_test_button_opens_tester(self):
        self._assert_handled(
            rule_handlers.handle_rules_menu_text,
            texts.BTN_RULE_TEST,
            expected_menu=state.MENU_RULE_TEST,
        )

    def test_pause_all_button_toggles_account_flag(self):
        """⏸ توقف همه → پرچم اکانت True؛ ▶️ از سرگیری → False (همه با یک کلید)."""
        _, ctx = self._assert_handled(
            rule_handlers.handle_rules_menu_text,
            texts.BTN_RULES_PAUSE_ALL,
            expected_menu=state.MENU_RULES,
        )
        self.session.expire_all()
        self.assertTrue(self.session.get(BusinessAccount, self.account.id).auto_reply_paused)

        # حالا دکمه باید «از سرگیری» باشد و کار کند
        kb = keyboards.rules_list_keyboard([], True, auto_reply_paused=True)
        labels = [b.text for row in kb.keyboard for b in row]
        self.assertIn(texts.BTN_RULES_RESUME_ALL, labels)

        handled, _, _ = self._press(rule_handlers.handle_rules_menu_text, texts.BTN_RULES_RESUME_ALL, ctx)
        self.assertTrue(handled)
        self.session.expire_all()
        self.assertFalse(self.session.get(BusinessAccount, self.account.id).auto_reply_paused)

    def test_rule_add_button_starts_draft(self):
        self._assert_handled(
            rule_handlers.handle_rules_menu_text,
            texts.BTN_RULE_ADD,
            expected_menu=state.MENU_RULE_ADD_TRIGGER_TYPE,
        )


# ---------------------------------------------------------------------------
# کیبورد «نگهبان شبانه» — سفر کامل کاربر: تنظیم تا روشن/خاموش
# ---------------------------------------------------------------------------


class NightGuardJourneyTest(MenuFlowTestBase):
    def test_every_night_guard_button_is_handled(self):
        kb = keyboards.night_guard_menu_keyboard(enabled=False)
        labels = [b.text for row in kb.keyboard for b in row]
        ctx = self._context()
        state.set_menu(ctx, state.MENU_NIGHT_GUARD)
        for label in labels:
            if label in (texts.BTN_BACK_TO_MENU,):
                continue
            handled, _, _ = self._press(rule_handlers.handle_night_guard_menu_text, label, ctx)
            self.assertTrue(handled, f"دکمه‌ی {label!r} در منوی نگهبان هندل نشده!")
            state.set_menu(ctx, state.MENU_NIGHT_GUARD)

    def test_full_journey_set_times_and_enable(self):
        """سفر واقعی کاربر: منو → ساعت شروع → ساعت پایان → فعال‌سازی → خاموشی."""
        _, ctx = self._assert_handled(
            rule_handlers.handle_rules_menu_text,
            texts.BTN_NIGHT_GUARD,
            expected_menu=state.MENU_NIGHT_GUARD,
        )

        # قبل از تنظیم ساعت، فعال‌سازی رد می‌شود (پیام راهنما، بدون تغییر منو)
        handled, u0, ctx = self._press(
            rule_handlers.handle_night_guard_menu_text, texts.BTN_NIGHT_ON, ctx
        )
        self.assertTrue(handled)
        self.assertTrue(any("اول ساعت" in r for r in u0.effective_message.replies))

        # ⏰ ساعت شروع — اول نامعتبر (در منو می‌ماند)، بعد معتبر
        state.set_menu(ctx, state.MENU_NIGHT_GUARD_START)
        handled, u1, ctx = self._press(rule_handlers.handle_night_guard_time_input, "25:99", ctx)
        self.assertTrue(handled)
        self.assertTrue(any("درست نیست" in r for r in u1.effective_message.replies))
        self.assertEqual(self._menu(ctx), state.MENU_NIGHT_GUARD_START)

        handled, u2, ctx = self._press(rule_handlers.handle_night_guard_time_input, "23:00", ctx)
        self.assertTrue(handled)
        self.assertEqual(self._menu(ctx), state.MENU_NIGHT_GUARD)

        # 🌅 ساعت پایان (از طریق دکمه‌ی خود منو)
        handled, _, ctx = self._press(
            rule_handlers.handle_night_guard_menu_text, texts.BTN_NIGHT_END, ctx
        )
        self.assertTrue(handled)
        self.assertEqual(self._menu(ctx), state.MENU_NIGHT_GUARD_END)
        handled, _, ctx = self._press(rule_handlers.handle_night_guard_time_input, "9:30", ctx)
        self.assertTrue(handled)
        self.assertEqual(self._menu(ctx), state.MENU_NIGHT_GUARD)

        # ✅ حالا فعال‌سازی موفق است
        handled, u3, ctx = self._press(
            rule_handlers.handle_night_guard_menu_text, texts.BTN_NIGHT_ON, ctx
        )
        self.assertTrue(handled)
        self.assertTrue(any("فعال شد" in r for r in u3.effective_message.replies))

        self.session.expire_all()
        acc = self.session.get(BusinessAccount, self.account.id)
        self.assertTrue(acc.night_guard_enabled)
        self.assertEqual(acc.night_start_minute, 23 * 60)
        self.assertEqual(acc.night_end_minute, 9 * 60 + 30)

        # ☀️ خاموش‌کردن
        handled, u4, ctx = self._press(
            rule_handlers.handle_night_guard_menu_text, texts.BTN_NIGHT_OFF, ctx
        )
        self.assertTrue(handled)
        self.assertTrue(any("خاموش شد" in r for r in u4.effective_message.replies))
        self.session.expire_all()
        self.assertFalse(self.session.get(BusinessAccount, self.account.id).night_guard_enabled)

    def test_equal_start_end_rejected(self):
        """شروع == پایان باید رد شود و کاربر در منوی پایان بماند."""
        # اول شروع را 23:00 ذخیره کن
        ctx = self._context()
        state.set_menu(ctx, state.MENU_NIGHT_GUARD_START)
        handled, _, ctx = self._press(rule_handlers.handle_night_guard_time_input, "23:00", ctx)
        self.assertTrue(handled)

        # حالا پایان را هم 23:00 بزن → رد شود و در منوی پایان بماند
        state.set_menu(ctx, state.MENU_NIGHT_GUARD_END)
        update = self._update()
        handled = asyncio.run(
            rule_handlers.handle_night_guard_time_input(update, ctx, "23:00")
        )
        self.assertTrue(handled)
        self.assertTrue(any("یکی باشن" in r for r in update.effective_message.replies))
        self.assertEqual(self._menu(ctx), state.MENU_NIGHT_GUARD_END)
        # و پایان ذخیره نشده باشد
        self.session.expire_all()
        self.assertIsNone(self.session.get(BusinessAccount, self.account.id).night_end_minute)

    def test_custom_text_then_default_reset(self):
        ctx = self._context()
        state.set_menu(ctx, state.MENU_NIGHT_GUARD_TEXT)

        handled, u1, ctx = self._press(
            rule_handlers.handle_night_guard_text_input, "بسته‌ایم تا صبح 🌙", ctx
        )
        self.assertTrue(handled)
        self.session.expire_all()
        self.assertEqual(
            self.session.get(BusinessAccount, self.account.id).night_guard_text,
            "بسته‌ایم تا صبح 🌙",
        )

        handled, u2, ctx = self._press(
            rule_handlers.handle_night_guard_text_input, texts.BTN_NIGHT_DEFAULT_TEXT, ctx
        )
        self.assertTrue(handled)
        self.session.expire_all()
        self.assertIsNone(
            self.session.get(BusinessAccount, self.account.id).night_guard_text
        )


# ---------------------------------------------------------------------------
# جزئیات قانون — دکمه‌ی 📄 کپی
# ---------------------------------------------------------------------------


class RuleDetailButtonsTest(MenuFlowTestBase):
    def test_copy_button_from_rule_detail(self):
        from app.models import Rule, TriggerType

        rule = Rule(
            business_account_id=self.account.id,
            trigger_type=TriggerType.CONTAINS,
            trigger_value="قیمت",
            response_text="لیست",
            enabled=True,
        )
        self.session.add(rule)
        self.session.commit()

        ctx = self._context()
        ctx.user_data[state.CURRENT_RULE_ID] = rule.id
        state.set_menu(ctx, state.MENU_RULE_DETAIL)

        handled, update, ctx = self._press(
            rule_handlers.handle_rule_detail_text, texts.BTN_RULE_COPY, ctx
        )
        self.assertTrue(handled)
        self.assertTrue(any("نسخه‌ی جدید" in r for r in update.effective_message.replies))
        self.assertEqual(self._menu(ctx), state.MENU_RULES)  # برگشت به لیست


if __name__ == "__main__":
    unittest.main()
