"""
تست‌های 🧪 شبیه‌ساز قانون (app/services/rule_tester.py).

سرویس خالص است (بدون تلگرام/دیتابیس) پس تست هم بدون dependency بیرونی اجرا می‌شود.
هدف: تضمین اینکه پیش‌نمایش «دقیقاً» همان رفتار پاسخ‌گویی واقعی را نشان می‌دهد.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.rule_engine import EngineRule, ResponseMediaType, RuleMediaItem, TriggerType
from app.services.rule_tester import preview_response, trigger_label


def make_rule(
    rule_id: int,
    trigger_type: TriggerType,
    trigger_value: str | None,
    response_text: str = "پاسخ",
    *,
    enabled: bool = True,
    priority: int = 0,
    photos: int = 0,
) -> EngineRule:
    media = tuple(
        RuleMediaItem(telegram_file_id=f"file-{rule_id}-{i}", sort_order=i) for i in range(photos)
    )
    return EngineRule(
        id=rule_id,
        trigger_type=trigger_type,
        trigger_value=trigger_value,
        response_text=response_text,
        response_media_type=ResponseMediaType.PHOTO if photos else ResponseMediaType.NONE,
        media_items=media,
        priority=priority,
        enabled=enabled,
        requires_pro=False,
        is_system=False,
    )


class RuleTesterTest(unittest.TestCase):
    def test_exact_match_wins_over_contains(self):
        """ترتیب واقعی انجین: EXACT مقدم بر CONTAINS است — پیش‌نمایش هم باید همین را بگوید."""
        rules = (
            make_rule(1, TriggerType.CONTAINS, "قیمت", "جواب شامل‌شدنی"),
            make_rule(2, TriggerType.EXACT, "قیمت", "جواب دقیق"),
        )
        outcome = preview_response(rules=rules, incoming_text="قیمت", fallback_enabled=False, fallback_text=None)
        self.assertIsNotNone(outcome.matched)
        self.assertEqual(outcome.matched.id, 2)
        self.assertFalse(outcome.via_fallback)
        self.assertEqual(outcome.final_response_text, "جواب دقیق")
        self.assertEqual(outcome.final_photos_count, 0)

    def test_contains_match_with_photos_count(self):
        rules = (make_rule(5, TriggerType.CONTAINS, "آدرس", "آدرس ما...", photos=3),)
        outcome = preview_response(rules=rules, incoming_text="لطفاً آدرس فروشگاه رو بگید", fallback_enabled=False, fallback_text=None)
        self.assertEqual(outcome.matched.id, 5)
        self.assertEqual(outcome.final_photos_count, 3)

    def test_unicode_normalization_same_as_real_engine(self):
        """ي عربی در پیام باید با ی فارسیِ شرط Match شود (همان نرمال‌سازی انجین واقعی)."""
        rules = (make_rule(7, TriggerType.EXACT, "قیمت", "پاسخ قیمت"),)
        outcome = preview_response(rules=rules, incoming_text="قیمت", fallback_enabled=False, fallback_text=None)
        self.assertIsNotNone(outcome.matched)

    def test_disabled_rule_is_ignored(self):
        rules = (make_rule(3, TriggerType.EXACT, "سلام", "جواب خاموش", enabled=False),)
        outcome = preview_response(rules=rules, incoming_text="سلام", fallback_enabled=False, fallback_text=None)
        self.assertIsNone(outcome.matched)
        self.assertFalse(outcome.via_fallback)
        self.assertIsNone(outcome.final_response_text)

    def test_no_match_falls_back_when_enabled_with_text(self):
        rules = (make_rule(1, TriggerType.EXACT, "سلام", "سلام!"),)
        outcome = preview_response(
            rules=rules,
            incoming_text="ارسال به کرج دارید؟",
            fallback_enabled=True,
            fallback_text="  به زودی جواب می‌دهیم  ",
        )
        self.assertIsNone(outcome.matched)
        self.assertTrue(outcome.via_fallback)
        self.assertEqual(outcome.final_response_text, "به زودی جواب می‌دهیم")
        self.assertEqual(outcome.final_photos_count, 0)

    def test_blank_fallback_text_treated_as_off(self):
        rules = (make_rule(1, TriggerType.EXACT, "سلام", "سلام!"),)
        outcome = preview_response(rules=rules, incoming_text="چند؟", fallback_enabled=True, fallback_text="   ")
        self.assertIsNone(outcome.matched)
        self.assertFalse(outcome.via_fallback)

    def test_priority_breaks_tie_between_contains(self):
        rules = (
            make_rule(10, TriggerType.CONTAINS, "تخفیف", "جواب کم‌اولویت", priority=0),
            make_rule(11, TriggerType.CONTAINS, "تخفیف", "جواب پرباولویت", priority=5),
        )
        outcome = preview_response(rules=rules, incoming_text="تخفیف دارید؟", fallback_enabled=False, fallback_text=None)
        self.assertEqual(outcome.matched.id, 11)

    def test_trigger_label_fa(self):
        self.assertEqual(trigger_label(make_rule(1, TriggerType.EXACT, "x")), "برابر دقیق")
        self.assertEqual(trigger_label(make_rule(1, TriggerType.CONTAINS, "x")), "شامل شدن")

    def test_system_hello_rule_is_testable(self):
        """قانون رایگان «سلام» هم باید در پیش‌نمایش دیده شود (در لیست واقعی هست)."""
        from app.rule_engine import FREE_DEFAULT_RULE

        outcome = preview_response(
            rules=(FREE_DEFAULT_RULE,), incoming_text="سلام", fallback_enabled=False, fallback_text=None
        )
        self.assertIsNotNone(outcome.matched)
        self.assertEqual(outcome.matched.id, 0)
        self.assertIn("سلام", outcome.final_response_text)


if __name__ == "__main__":
    unittest.main()
